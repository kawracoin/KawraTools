These are the irreducible polynomials over *GF(2)* used to represent field elements:

* *x<sup>2</sup> + x + 1*
* *x<sup>3</sup> + x + 1*
* *x<sup>4</sup> + x + 1*
* *x<sup>5</sup> + x<sup>2</sup> + 1*
* *x<sup>6</sup> + x + 1*
* *x<sup>7</sup> + x + 1*
* *x<sup>8</sup> + x<sup>4</sup> + x<sup>3</sup> + x + 1*
* *x<sup>9</sup> + x + 1*
* *x<sup>10</sup> + x<sup>3</sup> + 1*
* *x<sup>11</sup> + x<sup>2</sup> + 1*
* *x<sup>12</sup> + x<sup>3</sup> + 1*
* *x<sup>13</sup> + x<sup>4</sup> + x<sup>3</sup> + x + 1*
* *x<sup>14</sup> + x<sup>5</sup> + 1*
* *x<sup>15</sup> + x + 1*
* *x<sup>16</sup> + x<sup>5</sup> + x<sup>3</sup> + x + 1*
* *x<sup>17</sup> + x<sup>3</sup> + 1*
* *x<sup>18</sup> + x<sup>3</sup> + 1*
* *x<sup>19</sup> + x<sup>5</sup> + x<sup>2</sup> + x + 1*
* *x<sup>20</sup> + x<sup>3</sup> + 1*
* *x<sup>21</sup> + x<sup>2</sup> + 1*
* *x<sup>22</sup> + x + 1*
* *x<sup>23</sup> + x<sup>5</sup> + 1*
* *x<sup>24</sup> + x<sup>4</sup> + x<sup>3</sup> + x + 1*
* *x<sup>25</sup> + x<sup>3</sup> + 1*
* *x<sup>26</sup> + x<sup>4</sup> + x<sup>3</sup> + x + 1*
* *x<sup>27</sup> + x<sup>5</sup> + x<sup>2</sup> + x + 1*
* *x<sup>28</sup> + x + 1*
* *x<sup>29</sup> + x<sup>2</sup> + 1*
* *x<sup>30</sup> + x + 1*
* *x<sup>31</sup> + x<sup>3</sup> + 1*
* *x<sup>32</sup> + x<sup>7</sup> + x<sup>3</sup> + x<sup>2</sup> + 1*
* *x<sup>33</sup> + x<sup>10</sup> + 1*
* *x<sup>34</sup> + x<sup>7</sup> + 1*
* *x<sup>35</sup> + x<sup>2</sup> + 1*
* *x<sup>36</sup> + x<sup>9</sup> + 1*
* *x<sup>37</sup> + x<sup>6</sup> + x<sup>4</sup> + x + 1*
* *x<sup>38</sup> + x<sup>6</sup> + x<sup>5</sup> + x + 1*
* *x<sup>39</sup> + x<sup>4</sup> + 1*
* *x<sup>40</sup> + x<sup>5</sup> + x<sup>4</sup> + x<sup>3</sup> + 1*
* *x<sup>41</sup> + x<sup>3</sup> + 1*
* *x<sup>42</sup> + x<sup>7</sup> + 1*
* *x<sup>43</sup> + x<sup>6</sup> + x<sup>4</sup> + x<sup>3</sup> + 1*
* *x<sup>44</sup> + x<sup>5</sup> + 1*
* *x<sup>45</sup> + x<sup>4</sup> + x<sup>3</sup> + x + 1*
* *x<sup>46</sup> + x + 1*
* *x<sup>47</sup> + x<sup>5</sup> + 1*
* *x<sup>48</sup> + x<sup>5</sup> + x<sup>3</sup> + x<sup>2</sup> + 1*
* *x<sup>49</sup> + x<sup>9</sup> + 1*
* *x<sup>50</sup> + x<sup>4</sup> + x<sup>3</sup> + x<sup>2</sup> + 1*
* *x<sup>51</sup> + x<sup>6</sup> + x<sup>3</sup> + x + 1*
* *x<sup>52</sup> + x<sup>3</sup> + 1*
* *x<sup>53</sup> + x<sup>6</sup> + x<sup>2</sup> + x + 1*
* *x<sup>54</sup> + x<sup>9</sup> + 1*
* *x<sup>55</sup> + x<sup>7</sup> + 1*
* *x<sup>56</sup> + x<sup>7</sup> + x<sup>4</sup> + x<sup>2</sup> + 1*
* *x<sup>57</sup> + x<sup>4</sup> + 1*
* *x<sup>58</sup> + x<sup>19</sup> + 1*
* *x<sup>59</sup> + x<sup>7</sup> + x<sup>4</sup> + x<sup>2</sup> + 1*
* *x<sup>60</sup> + x + 1*
* *x<sup>61</sup> + x<sup>5</sup> + x<sup>2</sup> + x + 1*
* *x<sup>62</sup> + x<sup>29</sup> + 1*
* *x<sup>63</sup> + x + 1*
* *x<sup>64</sup> + x<sup>4</sup> + x<sup>3</sup> + x + 1*
