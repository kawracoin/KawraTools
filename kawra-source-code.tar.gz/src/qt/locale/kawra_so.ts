<TS version="2.1" language="so">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Right-click to edit address or label</source>
        <translation type="unfinished">Fadlan garaaci Midig ku dhufo si aad u saxdo ciwaanka ama sumadda.</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation type="unfinished">Fadhlan samee cinwaan cusub.</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation type="unfinished">Maqal</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation type="unfinished">Ka akhriso cinwaan aad xaqiijinaysay si aad u ku koobid natiijada isticmaalka ee nidaamka</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation type="unfinished">&amp;Fidi </translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation type="unfinished">C&amp;Lose</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation type="unfinished">Liiska ka tirtir cinwaanka hadda laga soo xulay</translation>
    </message>
    <message>
        <source>Enter address or label to search</source>
        <translation type="unfinished">Ku qor cinwaanka ama qoraalka si aad u raadiso</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation type="unfinished">Sida loo tababbardhigo qaabka loo takhasusay</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation type="unfinished">&amp; Dhoofinta</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation type="unfinished">&amp;Naxashka</translation>
    </message>
    <message>
        <source>Choose the address to send coins to</source>
        <translation type="unfinished">Dooro cinwaanka u dirto lacagta qadaadiicda ah si ay u</translation>
    </message>
    <message>
        <source>Choose the address to receive coins with</source>
        <translation type="unfinished">Dooro cinwaanka si aad u hesho lacagta qadaadiicda leh</translation>
    </message>
    <message>
        <source>C&amp;hoose</source>
        <translation type="unfinished">C&amp;Aagga</translation>
    </message>
    <message>
        <source>Sending addresses</source>
        <translation type="unfinished">Cinwaanada dirista</translation>
    </message>
    <message>
        <source>Receiving addresses</source>
        <translation type="unfinished">Cinwaanada qaabilaadda</translation>
    </message>
    <message>
        <source>These are your Kawra addresses for sending payments. Always check the amount and the receiving address before sending coins.</source>
        <translation type="unfinished">Kuwani waa cinwaanada Seeraar aad ku direyso lacagaha. Marwalba caddadka ama cinwaanka laga soo hubiyo inta aadan dirin lacagta qadaadiicda ah ka hor inta aadan dirin.</translation>
    </message>
    <message>
        <source>These are your Kawra addresses for receiving payments. Use the 'Create new receiving address' button in the receive tab to create new addresses.
Signing is only possible with addresses of the type 'legacy'.</source>
        <translation type="unfinished">Kuwani waa cinwaanada Seeraar in aad ku direyso lacagaha. Marwalba waxaa ka mid ah masuuliyiinta kubadda cagta ah ee hubinaya in ay ka soo horjeedaan tacaddiyadeeda, taas oo ay ku tallaabsato in ay ka qayb qaataan isbedelka taleemooyinka.</translation>
    </message>
    <message>
        <source>&amp;Copy Address</source>
        <translation type="unfinished">&amp; Nuqul Kabaha Cinwaanka</translation>
    </message>
    <message>
        <source>Copy &amp;Label</source>
        <translation type="unfinished">Nuqul &amp; Label</translation>
    </message>
    <message>
        <source>Export Address List</source>
        <translation type="unfinished">Liiska Cinwaanka Dhoofinta

</translation>
    </message>
    <message>
        <source>Comma separated file</source>
        <extracomment>Expanded name of the CSV file format. See: https://en.wikipedia.org/wiki/Comma-separated_values.</extracomment>
        <translation type="unfinished">Comma kala file</translation>
    </message>
    <message>
        <source>There was an error trying to save the address list to %1. Please try again.</source>
        <extracomment>An error message. %1 is a stand-in argument for the name of the file we attempted to save to.</extracomment>
        <translation type="unfinished">Waxaa jiray qalad isku dayaya in uu badbaadiyo liiska cinwaanka si. %1Iskuday mar kale.</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation type="unfinished">Dhoofinta Fashilmeen</translation>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Label</source>
        <translation type="unfinished">Marka</translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="unfinished">Cinwaanka</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(calaamad lahayn)</translation>
    </message>
</context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Enter passphrase</source>
        <translation type="unfinished">Gali Passphrase</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation type="unfinished">Ku celi passphrase cusub</translation>
    </message>
    <message>
        <source>Encrypt wallet</source>
        <translation type="unfinished">jeebka Encrypt</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation type="unfinished">Hawlgalkani wuxuu u baahan yahay jeebkaaga Passphrase jeebka si loo furo jeebka.</translation>
    </message>
    <message>
        <source>Unlock wallet</source>
        <translation type="unfinished">jeebka Unlock</translation>
    </message>
    <message>
        <source>Change passphrase</source>
        <translation type="unfinished">Isbedelka passphrase</translation>
    </message>
    <message>
        <source>Confirm wallet encryption</source>
        <translation type="unfinished">Xaqiiji encryption jeebka</translation>
    </message>
    <message>
        <source>Warning: If you encrypt your wallet and lose your passphrase, you will &lt;b&gt;LOSE ALL OF YOUR KAWRAS&lt;/b&gt;!</source>
        <translation type="unfinished">Digniin: Haddii aad qarisid jeebkaaga oo aad lumiso ereyga Passphrase, waxaad 1LOSE DOONAA DHAMMAAN KAWRAS1!</translation>
    </message>
    <message>
        <source>Are you sure you wish to encrypt your wallet?</source>
        <translation type="unfinished">Ma hubtaa in aad jeceshahay in aad jeebka sirta?</translation>
    </message>
    <message>
        <source>Enter the new passphrase for the wallet.&lt;br/&gt;Please use a passphrase of &lt;b&gt;ten or more random characters&lt;/b&gt;, or &lt;b&gt;eight or more words&lt;/b&gt;.</source>
        <translation type="unfinished">Ku qor passrase cusub jeebka.&lt;br/&gt;Fadlan isticmaal ereygii passphrase ah &lt;b&gt;toban ama in ka badan characters random&lt;/b&gt;ama&lt;b&gt;sideed ama kabadan&lt;/b&gt;.</translation>
    </message>
    <message>
        <source>Enter the old passphrase and new passphrase for the wallet.</source>
        <translation type="unfinished">sideed ula kacsan ama kabadan</translation>
    </message>
    <message>
        <source>Remember that encrypting your wallet cannot fully protect your kawras from being stolen by malware infecting your computer.</source>
        <translation type="unfinished">Xusuusnow in encrypting jeebka si buuxda ma uu ilaalin karo kawras aad ka xado by furin qaadsiinaya aad computer.</translation>
    </message>
    <message>
        <source>Wallet to be encrypted</source>
        <translation type="unfinished">Jeebka in la encrypted</translation>
    </message>
    <message>
        <source>Your wallet is about to be encrypted. </source>
        <translation type="unfinished">Jeebka in aan la xarriiqin</translation>
    </message>
    <message>
        <source>Your wallet is now encrypted. </source>
        <translation type="unfinished">Jeebkaaga hadda waa la xareeyay. </translation>
    </message>
    <message>
        <source>IMPORTANT: Any previous backups you have made of your wallet file should be replaced with the newly generated, encrypted wallet file. For security reasons, previous backups of the unencrypted wallet file will become useless as soon as you start using the new, encrypted wallet.</source>
        <translation type="unfinished">MUHIIM AH: Wixii gurmad ah ee hore ee aad ka samaysay faylkaaga jeebka waa in lagugu beddelaa faylka jeebka ee dhowaan la abuuray, faylka jeebka sirta ah. Sababo la xidhiidha amniga awgood, gurmadkii hore ee faylalka jeebka ee aan la gooyn ayaa noqon doona mid aan waxtar lahayn isla markaaba markaad bilowdo isticmaalka jeebka cusub ee la xarrimay.</translation>
    </message>
    <message>
        <source>Wallet encryption failed</source>
        <translation type="unfinished">encryption jeebka ku guuldareystay</translation>
    </message>
    <message>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation type="unfinished">Encryption jeebka way ku guuldareysteen qalad gudaha awgeed. Jeebkaaga lama sirtain.</translation>
    </message>
    <message>
        <source>The supplied passphrases do not match.</source>
        <translation type="unfinished">Supplied passrases ma u dhigma.</translation>
    </message>
    <message>
        <source>Wallet unlock failed</source>
        <translation type="unfinished">Wallet Unlock failed</translation>
    </message>
    <message>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation type="unfinished">Passrase soo galay for decryption jeebka ahaa mid khaldan.</translation>
    </message>
    <message>
        <source>Wallet passphrase was successfully changed.</source>
        <translation type="unfinished">Jeebka passphrase ayaa si guul leh loo bedelay.</translation>
    </message>
    <message>
        <source>Warning: The Caps Lock key is on!</source>
        <translation type="unfinished">Digniin: Furaha Lock Caps waa on!</translation>
    </message>
</context>
<context>
    <name>BanTableModel</name>
    <message>
        <source>IP/Netmask</source>
        <translation type="unfinished">IP / Netmask</translation>
    </message>
    <message>
        <source>Banned Until</source>
        <translation type="unfinished">Mamnuucay Ilaa</translation>
    </message>
</context>
<context>
    <name>KawraApplication</name>
    <message>
        <source>Settings file %1 might be corrupt or invalid.</source>
        <translation type="unfinished">Settings file,%1waxaa laga yaabaa in musuqmaasuq ama aan asal ahayn.</translation>
    </message>
    <message>
        <source>A fatal error occurred. %1 can no longer continue safely and will quit.</source>
        <translation type="unfinished">Waxaa dhacday qalad dilaa ah. %1 mar dambe si ammaan ah uma sii socon karo oo wuu ka tagi doonaa.</translation>
    </message>
    <message>
        <source>Internal error</source>
        <translation type="unfinished">Qalad gudaha ah</translation>
    </message>
    <message>
        <source>An internal error occurred. %1 will attempt to continue safely. This is an unexpected bug which can be reported as described below.</source>
        <translation type="unfinished">Qalad gudaha ah ayaa dhacay.%1isku dayi doonaan in ay si ammaan ah u sii socdaan. Kani waa cayil aan la filayn oo la soo sheegi karo sida hoos ku xusan.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Do you want to reset settings to default values, or to abort without making changes?</source>
        <extracomment>Explanatory text shown on startup when the settings file cannot be read. Prompts user to make a choice between resetting or aborting.</extracomment>
        <translation type="unfinished">Ma waxaad doonaysaa in aad dib u dejiso goobaha si aad u default qiyamka, ama aad iska xaaqdo adigoon isbeddelin?</translation>
    </message>
    <message>
        <source>A fatal error occurred. Check that settings file is writable, or try running with -nosettings.</source>
        <extracomment>Explanatory text shown on startup when the settings file could not be written. Prompts user to check that we have the ability to write to the file. Explains that the user has the option of running without a settings file.</extracomment>
        <translation type="unfinished">Waxaa dhacday qalad dilaa ah. Hubi in file settings waa writable, ama isku day inaad la -nosettings socda.</translation>
    </message>
    <message numerus="yes">
        <source>%n second(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n minute(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n hour(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n day(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n week(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n year(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    </context>
<context>
    <name>KawraGUI</name>
    <message numerus="yes">
        <source>Processed %n block(s) of transaction history.</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n active connection(s) to Kawra network.</source>
        <extracomment>A substring of the tooltip.</extracomment>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    </context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(calaamad lahayn)</translation>
    </message>
    </context>
<context>
    <name>Intro</name>
    <message numerus="yes">
        <source>%n GB of space available</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>(of %n GB needed)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>(%n GB needed for full chain)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>(sufficient to restore backups %n day(s) old)</source>
        <extracomment>Explanatory text on the capability of the current prune target.</extracomment>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    </context>
<context>
    <name>PeerTableModel</name>
    <message>
        <source>Address</source>
        <extracomment>Title of Peers Table column which contains the IP/Onion/I2P address of the connected peer.</extracomment>
        <translation type="unfinished">Cinwaanka</translation>
    </message>
    </context>
<context>
    <name>RecentRequestsTableModel</name>
    <message>
        <source>Label</source>
        <translation type="unfinished">Marka</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(calaamad lahayn)</translation>
    </message>
    </context>
<context>
    <name>SendCoinsDialog</name>
    <message numerus="yes">
        <source>Estimated to begin confirmation within %n block(s).</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(calaamad lahayn)</translation>
    </message>
</context>
<context>
    <name>TransactionDesc</name>
    <message numerus="yes">
        <source>matures in %n more block(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    </context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Label</source>
        <translation type="unfinished">Marka</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(calaamad lahayn)</translation>
    </message>
    </context>
<context>
    <name>TransactionView</name>
    <message>
        <source>Comma separated file</source>
        <extracomment>Expanded name of the CSV file format. See: https://en.wikipedia.org/wiki/Comma-separated_values.</extracomment>
        <translation type="unfinished">Comma kala file</translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished">Marka</translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="unfinished">Cinwaanka</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation type="unfinished">Dhoofinta Fashilmeen</translation>
    </message>
    </context>
<context>
    <name>WalletView</name>
    <message>
        <source>&amp;Export</source>
        <translation type="unfinished">&amp; Dhoofinta</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation type="unfinished">Sida loo tababbardhigo qaabka loo takhasusay</translation>
    </message>
    </context>
</TS>