<TS version="2.1" language="sw">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Right-click to edit address or label</source>
        <translation type="unfinished">Bonyeza kitufe cha kulia kufanya mabadiliko kwenye anuani au lebo</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation type="unfinished">Fungua anuani mpya</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation type="unfinished">&amp;Mpya</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation type="unfinished">Nakili anwani iliyochaguliwa sasa kwenye ubao wa kunakili wa mfumo</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation type="unfinished">&amp;nakili</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation type="unfinished">C&amp;Funga</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation type="unfinished">Futa anwani iliyochaguliwa sasa kutoka kwenye orodha</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation type="unfinished">&amp;Futa</translation>
    </message>
    <message>
        <source>Choose the address to send coins to</source>
        <translation type="unfinished">Chagua anwani ya kutuma sarafu</translation>
    </message>
    <message>
        <source>Choose the address to receive coins with</source>
        <translation type="unfinished">Chagua anwani ya kupokea sarafu</translation>
    </message>
    <message>
        <source>Sending addresses</source>
        <translation type="unfinished">Kutuma anuani</translation>
    </message>
    <message>
        <source>Receiving addresses</source>
        <translation type="unfinished">Kupokea anuani</translation>
    </message>
    <message>
        <source>These are your Kawra addresses for sending payments. Always check the amount and the receiving address before sending coins.</source>
        <translation type="unfinished">Hizi ndizo anwani zako za kutuma malipo ya sarafu ya Kawra. Hakikisha kila wakati kiwango na anwani ya kupokea kabla ya kutuma sarafu.</translation>
    </message>
    <message>
        <source>&amp;Copy Address</source>
        <translation type="unfinished">Nakili &amp;anwani</translation>
    </message>
    </context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Address</source>
        <translation type="unfinished">Anuani</translation>
    </message>
    </context>
<context>
    <name>QObject</name>
    <message numerus="yes">
        <source>%n second(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n minute(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n hour(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n day(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n week(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n year(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    </context>
<context>
    <name>KawraGUI</name>
    <message numerus="yes">
        <source>Processed %n block(s) of transaction history.</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n active connection(s) to Kawra network.</source>
        <extracomment>A substring of the tooltip.</extracomment>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    </context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Quantity:</source>
        <translation type="unfinished">Wingi</translation>
    </message>
    <message>
        <source>yes</source>
        <translation type="unfinished">ndio</translation>
    </message>
    <message>
        <source>no</source>
        <translation type="unfinished">La</translation>
    </message>
    </context>
<context>
    <name>FreespaceChecker</name>
    <message>
        <source>name</source>
        <translation type="unfinished">Jina</translation>
    </message>
    </context>
<context>
    <name>Intro</name>
    <message numerus="yes">
        <source>%n GB of space available</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>(of %n GB needed)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>(%n GB needed for full chain)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>(sufficient to restore backups %n day(s) old)</source>
        <extracomment>Explanatory text on the capability of the current prune target.</extracomment>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    </context>
<context>
    <name>PeerTableModel</name>
    <message>
        <source>Address</source>
        <extracomment>Title of Peers Table column which contains the IP/Onion/I2P address of the connected peer.</extracomment>
        <translation type="unfinished">Anuani</translation>
    </message>
    </context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Quantity:</source>
        <translation type="unfinished">Wingi</translation>
    </message>
    <message numerus="yes">
        <source>Estimated to begin confirmation within %n block(s).</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    </context>
<context>
    <name>TransactionDesc</name>
    <message numerus="yes">
        <source>matures in %n more block(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    </context>
<context>
    <name>TransactionView</name>
    <message>
        <source>Address</source>
        <translation type="unfinished">Anuani</translation>
    </message>
    </context>
</TS>