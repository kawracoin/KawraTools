<TS version="2.1" language="mg">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Create a new address</source>
        <translation type="unfinished">Mamorona adiresy vaovao</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation type="unfinished">&amp;Vaovao</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation type="unfinished">&amp;Adikao</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation type="unfinished">Fafao ao anaty lisitra ny adiresy voamarika</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation type="unfinished">&amp;Avoahy</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation type="unfinished">&amp;Fafao</translation>
    </message>
    <message>
        <source>Choose the address to send coins to</source>
        <translation type="unfinished">Fidio ny adiresy handefasana vola</translation>
    </message>
    <message>
        <source>Choose the address to receive coins with</source>
        <translation type="unfinished">Fidio ny adiresy handraisana vola</translation>
    </message>
    <message>
        <source>Sending addresses</source>
        <translation type="unfinished">Adiresy fandefasana</translation>
    </message>
    <message>
        <source>Receiving addresses</source>
        <translation type="unfinished">Adiresy fandraisana</translation>
    </message>
    <message>
        <source>These are your Kawra addresses for sending payments. Always check the amount and the receiving address before sending coins.</source>
        <translation type="unfinished">Ireto ny adiresy Kawra natokana handefasanao vola. Hamarino hatrany ny tarehimarika sy ny adiresy handefasana alohan'ny handefa vola.</translation>
    </message>
    <message>
        <source>&amp;Copy Address</source>
        <translation type="unfinished">&amp;Adikao ny Adiresy</translation>
    </message>
    </context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Address</source>
        <translation type="unfinished">Adiresy</translation>
    </message>
    </context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Enter passphrase</source>
        <translation type="unfinished">Ampidiro ny tenimiafina</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation type="unfinished">Tenimiafina vaovao</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation type="unfinished">Avereno ny tenimiafina vaovao</translation>
    </message>
    <message>
        <source>Show passphrase</source>
        <translation type="unfinished">Asehoy ny tenimiafina</translation>
    </message>
    <message>
        <source>Change passphrase</source>
        <translation type="unfinished">Ovay ny tenimiafina</translation>
    </message>
    </context>
<context>
    <name>QObject</name>
    <message numerus="yes">
        <source>%n second(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n minute(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n hour(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n day(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n week(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n year(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    </context>
<context>
    <name>KawraGUI</name>
    <message>
        <source>Create a new wallet</source>
        <translation type="unfinished">Hamorona kitapom-bola vaovao</translation>
    </message>
    <message>
        <source>Wallet:</source>
        <translation type="unfinished">Kitapom-bola:</translation>
    </message>
    <message>
        <source>&amp;Send</source>
        <translation type="unfinished">&amp;Handefa</translation>
    </message>
    <message>
        <source>&amp;Receive</source>
        <translation type="unfinished">&amp;Handray</translation>
    </message>
    <message>
        <source>&amp;Change Passphrase…</source>
        <translation type="unfinished">&amp;Ovay ny Tenimiafina...</translation>
    </message>
    <message>
        <source>Sign &amp;message…</source>
        <translation type="unfinished">Soniavo &amp;hafatra...</translation>
    </message>
    <message>
        <source>&amp;Verify message…</source>
        <translation type="unfinished">&amp;Hamarino hafatra...</translation>
    </message>
    <message>
        <source>Close Wallet…</source>
        <translation type="unfinished">Akatony ny Kitapom-bola...</translation>
    </message>
    <message>
        <source>Create Wallet…</source>
        <translation type="unfinished">Hamorona Kitapom-bola...</translation>
    </message>
    <message>
        <source>Close All Wallets…</source>
        <translation type="unfinished">Akatony ny Kitapom-bola Rehetra</translation>
    </message>
    <message numerus="yes">
        <source>Processed %n block(s) of transaction history.</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">Fahadisoana</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation type="unfinished">Fampitandremana</translation>
    </message>
    <message>
        <source>Information</source>
        <translation type="unfinished">Tsara ho fantatra</translation>
    </message>
    <message>
        <source>&amp;Sending addresses</source>
        <translation type="unfinished">&amp;Adiresy fandefasana</translation>
    </message>
    <message>
        <source>&amp;Receiving addresses</source>
        <translation type="unfinished">&amp;Adiresy fandraisana</translation>
    </message>
    <message>
        <source>Wallet Name</source>
        <extracomment>Label of the input field where the name of the wallet is entered.</extracomment>
        <translation type="unfinished">Anaran'ny Kitapom-bola</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation type="unfinished">Hangezao</translation>
    </message>
    <message>
        <source>&amp;Hide</source>
        <translation type="unfinished">&amp;Afeno</translation>
    </message>
    <message numerus="yes">
        <source>%n active connection(s) to Kawra network.</source>
        <extracomment>A substring of the tooltip.</extracomment>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    </context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Date</source>
        <translation type="unfinished">Daty</translation>
    </message>
    <message>
        <source>Confirmations</source>
        <translation type="unfinished">Fanamarinana</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation type="unfinished">Voamarina</translation>
    </message>
    <message>
        <source>&amp;Copy address</source>
        <translation type="unfinished">&amp;Adikao ny adiresy</translation>
    </message>
    <message>
        <source>yes</source>
        <translation type="unfinished">eny</translation>
    </message>
    <message>
        <source>no</source>
        <translation type="unfinished">tsia</translation>
    </message>
    </context>
<context>
    <name>CreateWalletActivity</name>
    <message>
        <source>Create Wallet</source>
        <extracomment>Title of window indicating the progress of creation of a new wallet.</extracomment>
        <translation type="unfinished">Hamorona Kitapom-bola</translation>
    </message>
    </context>
<context>
    <name>CreateWalletDialog</name>
    <message>
        <source>Create Wallet</source>
        <translation type="unfinished">Hamorona Kitapom-bola</translation>
    </message>
    <message>
        <source>Wallet Name</source>
        <translation type="unfinished">Anaran'ny Kitapom-bola</translation>
    </message>
    <message>
        <source>Wallet</source>
        <translation type="unfinished">Kitapom-bola</translation>
    </message>
    <message>
        <source>Create</source>
        <translation type="unfinished">Mamorona</translation>
    </message>
    </context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation type="unfinished">Hanova Adiresy</translation>
    </message>
    <message>
        <source>&amp;Address</source>
        <translation type="unfinished">&amp;Adiresy</translation>
    </message>
    <message>
        <source>New sending address</source>
        <translation type="unfinished">Adiresy fandefasana vaovao</translation>
    </message>
    <message>
        <source>Edit receiving address</source>
        <translation type="unfinished">Hanova adiresy fandraisana</translation>
    </message>
    <message>
        <source>Edit sending address</source>
        <translation type="unfinished">Hanova adiresy fandefasana</translation>
    </message>
    </context>
<context>
    <name>Intro</name>
    <message numerus="yes">
        <source>%n GB of space available</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>(of %n GB needed)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>(%n GB needed for full chain)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>(sufficient to restore backups %n day(s) old)</source>
        <extracomment>Explanatory text on the capability of the current prune target.</extracomment>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">Fahadisoana</translation>
    </message>
    </context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Error</source>
        <translation type="unfinished">Fahadisoana</translation>
    </message>
    </context>
<context>
    <name>PeerTableModel</name>
    <message>
        <source>Address</source>
        <extracomment>Title of Peers Table column which contains the IP/Onion/I2P address of the connected peer.</extracomment>
        <translation type="unfinished">Adiresy</translation>
    </message>
    </context>
<context>
    <name>RPCConsole</name>
    <message>
        <source>&amp;Copy address</source>
        <extracomment>Context menu action to copy the address of a peer.</extracomment>
        <translation type="unfinished">&amp;Adikao ny adiresy</translation>
    </message>
    </context>
<context>
    <name>ReceiveCoinsDialog</name>
    <message>
        <source>&amp;Copy address</source>
        <translation type="unfinished">&amp;Adikao ny adiresy</translation>
    </message>
    </context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>Wallet:</source>
        <translation type="unfinished">Kitapom-bola:</translation>
    </message>
    </context>
<context>
    <name>RecentRequestsTableModel</name>
    <message>
        <source>Date</source>
        <translation type="unfinished">Daty</translation>
    </message>
    </context>
<context>
    <name>SendCoinsDialog</name>
    <message numerus="yes">
        <source>Estimated to begin confirmation within %n block(s).</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    </context>
<context>
    <name>TransactionDesc</name>
    <message>
        <source>Date</source>
        <translation type="unfinished">Daty</translation>
    </message>
    <message numerus="yes">
        <source>matures in %n more block(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    </context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Date</source>
        <translation type="unfinished">Daty</translation>
    </message>
    </context>
<context>
    <name>TransactionView</name>
    <message>
        <source>&amp;Copy address</source>
        <translation type="unfinished">&amp;Adikao ny adiresy</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation type="unfinished">Voamarina</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished">Daty</translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="unfinished">Adiresy</translation>
    </message>
    </context>
<context>
    <name>WalletFrame</name>
    <message>
        <source>Create a new wallet</source>
        <translation type="unfinished">Hamorona kitapom-bola vaovao</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">Fahadisoana</translation>
    </message>
    </context>
<context>
    <name>WalletView</name>
    <message>
        <source>&amp;Export</source>
        <translation type="unfinished">&amp;Avoahy</translation>
    </message>
    </context>
</TS>