<TS version="2.1" language="szl">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Right-click to edit address or label</source>
        <translation type="unfinished">Kliknij prawy knefel mysze, coby edytować adresã abo etyketã</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation type="unfinished">Zrychtuj nowõ adresã</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation type="unfinished">&amp;Nowy</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation type="unfinished">Skopiyruj aktualnie ôbranõ adresã do skrytki</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation type="unfinished">&amp;Kopiyruj</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation type="unfinished">&amp;Zawrzij</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation type="unfinished">Wychrōń zaznaczōnõ adresã z brify</translation>
    </message>
    <message>
        <source>Enter address or label to search</source>
        <translation type="unfinished">Wkludź adresã abo etyketã coby wyszukać</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation type="unfinished">Eksportuj dane z aktywnyj szkarty do zbioru</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation type="unfinished">&amp;Eksportuj</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation type="unfinished">&amp;Wychrōń</translation>
    </message>
    <message>
        <source>Choose the address to send coins to</source>
        <translation type="unfinished">Ôbier adresã, na kerõ chcesz posłać mōnety</translation>
    </message>
    <message>
        <source>Choose the address to receive coins with</source>
        <translation type="unfinished">Ôbier adresã, na kerõ chcesz dostać mōnety</translation>
    </message>
    <message>
        <source>C&amp;hoose</source>
        <translation type="unfinished">Ô&amp;bier</translation>
    </message>
    <message>
        <source>Sending addresses</source>
        <translation type="unfinished">Adresy posyłaniŏ</translation>
    </message>
    <message>
        <source>Receiving addresses</source>
        <translation type="unfinished">Adresy ôdbiyraniŏ</translation>
    </message>
    <message>
        <source>These are your Kawra addresses for sending payments. Always check the amount and the receiving address before sending coins.</source>
        <translation type="unfinished">Tukej sōm adresy Kawra na kere posyłŏsz płaty. Dycki wybaduj wielość i adresã ôdbiyrŏcza przed posłaniym mōnet.</translation>
    </message>
    <message>
        <source>&amp;Copy Address</source>
        <translation type="unfinished">&amp;Kopiyruj Adresã</translation>
    </message>
    <message>
        <source>Copy &amp;Label</source>
        <translation type="unfinished">Kopiyruj &amp;Etyketã</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation type="unfinished">&amp;Edytuj</translation>
    </message>
    <message>
        <source>Export Address List</source>
        <translation type="unfinished">Eksportuj wykŏz adres</translation>
    </message>
    <message>
        <source>There was an error trying to save the address list to %1. Please try again.</source>
        <extracomment>An error message. %1 is a stand-in argument for the name of the file we attempted to save to.</extracomment>
        <translation type="unfinished">Przitrefiōł sie feler w czasie spamiyntowaniŏ brify adres do %1. Proszã sprōbować zaś.</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation type="unfinished">Eksportowanie niy podarziło sie</translation>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Label</source>
        <translation type="unfinished">Etyketa</translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="unfinished">Adresa</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(chyba etykety)</translation>
    </message>
</context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Passphrase Dialog</source>
        <translation type="unfinished">Ôkiynko Hasła</translation>
    </message>
    <message>
        <source>Enter passphrase</source>
        <translation type="unfinished">Wkludź hasło</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation type="unfinished">Nowe hasło</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation type="unfinished">Powtōrz nowe hasło</translation>
    </message>
    <message>
        <source>Encrypt wallet</source>
        <translation type="unfinished">Zaszyfruj portmanyj</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation type="unfinished">Ta ôperacyjŏ wymŏgŏ hasła do portmanyja coby ôdszperować portmanyj.</translation>
    </message>
    <message>
        <source>Unlock wallet</source>
        <translation type="unfinished">Ôdszperuj portmanyj.</translation>
    </message>
    <message>
        <source>Change passphrase</source>
        <translation type="unfinished">Pōmiyń hasło</translation>
    </message>
    <message>
        <source>Confirm wallet encryption</source>
        <translation type="unfinished">Przituplikuj szyfrowanie portmanyja</translation>
    </message>
    <message>
        <source>Warning: If you encrypt your wallet and lose your passphrase, you will &lt;b&gt;LOSE ALL OF YOUR KAWRAS&lt;/b&gt;!</source>
        <translation type="unfinished">Pozōr: jeźli zaszyfrujesz swōj portmanyj i stracisz hasło &lt;b&gt;STRACISZ WSZYJSKE SWOJE KAWRAY&lt;/b&gt;!</translation>
    </message>
    <message>
        <source>Are you sure you wish to encrypt your wallet?</source>
        <translation type="unfinished">Na isto chcesz zaszyfrować swōj portmanyj?</translation>
    </message>
    <message>
        <source>Wallet encrypted</source>
        <translation type="unfinished">Portmanyj zaszyfrowany</translation>
    </message>
    <message>
        <source>IMPORTANT: Any previous backups you have made of your wallet file should be replaced with the newly generated, encrypted wallet file. For security reasons, previous backups of the unencrypted wallet file will become useless as soon as you start using the new, encrypted wallet.</source>
        <translation type="unfinished">WŎŻNE: Wszyjske wykōnane wczaśnij kopije zbioru portmanyja winny być umiyniōne na nowe, szyfrowane zbiory. Z powodōw bezpiyczyństwa, piyrwyjsze kopije niyszyfrowanych zbiorōw portmanyja stōnõ sie bezużyteczne jak ino zaczniesz używać nowego, szyfrowanego portmanyja.</translation>
    </message>
    <message>
        <source>Wallet encryption failed</source>
        <translation type="unfinished">Zaszyfrowanie portmanyja niy podarziło sie</translation>
    </message>
    <message>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation type="unfinished">Zaszyfrowanie portmanyja niy podarziło sie bez wnyntrzny feler. Twōj portmanyj niy ôstoł zaszyfrowany.</translation>
    </message>
    <message>
        <source>The supplied passphrases do not match.</source>
        <translation type="unfinished">Podane hasła niy sōm take same.</translation>
    </message>
    <message>
        <source>Wallet unlock failed</source>
        <translation type="unfinished">Ôdszperowanie portmanyja niy podarziło sie</translation>
    </message>
    <message>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation type="unfinished">Wkludzōne hasło do ôdszyfrowaniŏ portmanyja je niynŏleżne.</translation>
    </message>
    <message>
        <source>Wallet passphrase was successfully changed.</source>
        <translation type="unfinished">Hasło do portmanyja ôstało sprŏwnie pōmiyniōne.</translation>
    </message>
    <message>
        <source>Warning: The Caps Lock key is on!</source>
        <translation type="unfinished">Pozōr: Caps Lock je zapuszczōny!</translation>
    </message>
</context>
<context>
    <name>BanTableModel</name>
    <message>
        <source>IP/Netmask</source>
        <translation type="unfinished">IP/Maska necu</translation>
    </message>
    <message>
        <source>Banned Until</source>
        <translation type="unfinished">Szpera do</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Error: %1</source>
        <translation type="unfinished">Feler: %1</translation>
    </message>
    <message>
        <source>unknown</source>
        <translation type="unfinished">niyznōme</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">Kwota</translation>
    </message>
    <message>
        <source>Enter a Kawra address (e.g. %1)</source>
        <translation type="unfinished">Wkludź adresã Kawra (bp. %1)</translation>
    </message>
    <message>
        <source>Inbound</source>
        <extracomment>An inbound connection from a peer. An inbound connection is a connection initiated by a peer.</extracomment>
        <translation type="unfinished">Wchodowy</translation>
    </message>
    <message>
        <source>Outbound</source>
        <extracomment>An outbound connection to a peer. An outbound connection is a connection initiated by us.</extracomment>
        <translation type="unfinished">Wychodowy</translation>
    </message>
    <message numerus="yes">
        <source>%n second(s)</source>
        <translation type="unfinished">
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n minute(s)</source>
        <translation type="unfinished">
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n hour(s)</source>
        <translation type="unfinished">
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n day(s)</source>
        <translation type="unfinished">
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n week(s)</source>
        <translation type="unfinished">
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n year(s)</source>
        <translation type="unfinished">
            <numerusform />
        </translation>
    </message>
    </context>
<context>
    <name>KawraGUI</name>
    <message>
        <source>&amp;Overview</source>
        <translation type="unfinished">&amp;Podsumowanie</translation>
    </message>
    <message>
        <source>Show general overview of wallet</source>
        <translation type="unfinished">Pokazuje ôgōlny widok portmanyja</translation>
    </message>
    <message>
        <source>&amp;Transactions</source>
        <translation type="unfinished">&amp;Transakcyje</translation>
    </message>
    <message>
        <source>Browse transaction history</source>
        <translation type="unfinished">Przeglōndej historyjõ transakcyji</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation type="unfinished">&amp;Zakōńcz</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation type="unfinished">Zawrzij aplikacyjõ</translation>
    </message>
    <message>
        <source>&amp;About %1</source>
        <translation type="unfinished">&amp;Ô %1</translation>
    </message>
    <message>
        <source>Show information about %1</source>
        <translation type="unfinished">Pokŏż informacyje ô %1</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation type="unfinished">Ô &amp;Qt</translation>
    </message>
    <message>
        <source>Show information about Qt</source>
        <translation type="unfinished">Pokŏż informacyje ô Qt</translation>
    </message>
    <message>
        <source>Modify configuration options for %1</source>
        <translation type="unfinished">Zmiyń ôpcyje kōnfiguracyje dlŏ %1</translation>
    </message>
    <message>
        <source>Wallet:</source>
        <translation type="unfinished">Portmanyj:</translation>
    </message>
    <message>
        <source>Network activity disabled.</source>
        <extracomment>A substring of the tooltip.</extracomment>
        <translation type="unfinished">Aktywność necowŏ ôstała zastawiōnŏ.</translation>
    </message>
    <message>
        <source>Proxy is &lt;b&gt;enabled&lt;/b&gt;: %1</source>
        <translation type="unfinished">Proxy je &lt;b&gt;zapuszczone&lt;/b&gt;: %1</translation>
    </message>
    <message>
        <source>Send coins to a Kawra address</source>
        <translation type="unfinished">Poślij mōnety na adresã Kawra</translation>
    </message>
    <message>
        <source>Backup wallet to another location</source>
        <translation type="unfinished">Ibryczny portmanyj w inkszyj lokalizacyje</translation>
    </message>
    <message>
        <source>Change the passphrase used for wallet encryption</source>
        <translation type="unfinished">Pōmiyń hasło użyte do szyfrowaniŏ portmanyja</translation>
    </message>
    <message>
        <source>&amp;Send</source>
        <translation type="unfinished">&amp;Poślij</translation>
    </message>
    <message>
        <source>&amp;Receive</source>
        <translation type="unfinished">Ôd&amp;bier</translation>
    </message>
    <message>
        <source>Encrypt the private keys that belong to your wallet</source>
        <translation type="unfinished">Szyfruj klucze prywatne, kere sōm we twojim portmanyju</translation>
    </message>
    <message>
        <source>Sign messages with your Kawra addresses to prove you own them</source>
        <translation type="unfinished">Podpisz wiadōmości swojōm adresōm coby dowiyść jejich posiadanie</translation>
    </message>
    <message>
        <source>Verify messages to ensure they were signed with specified Kawra addresses</source>
        <translation type="unfinished">Zweryfikuj wiadōmość, coby wejzdrzeć sie, iże ôstała podpisanŏ podanōm adresōm Kawra.</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation type="unfinished">&amp;Zbiōr</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation type="unfinished">&amp;Nasztalowania</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation type="unfinished">Pō&amp;moc</translation>
    </message>
    <message>
        <source>Tabs toolbar</source>
        <translation type="unfinished">Lajsta szkart</translation>
    </message>
    <message>
        <source>Request payments (generates QR codes and kawra: URIs)</source>
        <translation type="unfinished">Żōndej płatu (gyneruje kod QR jak tyż URI kawra:)</translation>
    </message>
    <message>
        <source>Show the list of used sending addresses and labels</source>
        <translation type="unfinished">Pokŏż wykŏz adres i etyket użytych do posyłaniŏ</translation>
    </message>
    <message>
        <source>Show the list of used receiving addresses and labels</source>
        <translation type="unfinished">Pokŏż wykŏz adres i etyket użytych do ôdbiyraniŏ</translation>
    </message>
    <message>
        <source>&amp;Command-line options</source>
        <translation type="unfinished">Ôp&amp;cyje piski nakŏzań</translation>
    </message>
    <message numerus="yes">
        <source>Processed %n block(s) of transaction history.</source>
        <translation type="unfinished">
            <numerusform />
        </translation>
    </message>
    <message>
        <source>%1 behind</source>
        <translation type="unfinished">%1 za</translation>
    </message>
    <message>
        <source>Last received block was generated %1 ago.</source>
        <translation type="unfinished">Ôstatni dostany blok ôstoł wygynerowany %1 tymu.</translation>
    </message>
    <message>
        <source>Transactions after this will not yet be visible.</source>
        <translation type="unfinished">Transakcyje po tym mōmyncie niy bydōm jeszcze widzialne.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">Feler</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation type="unfinished">Pozōr</translation>
    </message>
    <message>
        <source>Information</source>
        <translation type="unfinished">Informacyjŏ</translation>
    </message>
    <message>
        <source>Up to date</source>
        <translation type="unfinished">Terŏźny</translation>
    </message>
    <message>
        <source>&amp;Sending addresses</source>
        <translation type="unfinished">&amp;Adresy posyłaniŏ</translation>
    </message>
    <message>
        <source>Show the %1 help message to get a list with possible Kawra command-line options</source>
        <translation type="unfinished">Pokŏż pōmoc %1 coby zobŏczyć wykŏz wszyjskich ôpcyji piski nakŏzań.</translation>
    </message>
    <message>
        <source>default wallet</source>
        <translation type="unfinished">wychodny portmanyj</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation type="unfinished">Ô&amp;kno</translation>
    </message>
    <message>
        <source>%1 client</source>
        <translation type="unfinished">%1 klijynt</translation>
    </message>
    <message numerus="yes">
        <source>%n active connection(s) to Kawra network.</source>
        <extracomment>A substring of the tooltip.</extracomment>
        <translation type="unfinished">
            <numerusform />
        </translation>
    </message>
    <message>
        <source>Error: %1</source>
        <translation type="unfinished">Feler: %1</translation>
    </message>
    <message>
        <source>Date: %1
</source>
        <translation type="unfinished">Datōm: %1
</translation>
    </message>
    <message>
        <source>Amount: %1
</source>
        <translation type="unfinished">Kwota: %1
</translation>
    </message>
    <message>
        <source>Wallet: %1
</source>
        <translation type="unfinished">Portmanyj: %1
</translation>
    </message>
    <message>
        <source>Type: %1
</source>
        <translation type="unfinished">Zorta: %1
</translation>
    </message>
    <message>
        <source>Label: %1
</source>
        <translation type="unfinished">Etyketa: %1
</translation>
    </message>
    <message>
        <source>Address: %1
</source>
        <translation type="unfinished">Adresa: %1
</translation>
    </message>
    <message>
        <source>Sent transaction</source>
        <translation type="unfinished">Transakcyjŏ wysłanŏ</translation>
    </message>
    <message>
        <source>Incoming transaction</source>
        <translation type="unfinished">Transakcyjŏ przichodzōncŏ</translation>
    </message>
    <message>
        <source>HD key generation is &lt;b&gt;enabled&lt;/b&gt;</source>
        <translation type="unfinished">Gynerowanie kluczy HD je &lt;b&gt;zapuszczone&lt;/b&gt;</translation>
    </message>
    <message>
        <source>HD key generation is &lt;b&gt;disabled&lt;/b&gt;</source>
        <translation type="unfinished">Gynerowanie kluczy HD je &lt;b&gt;zastawiōne&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation type="unfinished">Portmanyj je &lt;b&gt;zaszyfrowany&lt;/b&gt; i terŏźnie &lt;b&gt;ôdszperowany&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation type="unfinished">Portmanyj je &lt;b&gt;zaszyfrowany&lt;/b&gt; i terŏźnie &lt;b&gt;zaszperowany&lt;/b&gt;</translation>
    </message>
    </context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Coin Selection</source>
        <translation type="unfinished">Ôbiōr mōnet</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation type="unfinished">Wielość:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation type="unfinished">Bajtōw:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation type="unfinished">Kwota:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation type="unfinished">Ôpłŏcka:</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation type="unfinished">Sztaub:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation type="unfinished">Po ôpłŏcce:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation type="unfinished">Wydŏwka:</translation>
    </message>
    <message>
        <source>(un)select all</source>
        <translation type="unfinished">Zaznacz/Ôdznacz wszyjsko</translation>
    </message>
    <message>
        <source>Tree mode</source>
        <translation type="unfinished">Tryb strōma</translation>
    </message>
    <message>
        <source>List mode</source>
        <translation type="unfinished">Tryb wykŏzu</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">Kwota</translation>
    </message>
    <message>
        <source>Received with label</source>
        <translation type="unfinished">Ôdebrane z etyketōm</translation>
    </message>
    <message>
        <source>Received with address</source>
        <translation type="unfinished">Ôdebrane z adresōm</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished">Datōm</translation>
    </message>
    <message>
        <source>Confirmations</source>
        <translation type="unfinished">Przituplowania</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation type="unfinished">Przituplowany</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation type="unfinished">Kopiyruj kwotã</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation type="unfinished">Kopiyruj wielość</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation type="unfinished">Kopiyruj ôpłŏckã</translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation type="unfinished">Kopiyruj wielość po ôpłŏcce</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation type="unfinished">Kopiyruj wielość bajtōw</translation>
    </message>
    <message>
        <source>Copy dust</source>
        <translation type="unfinished">Kopiyruj sztaub</translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation type="unfinished">Kopiyruj wydŏwkã</translation>
    </message>
    <message>
        <source>(%1 locked)</source>
        <translation type="unfinished">(%1 zaszperowane)</translation>
    </message>
    <message>
        <source>yes</source>
        <translation type="unfinished">ja</translation>
    </message>
    <message>
        <source>no</source>
        <translation type="unfinished">niy</translation>
    </message>
    <message>
        <source>This label turns red if any recipient receives an amount smaller than the current dust threshold.</source>
        <translation type="unfinished">Ta etyketa stŏwŏ sie czyrwōnŏ jeźli keryś z ôdbiyrŏczy dostŏwŏ kwotã myńszõ aniżeli terŏźny prōg sztaubu.</translation>
    </message>
    <message>
        <source>Can vary +/- %1 satoshi(s) per input.</source>
        <translation type="unfinished">Chwiyrŏ sie +/- %1 satoshi na wchōd.</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(chyba etykety)</translation>
    </message>
    <message>
        <source>change from %1 (%2)</source>
        <translation type="unfinished">wydŏwka z %1 (%2)</translation>
    </message>
    <message>
        <source>(change)</source>
        <translation type="unfinished">(wydŏwka)</translation>
    </message>
</context>
<context>
    <name>OpenWalletActivity</name>
    <message>
        <source>default wallet</source>
        <translation type="unfinished">wychodny portmanyj</translation>
    </message>
    </context>
<context>
    <name>CreateWalletDialog</name>
    <message>
        <source>Wallet</source>
        <translation type="unfinished">Portmanyj</translation>
    </message>
    </context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation type="unfinished">Edytuj adresã</translation>
    </message>
    <message>
        <source>&amp;Label</source>
        <translation type="unfinished">&amp;Etyketa</translation>
    </message>
    <message>
        <source>The label associated with this address list entry</source>
        <translation type="unfinished">Etyketa ôbwiōnzanŏ z tym wpisym na wykŏzie adres</translation>
    </message>
    <message>
        <source>The address associated with this address list entry. This can only be modified for sending addresses.</source>
        <translation type="unfinished">Ta adresa je ôbwiōnzanŏ z wpisym na wykŏzie adres. Może być zmodyfikowany jyno dlŏ adres posyłajōncych.</translation>
    </message>
    <message>
        <source>&amp;Address</source>
        <translation type="unfinished">&amp;Adresa</translation>
    </message>
    <message>
        <source>New sending address</source>
        <translation type="unfinished">Nowŏ adresa posyłaniŏ</translation>
    </message>
    <message>
        <source>Edit receiving address</source>
        <translation type="unfinished">Edytuj adresã ôdbiōru</translation>
    </message>
    <message>
        <source>Edit sending address</source>
        <translation type="unfinished">Edytuj adresã posyłaniŏ</translation>
    </message>
    <message>
        <source>The entered address "%1" is not a valid Kawra address.</source>
        <translation type="unfinished">Wkludzōnŏ adresa "%1" niyma nŏleżnōm adresōm Kawra.</translation>
    </message>
    <message>
        <source>Address "%1" already exists as a receiving address with label "%2" and so cannot be added as a sending address.</source>
        <translation type="unfinished">Adresa "%1" już je za adresã ôdbiorczõ z etyketōm "%2" i bez to niy idzie jeji przidać za adresã nadŏwcy.</translation>
    </message>
    <message>
        <source>The entered address "%1" is already in the address book with label "%2".</source>
        <translation type="unfinished">Wkludzōnŏ adresa "%1" już je w ksiōnżce adres z ôpisym "%2".</translation>
    </message>
    <message>
        <source>Could not unlock wallet.</source>
        <translation type="unfinished">Niy idzie było ôdszperować portmanyja.</translation>
    </message>
    <message>
        <source>New key generation failed.</source>
        <translation type="unfinished">Gynerowanie nowego klucza niy podarziło sie.</translation>
    </message>
</context>
<context>
    <name>FreespaceChecker</name>
    <message>
        <source>A new data directory will be created.</source>
        <translation type="unfinished">Bydzie zrychtowany nowy folder danych.</translation>
    </message>
    <message>
        <source>name</source>
        <translation type="unfinished">miano</translation>
    </message>
    <message>
        <source>Directory already exists. Add %1 if you intend to create a new directory here.</source>
        <translation type="unfinished">Katalog już je. Przidej %1 jeźli mŏsz zastrojynie zrychtować tukej nowy katalog.</translation>
    </message>
    <message>
        <source>Cannot create data directory here.</source>
        <translation type="unfinished">Niy idzie było tukej zrychtować folderu datōw.</translation>
    </message>
</context>
<context>
    <name>Intro</name>
    <message numerus="yes">
        <source>%n GB of space available</source>
        <translation type="unfinished">
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>(of %n GB needed)</source>
        <translation type="unfinished">
            <numerusform>(z %n GB przidajnego)</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>(%n GB needed for full chain)</source>
        <translation type="unfinished">
            <numerusform />
        </translation>
    </message>
    <message>
        <source>At least %1 GB of data will be stored in this directory, and it will grow over time.</source>
        <translation type="unfinished">Co nojmynij %1 GB datōw ôstanie spamiyntane w tym katalogu, daty te bydōm z czasym corŏz srogsze.</translation>
    </message>
    <message>
        <source>Approximately %1 GB of data will be stored in this directory.</source>
        <translation type="unfinished">Kole %1 GB datōw ôstanie spamiyntane w tym katalogu.</translation>
    </message>
    <message numerus="yes">
        <source>(sufficient to restore backups %n day(s) old)</source>
        <extracomment>Explanatory text on the capability of the current prune target.</extracomment>
        <translation type="unfinished">
            <numerusform />
        </translation>
    </message>
    <message>
        <source>%1 will download and store a copy of the Kawra block chain.</source>
        <translation type="unfinished">%1 sebiere i spamiyntŏ kopijõ kety blokōw Kawra.</translation>
    </message>
    <message>
        <source>The wallet will also be stored in this directory.</source>
        <translation type="unfinished">Portmanyj tyż ôstanie spamiyntany w tym katalogu.</translation>
    </message>
    <message>
        <source>Error: Specified data directory "%1" cannot be created.</source>
        <translation type="unfinished">Feler: podany folder datōw "%1" niy mōg ôstać zrychtowany.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">Feler</translation>
    </message>
    <message>
        <source>Welcome</source>
        <translation type="unfinished">Witej</translation>
    </message>
    <message>
        <source>Welcome to %1.</source>
        <translation type="unfinished">Witej w %1.</translation>
    </message>
    <message>
        <source>As this is the first time the program is launched, you can choose where %1 will store its data.</source>
        <translation type="unfinished">Pōniywŏż je to piyrsze sztartniyńcie programu, możesz ôbrać kaj %1 bydzie spamiyntować swoje daty.</translation>
    </message>
    <message>
        <source>This initial synchronisation is very demanding, and may expose hardware problems with your computer that had previously gone unnoticed. Each time you run %1, it will continue downloading where it left off.</source>
        <translation type="unfinished">Wstympnŏ synchrōnizacyjŏ je barzo wymŏgajōncŏ i może wyzdradzić wczaśnij niyzaôbserwowane niyprzileżytości sprzyntowe. Za kożdym sztartniyńciym %1 sebiyranie bydzie kōntynuowane ôd placu w kerym ôstało zastawiōne.</translation>
    </message>
    <message>
        <source>If you have chosen to limit block chain storage (pruning), the historical data must still be downloaded and processed, but will be deleted afterward to keep your disk usage low.</source>
        <translation type="unfinished">Jeźli ôbrołś ôpcyjõ ukrōcyniŏ spamiyntowaniŏ kety blokōw (przicinanie) daty historyczne cołki czas bydōm musiały być sebrane i przetworzōne, jednak po tym ôstanõ wychrōniōne coby ôgraniczyć użycie dysku.</translation>
    </message>
    <message>
        <source>Use the default data directory</source>
        <translation type="unfinished">Użyj wychodnego folderu datōw</translation>
    </message>
    <message>
        <source>Use a custom data directory:</source>
        <translation type="unfinished">Użyj ôbranego folderu datōw</translation>
    </message>
</context>
<context>
    <name>HelpMessageDialog</name>
    <message>
        <source>version</source>
        <translation type="unfinished">wersyjŏ</translation>
    </message>
    <message>
        <source>About %1</source>
        <translation type="unfinished">Ô %1</translation>
    </message>
    <message>
        <source>Command-line options</source>
        <translation type="unfinished">Ôpcyje piski nakŏzań</translation>
    </message>
</context>
<context>
    <name>ModalOverlay</name>
    <message>
        <source>Form</source>
        <translation type="unfinished">Formular</translation>
    </message>
    <message>
        <source>Recent transactions may not yet be visible, and therefore your wallet's balance might be incorrect. This information will be correct once your wallet has finished synchronizing with the kawra network, as detailed below.</source>
        <translation type="unfinished">Świyże transakcyje mogōm niy być jeszcze widzialne, a tedyć saldo portmanyja może być niynŏleżne. Te detale bydōm nŏleżne, kej portmanyj zakōńczy synchrōnizacyjõ z necym kawra, zgodnie z miyniōnym ôpisym.</translation>
    </message>
    <message>
        <source>Attempting to spend kawras that are affected by not-yet-displayed transactions will not be accepted by the network.</source>
        <translation type="unfinished">Prōba wydaniŏ kawraōw kere niy sōm jeszcze wyświytlōne za transakcyjŏ ôstanie ôdciepniyntŏ bez nec.</translation>
    </message>
    <message>
        <source>Number of blocks left</source>
        <translation type="unfinished">Ôstało blokōw</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation type="unfinished">Czas ôstatnigo bloku</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation type="unfinished">Postymp</translation>
    </message>
    <message>
        <source>Progress increase per hour</source>
        <translation type="unfinished">Przirost postympu na godzinã</translation>
    </message>
    <message>
        <source>Estimated time left until synced</source>
        <translation type="unfinished">Przewidowany czŏs abszlusu synchrōnizacyje</translation>
    </message>
    <message>
        <source>Hide</source>
        <translation type="unfinished">Skryj</translation>
    </message>
    </context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation type="unfinished">Ôpcyje</translation>
    </message>
    <message>
        <source>&amp;Main</source>
        <translation type="unfinished">&amp;Bazowe</translation>
    </message>
    <message>
        <source>Automatically start %1 after logging in to the system.</source>
        <translation type="unfinished">Autōmatycznie sztartnij %1 po wlogowaniu do systymu.</translation>
    </message>
    <message>
        <source>&amp;Start %1 on system login</source>
        <translation type="unfinished">&amp;Sztartuj %1 w czasie logowaniŏ do systymu</translation>
    </message>
    <message>
        <source>Size of &amp;database cache</source>
        <translation type="unfinished">Srogość bufōra bazy datōw</translation>
    </message>
    <message>
        <source>Number of script &amp;verification threads</source>
        <translation type="unfinished">Wielość wōntkōw &amp;weryfikacyje skryptu</translation>
    </message>
    <message>
        <source>IP address of the proxy (e.g. IPv4: 127.0.0.1 / IPv6: ::1)</source>
        <translation type="unfinished">Adresa IP proxy (bp. IPv4: 127.0.0.1 / IPv6: ::1)</translation>
    </message>
    <message>
        <source>Minimize instead of exit the application when the window is closed. When this option is enabled, the application will be closed only after selecting Exit in the menu.</source>
        <translation type="unfinished">Minimalizuje zamiast zakōńczyć fungowanie aplikacyje przi zawiyraniu ôkna. Kej ta ôpcyjŏ je zapuszczonŏ, aplikacyjŏ zakōńczy fungowanie po ôbraniu Zawrzij w myni.</translation>
    </message>
    <message>
        <source>Open the %1 configuration file from the working directory.</source>
        <translation type="unfinished">Ôdewrzij %1 zbiōr kōnfiguracyje z czynnego katalogu.</translation>
    </message>
    <message>
        <source>Open Configuration File</source>
        <translation type="unfinished">Ôdewrzij zbiōr kōnfiguracyje</translation>
    </message>
    <message>
        <source>Reset all client options to default.</source>
        <translation type="unfinished">Prziwrōć wszyjske wychodne ustawiyniŏ klijynta.</translation>
    </message>
    <message>
        <source>&amp;Reset Options</source>
        <translation type="unfinished">&amp;Resetuj Ôpcyje</translation>
    </message>
    <message>
        <source>&amp;Network</source>
        <translation type="unfinished">&amp;Nec</translation>
    </message>
    <message>
        <source>Prune &amp;block storage to</source>
        <translation type="unfinished">Przitnij skłŏd &amp;blokōw do</translation>
    </message>
    <message>
        <source>Reverting this setting requires re-downloading the entire blockchain.</source>
        <translation type="unfinished">Cŏfniyńcie tego ustawiyniŏ fołdruje pōnownego sebraniŏ cołkij kety blokōw.</translation>
    </message>
    <message>
        <source>(0 = auto, &lt;0 = leave that many cores free)</source>
        <translation type="unfinished">(0 = autōmatycznie, &lt;0 = ôstŏw tela swobodnych drzyni)</translation>
    </message>
    <message>
        <source>W&amp;allet</source>
        <translation type="unfinished">Portm&amp;anyj</translation>
    </message>
    <message>
        <source>Expert</source>
        <translation type="unfinished">Ekspert</translation>
    </message>
    <message>
        <source>Enable coin &amp;control features</source>
        <translation type="unfinished">Zapuść funkcyje kōntroli mōnet</translation>
    </message>
    <message>
        <source>If you disable the spending of unconfirmed change, the change from a transaction cannot be used until that transaction has at least one confirmation. This also affects how your balance is computed.</source>
        <translation type="unfinished">Jeźli zastawisz możebność wydaniŏ niyprzituplikowanyj wydanej wydŏwki, wydŏwka z transakcyje niy bydzie mogła ôstać użytŏ, podwiela ta transakcyjŏ niy bydzie miała nojmynij jednego przituplowaniŏ. To tyż mŏ wpływ na porachowanie Twojigo salda.</translation>
    </message>
    <message>
        <source>&amp;Spend unconfirmed change</source>
        <translation type="unfinished">&amp;Wydej niyprzituplowanõ wydŏwkã</translation>
    </message>
    <message>
        <source>Automatically open the Kawra client port on the router. This only works when your router supports UPnP and it is enabled.</source>
        <translation type="unfinished">Autōmatycznie ôdewrzij port klijynta Kawra na routerze. Ta ôpcyjŏ funguje ino jeźli twōj router podpiyrŏ UPnP i je ôno zapuszczone.</translation>
    </message>
    <message>
        <source>Map port using &amp;UPnP</source>
        <translation type="unfinished">Mapuj port przi używaniu &amp;UPnP</translation>
    </message>
    <message>
        <source>Accept connections from outside.</source>
        <translation type="unfinished">Akceptuj skuplowania ôd zewnōntrz.</translation>
    </message>
    <message>
        <source>Allow incomin&amp;g connections</source>
        <translation type="unfinished">Zwōl na skuplowania przichodzōnce</translation>
    </message>
    <message>
        <source>Connect to the Kawra network through a SOCKS5 proxy.</source>
        <translation type="unfinished">Skupluj sie z necym Kawra bez SOCKS5 proxy.</translation>
    </message>
    <message>
        <source>&amp;Connect through SOCKS5 proxy (default proxy):</source>
        <translation type="unfinished">&amp;Skupluj bez proxy SOCKS5 (wychodne proxy):</translation>
    </message>
    <message>
        <source>Port of the proxy (e.g. 9050)</source>
        <translation type="unfinished">Port ôd proxy (bp. 9050)</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation type="unfinished">Ô&amp;kno</translation>
    </message>
    <message>
        <source>User Interface &amp;language:</source>
        <translation type="unfinished">Gŏdka &amp;używŏcza:</translation>
    </message>
    <message>
        <source>The user interface language can be set here. This setting will take effect after restarting %1.</source>
        <translation type="unfinished">Idzie sam nasztalować gŏdka interfejsu używŏcza. Nasztalowanie prziniesie skutki po resztarcie %1.</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="unfinished">&amp;Pociep</translation>
    </message>
    <message>
        <source>default</source>
        <translation type="unfinished">wychodny</translation>
    </message>
    <message>
        <source>none</source>
        <translation type="unfinished">żŏdyn</translation>
    </message>
    <message>
        <source>Configuration options</source>
        <extracomment>Window title text of pop-up box that allows opening up of configuration file.</extracomment>
        <translation type="unfinished">Ôpcyje kōnfiguracyje</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished">Pociep</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">Feler</translation>
    </message>
    </context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Form</source>
        <translation type="unfinished">Formular</translation>
    </message>
    <message>
        <source>The displayed information may be out of date. Your wallet automatically synchronizes with the Kawra network after a connection is established, but this process has not completed yet.</source>
        <translation type="unfinished">Wyświytlanŏ informacyjŏ może być niyterŏźnŏ. Twōj portmanyj synchrōnizuje sie autōmatycznie z necym kawra zarŏz po tym, jak zrychtowane je skuplowanie, ale proces tyn niy ôstoł jeszcze skōńczōny.</translation>
    </message>
    <message>
        <source>Available:</source>
        <translation type="unfinished">Dostympne:</translation>
    </message>
    <message>
        <source>Pending:</source>
        <translation type="unfinished">Czekajōnce:</translation>
    </message>
    <message>
        <source>Balances</source>
        <translation type="unfinished">Salda</translation>
    </message>
    <message>
        <source>Total:</source>
        <translation type="unfinished">Cuzamyn:</translation>
    </message>
    <message>
        <source>Your current total balance</source>
        <translation type="unfinished">Twoje terŏźne saldo</translation>
    </message>
    </context>
<context>
    <name>PSBTOperationsDialog</name>
    <message>
        <source>or</source>
        <translation type="unfinished">abo</translation>
    </message>
    </context>
<context>
    <name>PaymentServer</name>
    <message>
        <source>Payment request error</source>
        <translation type="unfinished">Feler żōndaniŏ płatu</translation>
    </message>
    <message>
        <source>URI handling</source>
        <translation type="unfinished">Bedynōng URI</translation>
    </message>
    <message>
        <source>'kawra://' is not a valid URI. Use 'kawra:' instead.</source>
        <translation type="unfinished">'kawra://' to niyma nŏleżne URI. Użyj 'kawra:'.</translation>
    </message>
    </context>
<context>
    <name>PeerTableModel</name>
    <message>
        <source>User Agent</source>
        <extracomment>Title of Peers Table column which contains the peer's User Agent string.</extracomment>
        <translation type="unfinished">Agynt Używŏcza</translation>
    </message>
    <message>
        <source>Direction</source>
        <extracomment>Title of Peers Table column which indicates the direction the peer connection was initiated from.</extracomment>
        <translation type="unfinished">Richtōng</translation>
    </message>
    <message>
        <source>Received</source>
        <extracomment>Title of Peers Table column which indicates the total amount of network information we have received from the peer.</extracomment>
        <translation type="unfinished">Ôdebrane</translation>
    </message>
    <message>
        <source>Address</source>
        <extracomment>Title of Peers Table column which contains the IP/Onion/I2P address of the connected peer.</extracomment>
        <translation type="unfinished">Adresa</translation>
    </message>
    <message>
        <source>Type</source>
        <extracomment>Title of Peers Table column which describes the type of peer connection. The "type" describes why the connection exists.</extracomment>
        <translation type="unfinished">Zorta</translation>
    </message>
    <message>
        <source>Network</source>
        <extracomment>Title of Peers Table column which states the network the peer connected through.</extracomment>
        <translation type="unfinished">Nec</translation>
    </message>
    <message>
        <source>Inbound</source>
        <extracomment>An Inbound Connection from a Peer.</extracomment>
        <translation type="unfinished">Wchodowy</translation>
    </message>
    <message>
        <source>Outbound</source>
        <extracomment>An Outbound Connection to a Peer.</extracomment>
        <translation type="unfinished">Wychodowy</translation>
    </message>
</context>
<context>
    <name>QRImageWidget</name>
    <message>
        <source>&amp;Copy Image</source>
        <translation type="unfinished">&amp;Kopiyruj Ôbrŏzek</translation>
    </message>
    <message>
        <source>Save QR Code</source>
        <translation type="unfinished">Spamiyntej kod QR</translation>
    </message>
    </context>
<context>
    <name>RPCConsole</name>
    <message>
        <source>Client version</source>
        <translation type="unfinished">Wersyjŏ klijynta</translation>
    </message>
    <message>
        <source>Datadir</source>
        <translation type="unfinished">Katalog datōw</translation>
    </message>
    <message>
        <source>Startup time</source>
        <translation type="unfinished">Czŏs sztartniyńciŏ</translation>
    </message>
    <message>
        <source>Network</source>
        <translation type="unfinished">Nec</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished">Miano</translation>
    </message>
    <message>
        <source>Number of connections</source>
        <translation type="unfinished">Wielość skuplowań</translation>
    </message>
    <message>
        <source>Block chain</source>
        <translation type="unfinished">Keta blokōw</translation>
    </message>
    <message>
        <source>Current number of transactions</source>
        <translation type="unfinished">Terŏźniŏ wielość transakcyji</translation>
    </message>
    <message>
        <source>Wallet: </source>
        <translation type="unfinished">Portmanyj:</translation>
    </message>
    <message>
        <source>Received</source>
        <translation type="unfinished">Ôdebrane</translation>
    </message>
    <message>
        <source>Version</source>
        <translation type="unfinished">Wersyjŏ</translation>
    </message>
    <message>
        <source>User Agent</source>
        <translation type="unfinished">Agynt Używŏcza</translation>
    </message>
    <message>
        <source>Services</source>
        <translation type="unfinished">Usugi</translation>
    </message>
    <message>
        <source>Connection Time</source>
        <translation type="unfinished">Czŏs Skuplowaniŏ</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation type="unfinished">Czas ôstatnigo bloku</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation type="unfinished">Ô&amp;dewrzij</translation>
    </message>
    <message>
        <source>&amp;Network Traffic</source>
        <translation type="unfinished">&amp;Ruch necowy</translation>
    </message>
    <message>
        <source>In:</source>
        <translation type="unfinished">Wchōd:</translation>
    </message>
    <message>
        <source>Out:</source>
        <translation type="unfinished">Wychōd:</translation>
    </message>
    <message>
        <source>&amp;Disconnect</source>
        <translation type="unfinished">Ô&amp;dkupluj</translation>
    </message>
    <message>
        <source>Network activity disabled</source>
        <translation type="unfinished">Aktywność necowŏ zastawiōnŏ</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="unfinished">Ja</translation>
    </message>
    <message>
        <source>No</source>
        <translation type="unfinished">Niy</translation>
    </message>
    <message>
        <source>To</source>
        <translation type="unfinished">Do</translation>
    </message>
    <message>
        <source>From</source>
        <translation type="unfinished">Z</translation>
    </message>
    </context>
<context>
    <name>ReceiveCoinsDialog</name>
    <message>
        <source>&amp;Label:</source>
        <translation type="unfinished">&amp;Etyketa:</translation>
    </message>
    <message>
        <source>An optional message to attach to the payment request, which will be displayed when the request is opened. Note: The message will not be sent with the payment over the Kawra network.</source>
        <translation type="unfinished">Ôpcyjōnalnŏ wiadōmość do prziwstōniŏ do żōndaniŏ płatu, kerŏ bydzie wyświytlanŏ, kej żōndanie ôstanie ôdewrzōne. Napōmniynie: wiadōmość ta niy ôstanie wysłanŏ z płatym w nec Kawra.</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation type="unfinished">Wypucuj</translation>
    </message>
    <message>
        <source>Show</source>
        <translation type="unfinished">Pokŏż</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished">Wychrōń</translation>
    </message>
    <message>
        <source>Copy &amp;URI</source>
        <translation type="unfinished">Kopiyruj &amp;URI</translation>
    </message>
    <message>
        <source>Could not unlock wallet.</source>
        <translation type="unfinished">Niy idzie było ôdszperować portmanyja.</translation>
    </message>
    </context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>Amount:</source>
        <translation type="unfinished">Kwota:</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation type="unfinished">Wiadōmość:</translation>
    </message>
    <message>
        <source>Wallet:</source>
        <translation type="unfinished">Portmanyj:</translation>
    </message>
    <message>
        <source>Copy &amp;URI</source>
        <translation type="unfinished">Kopiyruj &amp;URI</translation>
    </message>
    <message>
        <source>Copy &amp;Address</source>
        <translation type="unfinished">Kopiyruj &amp;Adresã</translation>
    </message>
    <message>
        <source>Payment information</source>
        <translation type="unfinished">Informacyje ô płacie</translation>
    </message>
    </context>
<context>
    <name>RecentRequestsTableModel</name>
    <message>
        <source>Date</source>
        <translation type="unfinished">Datōm</translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished">Etyketa</translation>
    </message>
    <message>
        <source>Message</source>
        <translation type="unfinished">Wiadōmość</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(chyba etykety)</translation>
    </message>
    </context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Send Coins</source>
        <translation type="unfinished">Poślij mōnety</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation type="unfinished">Wielość:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation type="unfinished">Bajtōw:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation type="unfinished">Kwota:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation type="unfinished">Ôpłŏcka:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation type="unfinished">Po ôpłŏcce:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation type="unfinished">Wydŏwka:</translation>
    </message>
    <message>
        <source>Warning: Fee estimation is currently not possible.</source>
        <translation type="unfinished">Pozōr: Ôszacowanie ôpłŏcki za transakcyje je aktualnie niymożebne.</translation>
    </message>
    <message>
        <source>per kilobyte</source>
        <translation type="unfinished">na kilobajt</translation>
    </message>
    <message>
        <source>Hide</source>
        <translation type="unfinished">Skryj</translation>
    </message>
    <message>
        <source>Recommended:</source>
        <translation type="unfinished">Doradzane:</translation>
    </message>
    <message>
        <source>Custom:</source>
        <translation type="unfinished">Włŏsne:</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation type="unfinished">Sztaub:</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation type="unfinished">Saldo:</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation type="unfinished">Kopiyruj wielość</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation type="unfinished">Kopiyruj kwotã</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation type="unfinished">Kopiyruj ôpłŏckã</translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation type="unfinished">Kopiyruj wielość po ôpłŏcce</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation type="unfinished">Kopiyruj wielość bajtōw</translation>
    </message>
    <message>
        <source>Copy dust</source>
        <translation type="unfinished">Kopiyruj sztaub</translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation type="unfinished">Kopiyruj wydŏwkã</translation>
    </message>
    <message>
        <source>%1 (%2 blocks)</source>
        <translation type="unfinished">%1 (%2 blokōw)</translation>
    </message>
    <message>
        <source>or</source>
        <translation type="unfinished">abo</translation>
    </message>
    <message>
        <source>Transaction creation failed!</source>
        <translation type="unfinished">Utworzynie transakcyje niy podarziło sie!</translation>
    </message>
    <message numerus="yes">
        <source>Estimated to begin confirmation within %n block(s).</source>
        <translation type="unfinished">
            <numerusform />
        </translation>
    </message>
    <message>
        <source>Warning: Invalid Kawra address</source>
        <translation type="unfinished">Pozōr: niynŏleżnŏ adresa Kawra</translation>
    </message>
    <message>
        <source>Warning: Unknown change address</source>
        <translation type="unfinished">Pozōr: Niyznōmŏ adresa wydŏwki</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(chyba etykety)</translation>
    </message>
</context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>&amp;Label:</source>
        <translation type="unfinished">&amp;Etyketa:</translation>
    </message>
    <message>
        <source>The Kawra address to send the payment to</source>
        <translation type="unfinished">Adresa Kawra, na kerõ chcesz posłać płat</translation>
    </message>
    <message>
        <source>Use available balance</source>
        <translation type="unfinished">Użyj dostympnego salda</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation type="unfinished">Wiadōmość:</translation>
    </message>
    <message>
        <source>A message that was attached to the kawra: URI which will be stored with the transaction for your reference. Note: This message will not be sent over the Kawra network.</source>
        <translation type="unfinished">Wiadōmość, kerŏ ôstała prziwstōnŏ do URI kawra:, kerŏ bydzie przechowowanŏ z transakcyjōm w cylach informacyjnych. Napōmniynie: Ta wiadōmość niy bydzie rozszyrzowanŏ w necu Kawra.</translation>
    </message>
</context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>Signatures - Sign / Verify a Message</source>
        <translation type="unfinished">Szkryfki - Podpisz / Zweryfikuj Wiadōmość</translation>
    </message>
    <message>
        <source>&amp;Sign Message</source>
        <translation type="unfinished">&amp;Szkryftnij Wiadōmość</translation>
    </message>
    <message>
        <source>Sign &amp;Message</source>
        <translation type="unfinished">Szkryftnij &amp;Wiadōmość</translation>
    </message>
    <message>
        <source>&amp;Verify Message</source>
        <translation type="unfinished">&amp;Weryfikuj Wiadōmość</translation>
    </message>
    <message>
        <source>Message signing failed.</source>
        <translation type="unfinished">Szkryftniyńcie wiadōmości niy podarziło sie.</translation>
    </message>
    <message>
        <source>Message signed.</source>
        <translation type="unfinished">Wiadōmość szkryftniyntŏ.</translation>
    </message>
    <message>
        <source>Message verification failed.</source>
        <translation type="unfinished">Weryfikacyjŏ wiadōmości niy podarziła sie.</translation>
    </message>
    </context>
<context>
    <name>TransactionDesc</name>
    <message>
        <source>Status</source>
        <translation type="unfinished">Sztatus</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished">Datōm</translation>
    </message>
    <message>
        <source>Source</source>
        <translation type="unfinished">Źrōdło</translation>
    </message>
    <message>
        <source>From</source>
        <translation type="unfinished">Z</translation>
    </message>
    <message>
        <source>unknown</source>
        <translation type="unfinished">niyznōme</translation>
    </message>
    <message>
        <source>To</source>
        <translation type="unfinished">Do</translation>
    </message>
    <message>
        <source>label</source>
        <translation type="unfinished">etyketa</translation>
    </message>
    <message numerus="yes">
        <source>matures in %n more block(s)</source>
        <translation type="unfinished">
            <numerusform />
        </translation>
    </message>
    <message>
        <source>Message</source>
        <translation type="unfinished">Wiadōmość</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation type="unfinished">Kōmyntŏrz</translation>
    </message>
    <message>
        <source>Transaction</source>
        <translation type="unfinished">Transakcyjŏ</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">Kwota</translation>
    </message>
    </context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Date</source>
        <translation type="unfinished">Datōm</translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished">Zorta</translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished">Etyketa</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation type="unfinished">Ôdebrane z</translation>
    </message>
    <message>
        <source>Received from</source>
        <translation type="unfinished">Ôdebrane ôd</translation>
    </message>
    <message>
        <source>Payment to yourself</source>
        <translation type="unfinished">Płat do siebie</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(chyba etykety)</translation>
    </message>
    </context>
<context>
    <name>TransactionView</name>
    <message>
        <source>All</source>
        <translation type="unfinished">Wszyjske</translation>
    </message>
    <message>
        <source>Today</source>
        <translation type="unfinished">Dzisiej</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation type="unfinished">Ôdebrane z</translation>
    </message>
    <message>
        <source>Other</source>
        <translation type="unfinished">Inksze</translation>
    </message>
    <message>
        <source>Enter address, transaction id, or label to search</source>
        <translation type="unfinished">Wkludź adresa, idyntyfikatōr transakcyje abo etyketã coby wyszukać</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation type="unfinished">Przituplowany</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished">Datōm</translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished">Zorta</translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished">Etyketa</translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="unfinished">Adresa</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation type="unfinished">Eksportowanie niy podarziło sie</translation>
    </message>
    <message>
        <source>to</source>
        <translation type="unfinished">do</translation>
    </message>
</context>
<context>
    <name>WalletFrame</name>
    <message>
        <source>Error</source>
        <translation type="unfinished">Feler</translation>
    </message>
    </context>
<context>
    <name>WalletModel</name>
    <message>
        <source>Send Coins</source>
        <translation type="unfinished">Poślij mōnety</translation>
    </message>
    <message>
        <source>New fee:</source>
        <translation type="unfinished">Nowŏ ôpłŏcka:</translation>
    </message>
    <message>
        <source>default wallet</source>
        <translation type="unfinished">wychodny portmanyj</translation>
    </message>
</context>
<context>
    <name>WalletView</name>
    <message>
        <source>&amp;Export</source>
        <translation type="unfinished">&amp;Eksportuj</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation type="unfinished">Eksportuj dane z aktywnyj szkarty do zbioru</translation>
    </message>
    <message>
        <source>Backup Failed</source>
        <translation type="unfinished">Backup niy podarził sie</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished">Pociep</translation>
    </message>
</context>
<context>
    <name>kawra-core</name>
    <message>
        <source>The %s developers</source>
        <translation type="unfinished">Twōrcy %s</translation>
    </message>
    <message>
        <source>Total length of network version string (%i) exceeds maximum length (%i). Reduce the number or size of uacomments.</source>
        <translation type="unfinished">Imyntnŏ dugość kety wersyje (%i) przekrŏczŏ maksymalnõ dopuszczalnõ dugość (%i). Zmyńsz wielość abo miara parametra uacomment.</translation>
    </message>
    <message>
        <source>Warning: Private keys detected in wallet {%s} with disabled private keys</source>
        <translation type="unfinished">Pozōr: Wykryto było klucze prywatne w portmanyju {%s} kery mŏ zastawiōne klucze prywatne</translation>
    </message>
    <message>
        <source>Done loading</source>
        <translation type="unfinished">Wgrŏwanie zakōńczōne</translation>
    </message>
    <message>
        <source>Error loading %s</source>
        <translation type="unfinished">Feler wgrŏwaniŏ %s</translation>
    </message>
    <message>
        <source>Error loading %s: Private keys can only be disabled during creation</source>
        <translation type="unfinished">Feler wgrŏwaniŏ %s: Klucze prywatne mogōm być zastawiōne ino w czasie tworzyniŏ</translation>
    </message>
    <message>
        <source>Error loading %s: Wallet corrupted</source>
        <translation type="unfinished">Feler wgrŏwaniŏ %s: Portmanyj poprzniōny</translation>
    </message>
    <message>
        <source>Error loading %s: Wallet requires newer version of %s</source>
        <translation type="unfinished">Feler wgrŏwaniŏ %s: Portmanyj fołdruje nowszyj wersyje %s</translation>
    </message>
    <message>
        <source>Error loading block database</source>
        <translation type="unfinished">Feler wgrŏwaniŏ bazy blokōw</translation>
    </message>
    <message>
        <source>Error: Disk space is low for %s</source>
        <translation type="unfinished">Feler: Za mało wolnego placu na dysku dlŏ %s</translation>
    </message>
    <message>
        <source>Signing transaction failed</source>
        <translation type="unfinished">Szkryftniyńcie transakcyji niy podarziło sie</translation>
    </message>
    <message>
        <source>This is experimental software.</source>
        <translation type="unfinished">To je eksperymyntalny softwer.</translation>
    </message>
    <message>
        <source>Transaction too large</source>
        <translation type="unfinished">Transakcyjŏ za srogŏ</translation>
    </message>
    <message>
        <source>Unknown network specified in -onlynet: '%s'</source>
        <translation type="unfinished">Niyznōmy nec ôkryślōny w -onlynet: '%s'</translation>
    </message>
    <message>
        <source>Unsupported logging category %s=%s.</source>
        <translation type="unfinished">Niypodpiyranŏ kategoryjŏ registrowaniŏ %s=%s.</translation>
    </message>
    </context>
</TS>