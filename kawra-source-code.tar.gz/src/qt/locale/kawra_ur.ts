<TS version="2.1" language="ur">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Right-click to edit address or label</source>
        <translation type="unfinished">پتہ یا لیبل کی تصیح کیلیئے داہنا کلک</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation type="unfinished">نیا پتہ تخلیق کریں</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation type="unfinished">اور نیا</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation type="unfinished">موجودہ چنے ہوئے پتے کو نقل کریں سسٹم کلپ بورڈ پر</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation type="unfinished">نقل</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation type="unfinished">بند</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation type="unfinished">سلیکٹڈ پتے کو مٹائیں</translation>
    </message>
    <message>
        <source>Enter address or label to search</source>
        <translation type="unfinished">پتہ یا لیبل تلاشی کے لئے درج کریں</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation type="unfinished">موجودہ ڈیٹا کو فائیل میں محفوظ کریں</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation type="unfinished">برآمد</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation type="unfinished">مٹا</translation>
    </message>
    <message>
        <source>Choose the address to send coins to</source>
        <translation type="unfinished">کوئین وصول کرنے والے کا پتہ</translation>
    </message>
    <message>
        <source>Choose the address to receive coins with</source>
        <translation type="unfinished">کوئین وصول کرنے والے کا پتہ</translation>
    </message>
    <message>
        <source>C&amp;hoose</source>
        <translation type="unfinished">چننا</translation>
    </message>
    <message>
        <source>Sending addresses</source>
        <translation type="unfinished">پتے ارسال کیے جارہے ہیں</translation>
    </message>
    <message>
        <source>Receiving addresses</source>
        <translation type="unfinished">پتے موصول ہورہے ہیں</translation>
    </message>
    <message>
        <source>These are your Kawra addresses for sending payments. Always check the amount and the receiving address before sending coins.</source>
        <translation type="unfinished">یہ آپ کے ادائیگی بھیجنے کے لئے بٹ کوائن ایڈریس ہیں.سکے بھیجنے سے پہلے ہمیشہ رقم اور وصول کنندہ پتہ چیک کریں۔</translation>
    </message>
    <message>
        <source>These are your Kawra addresses for receiving payments. Use the 'Create new receiving address' button in the receive tab to create new addresses.
Signing is only possible with addresses of the type 'legacy'.</source>
        <translation type="unfinished">ادائیگیوں کے لئے آپ کے بٹ کوائن ایڈریس ہیں۔ نئے پتے بنانے کے لئے وصول کنندہ ٹیب میں 'نیا وصول کنندہ پتہ بنائیں' بٹن کا استعمال کریں۔دستخط صرف 'میراثی' قسم کے پتے کے ساتھ ہی ممکن ہے۔</translation>
    </message>
    <message>
        <source>&amp;Copy Address</source>
        <translation type="unfinished">&amp;پتا نقل کریں</translation>
    </message>
    <message>
        <source>Copy &amp;Label</source>
        <translation type="unfinished">&amp;لیبل نقل کریں</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation type="unfinished">&amp;تدوین</translation>
    </message>
    <message>
        <source>Export Address List</source>
        <translation type="unfinished">پتا فہرست ایکسپورٹ کریں</translation>
    </message>
    <message>
        <source>Comma separated file</source>
        <extracomment>Expanded name of the CSV file format. See: https://en.wikipedia.org/wiki/Comma-separated_values.</extracomment>
        <translation type="unfinished">کوما سے الگ فائل</translation>
    </message>
    <message>
        <source>There was an error trying to save the address list to %1. Please try again.</source>
        <extracomment>An error message. %1 is a stand-in argument for the name of the file we attempted to save to.</extracomment>
        <translation type="unfinished">پتا فہرست محفوظ کرتے ہوئے %1 نقص کا سامنا ہوا۔ دوبارہ کوشش کریں۔</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation type="unfinished">ایکسپورٹ ناکام ہوا</translation>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Label</source>
        <translation type="unfinished">لیبل</translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="unfinished">پتہ</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(کوئی لیبل نہیں)</translation>
    </message>
</context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Passphrase Dialog</source>
        <translation type="unfinished">پاسفریج ڈائیلاگ</translation>
    </message>
    <message>
        <source>Enter passphrase</source>
        <translation type="unfinished">پاس فریز داخل کریں</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation type="unfinished">نیا پاس فریز</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation type="unfinished">نیا پاس فریز دہرائیں</translation>
    </message>
    <message>
        <source>Show passphrase</source>
        <translation type="unfinished">پاسفریز دکھائیں</translation>
    </message>
    <message>
        <source>Encrypt wallet</source>
        <translation type="unfinished">بٹوے کو خفیہ کریں</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation type="unfinished">پرس کو غیر مقفل کرنے کے لئے اس آپریشن کو آپ کے بٹوے کا پاسفریز درکار ہے۔</translation>
    </message>
    <message>
        <source>Unlock wallet</source>
        <translation type="unfinished">بستہ کھولیں</translation>
    </message>
    <message>
        <source>Change passphrase</source>
        <translation type="unfinished">پاسفریز تبدیل کریں</translation>
    </message>
    <message>
        <source>Confirm wallet encryption</source>
        <translation type="unfinished">پرس کی خفیہ کاری کی تصدیق کریں</translation>
    </message>
    <message>
        <source>Warning: If you encrypt your wallet and lose your passphrase, you will &lt;b&gt;LOSE ALL OF YOUR KAWRAS&lt;/b&gt;!</source>
        <translation type="unfinished">انتباہ: اگر آپ اپنا بٹوہ انکرپٹ کرتے ہیں اور اپنا پاس فریز کھو دیتے ہیں تو ، آپ اپنے تمام بٹکوئنز کھو دیں گے.</translation>
    </message>
    <message>
        <source>Are you sure you wish to encrypt your wallet?</source>
        <translation type="unfinished">کیا آپ واقعی اپنے بٹوے کو خفیہ کرنا چاہتے ہیں؟</translation>
    </message>
    <message>
        <source>Wallet encrypted</source>
        <translation type="unfinished">بٹوے کو خفیہ کردہ</translation>
    </message>
    <message>
        <source>Enter the new passphrase for the wallet.&lt;br/&gt;Please use a passphrase of &lt;b&gt;ten or more random characters&lt;/b&gt;, or &lt;b&gt;eight or more words&lt;/b&gt;.</source>
        <translation type="unfinished">پرس کے لئے نیا پاسفریج درج کریں۔ براہ کرم دس یا زیادہ بے ترتیب حرفوں ، یا آٹھ یا زیادہ الفاظ کا پاس فریز استعمال کریں۔</translation>
    </message>
    <message>
        <source>Enter the old passphrase and new passphrase for the wallet.</source>
        <translation type="unfinished">پرس کے لئے پرانا پاسفریج اور نیا پاسفریز درج کریں۔</translation>
    </message>
    <message>
        <source>Remember that encrypting your wallet cannot fully protect your kawras from being stolen by malware infecting your computer.</source>
        <translation type="unfinished">یاد رکھیں کہ آپ کے پرس کو خفیہ کرنا آپ کے بٹ کوائنز کو میلویئر/چور سے آپ کے کمپیوٹر میں انفیکشن لگانے کے ذریعہ چوری ہونے سے پوری طرح محفوظ نہیں رکھ سکتا ہے۔</translation>
    </message>
    <message>
        <source>Wallet to be encrypted</source>
        <translation type="unfinished">بٹوے کو خفیہ کرنا ہے</translation>
    </message>
    <message>
        <source>Your wallet is about to be encrypted. </source>
        <translation type="unfinished">آپ کا پرس خفیہ ہونے والا ہے۔</translation>
    </message>
    <message>
        <source>Your wallet is now encrypted. </source>
        <translation type="unfinished">آپ کا پرس اب خفیہ ہے۔</translation>
    </message>
    <message>
        <source>IMPORTANT: Any previous backups you have made of your wallet file should be replaced with the newly generated, encrypted wallet file. For security reasons, previous backups of the unencrypted wallet file will become useless as soon as you start using the new, encrypted wallet.</source>
        <translation type="unfinished">اہم: کسی بھی پچھلے بیک اپ کو جو آپ نے اپنی بٹوے فائل سے بنایا ہے اس کی جگہ نئی تیار کردہ ، خفیہ کردہ والیٹ فائل کی جگہ لینا چاہئے۔ سیکیورٹی وجوہات کی بناء پر ، بغیر خفیہ کردہ والیٹ فائل کا پچھلا بیک اپ بیکار ہوجائے گا جیسے ہی آپ نیا ، خفیہ کردہ پرس استعمال کرنا شروع کردیں گے۔</translation>
    </message>
    <message>
        <source>Wallet encryption failed</source>
        <translation type="unfinished">والیٹ کی خفیہ کاری ناکام ہوگئی</translation>
    </message>
    <message>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation type="unfinished">اندرونی خامی کے سبب والیٹ کی خفیہ کاری ناکام ہوگئی۔ آپ کا پرس خفیہ نہیں ہوا تھا۔</translation>
    </message>
    <message>
        <source>The supplied passphrases do not match.</source>
        <translation type="unfinished">فراہم کردہ پاسفریز مماثل نہیں ہیں۔</translation>
    </message>
    <message>
        <source>Wallet unlock failed</source>
        <translation type="unfinished">والیٹ انلاک ناکام ہوگیا</translation>
    </message>
    <message>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation type="unfinished">بٹوے کی ڈکرپشن کے لئے درج کردہ پاس فریس غلط تھا۔</translation>
    </message>
    <message>
        <source>Wallet passphrase was successfully changed.</source>
        <translation type="unfinished">والیٹ کا پاسفریز کامیابی کے ساتھ تبدیل کردیا گیا تھا۔</translation>
    </message>
    <message>
        <source>Warning: The Caps Lock key is on!</source>
        <translation type="unfinished">انتباہ: کیپس لاک کی آن ہے!</translation>
    </message>
</context>
<context>
    <name>BanTableModel</name>
    <message>
        <source>IP/Netmask</source>
        <translation type="unfinished">آئی پی / نیٹ ماسک</translation>
    </message>
    <message>
        <source>Banned Until</source>
        <translation type="unfinished">تک پابندی عائد</translation>
    </message>
</context>
<context>
    <name>KawraApplication</name>
    <message>
        <source>Runaway exception</source>
        <translation type="unfinished">بھگوڑے رعایت</translation>
    </message>
    <message>
        <source>A fatal error occurred. %1 can no longer continue safely and will quit.</source>
        <translation type="unfinished">ایک مہلک خرابی واقع ہوئی ہے۔  %1 اب مزید سلامتی سے جاری نہیں رہ سکتا ہے اور چھوڑ دے گا۔</translation>
    </message>
    <message>
        <source>Internal error</source>
        <translation type="unfinished">داخلی خامی</translation>
    </message>
    <message>
        <source>An internal error occurred. %1 will attempt to continue safely. This is an unexpected bug which can be reported as described below.</source>
        <translation type="unfinished">ایک داخلی خامی پیش آگئی۔ %1 محفوظ طریقے سے جاری رکھنے کی کوشش کریں گے۔ یہ ایک غیر متوقع مسئلہ ہے جس کی اطلاع ذیل میں دی جاسکتی ہے۔</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Do you want to reset settings to default values, or to abort without making changes?</source>
        <extracomment>Explanatory text shown on startup when the settings file cannot be read. Prompts user to make a choice between resetting or aborting.</extracomment>
        <translation type="unfinished">کیا آپ ترتیبات کو ڈیفالٹ اقدار پر دوبارہ ترتیب دینا چاہتے ہیں، یا تبدیلیاں کیے بغیر اسقاط کرنا چاہتے ہیں؟</translation>
    </message>
    <message>
        <source>Error: %1</source>
        <translation type="unfinished">خرابی:%1</translation>
    </message>
    <message>
        <source>%1 didn't yet exit safely…</source>
        <translation type="unfinished">%1ابھی تک سلامتی سے باہر نہیں نکلا…</translation>
    </message>
    <message>
        <source>unknown</source>
        <translation type="unfinished">نامعلوم</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">رقم</translation>
    </message>
    <message>
        <source>Unroutable</source>
        <translation type="unfinished">ناقابل استعمال</translation>
    </message>
    <message>
        <source>Address Fetch</source>
        <extracomment>Short-lived peer connection type that solicits known addresses from a peer.</extracomment>
        <translation type="unfinished">پتہ بازیافت کریں۔</translation>
    </message>
    <message>
        <source>%1 ms</source>
        <translation type="unfinished">ملی سیکنڈز %1</translation>
    </message>
    <message numerus="yes">
        <source>%n second(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n minute(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n hour(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n day(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n week(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n year(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    </context>
<context>
    <name>KawraGUI</name>
    <message>
        <source>&amp;Overview</source>
        <translation type="unfinished">اور جائزہ</translation>
    </message>
    <message>
        <source>Show general overview of wallet</source>
        <translation type="unfinished">پرس کا عمومی جائزہ دکھائیں</translation>
    </message>
    <message>
        <source>&amp;Transactions</source>
        <translation type="unfinished">اور لین دین</translation>
    </message>
    <message>
        <source>Browse transaction history</source>
        <translation type="unfinished">ٹرانزیکشن ہسٹری کو براؤز کریں</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation type="unfinished">باہر نکلیں</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation type="unfinished">درخواست چھوڑ دیں</translation>
    </message>
    <message>
        <source>&amp;About %1</source>
        <translation type="unfinished">&amp;معلومات%1</translation>
    </message>
    <message>
        <source>Show information about %1</source>
        <translation type="unfinished">%1 کے بارے میں معلومات دکھایں</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation type="unfinished">کے بارے میں &amp;Qt</translation>
    </message>
    <message>
        <source>Show information about Qt</source>
        <translation type="unfinished">Qt کے بارے میں معلومات دکھائیں</translation>
    </message>
    <message>
        <source>Modify configuration options for %1</source>
        <translation type="unfinished">%1 اختیارات کے لئےترتیب ترمیم کریں</translation>
    </message>
    <message>
        <source>Create a new wallet</source>
        <translation type="unfinished">ایک نیا پرس بنائیں</translation>
    </message>
    <message>
        <source>Wallet:</source>
        <translation type="unfinished">پرس:</translation>
    </message>
    <message>
        <source>Network activity disabled.</source>
        <extracomment>A substring of the tooltip.</extracomment>
        <translation type="unfinished">نیٹ ورک کی سرگرمی غیر فعال ہے۔</translation>
    </message>
    <message>
        <source>Proxy is &lt;b&gt;enabled&lt;/b&gt;: %1</source>
        <translation type="unfinished">پراکسی &lt;b&gt;فعال&lt;/b&gt; ہے:%1</translation>
    </message>
    <message>
        <source>Send coins to a Kawra address</source>
        <translation type="unfinished">بٹ کوائن ایڈریس پر سکے بھیجیں</translation>
    </message>
    <message>
        <source>Backup wallet to another location</source>
        <translation type="unfinished">کسی دوسرے مقام پر بیک اپ والیٹ</translation>
    </message>
    <message>
        <source>Change the passphrase used for wallet encryption</source>
        <translation type="unfinished">بٹوے کی خفیہ کاری کے لئے استعمال ہونے والا پاسفریز تبدیل کریں</translation>
    </message>
    <message>
        <source>&amp;Send</source>
        <translation type="unfinished">&amp;بھیجیں</translation>
    </message>
    <message>
        <source>&amp;Receive</source>
        <translation type="unfinished">&amp;وصول کریں</translation>
    </message>
    <message>
        <source>&amp;Options…</source>
        <translation type="unfinished">&amp;اختیارات…</translation>
    </message>
    <message>
        <source>&amp;Encrypt Wallet…</source>
        <translation type="unfinished">&amp; والیٹ کو خفیہ کریں…</translation>
    </message>
    <message>
        <source>&amp;Backup Wallet…</source>
        <translation type="unfinished">&amp; بیک اپ والیٹ…</translation>
    </message>
    <message>
        <source>&amp;Change Passphrase…</source>
        <translation type="unfinished">&amp; بیک اپ والیٹ…</translation>
    </message>
    <message>
        <source>Sign &amp;message…</source>
        <translation type="unfinished">سائن اور پیغام…</translation>
    </message>
    <message>
        <source>Sign messages with your Kawra addresses to prove you own them</source>
        <translation type="unfinished">اپنے ویکیپیڈیا پتوں کے ساتھ پیغامات پر دستخط کریں تاکہ آپ ان کے مالک ہوں</translation>
    </message>
    <message>
        <source>&amp;Verify message…</source>
        <translation type="unfinished">پیغام کی توثیق کریں…</translation>
    </message>
    <message>
        <source>Verify messages to ensure they were signed with specified Kawra addresses</source>
        <translation type="unfinished">پیغامات کی توثیق کریں تاکہ یہ یقینی بن سکے کہ ان پر بٹ کوائن کے مخصوص پتوں پر دستخط ہوئے ہیں</translation>
    </message>
    <message>
        <source>Open &amp;URI…</source>
        <translation type="unfinished">کھولیں اور یو آر آئی…</translation>
    </message>
    <message>
        <source>Close Wallet…</source>
        <translation type="unfinished">پرس بند کریں…</translation>
    </message>
    <message>
        <source>Create Wallet…</source>
        <translation type="unfinished">والیٹ بنائیں…</translation>
    </message>
    <message>
        <source>Close All Wallets…</source>
        <translation type="unfinished">تمام والیٹس بند کردیں</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation type="unfinished">اور فائل</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation type="unfinished">اور ترتیبات</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation type="unfinished">اور مدد</translation>
    </message>
    <message>
        <source>Tabs toolbar</source>
        <translation type="unfinished">ٹیبز ٹول بار</translation>
    </message>
    <message>
        <source>Syncing Headers (%1%)…</source>
        <translation type="unfinished"> '%1%' ہیڈرز کی مطابقت پذیری</translation>
    </message>
    <message>
        <source>Synchronizing with network…</source>
        <translation type="unfinished">نیٹ ورک کے ساتھ ہم آہنگ ہو کر</translation>
    </message>
    <message>
        <source>Indexing blocks on disk…</source>
        <translation type="unfinished">ڈسک پر بلاکس کو انڈیکس کرنا</translation>
    </message>
    <message>
        <source>Processing blocks on disk…</source>
        <translation type="unfinished">ڈسک پر بلاکس کو پراسیس کرنا</translation>
    </message>
    <message>
        <source>Connecting to peers…</source>
        <translation type="unfinished">ساتھیوں سے منسلک کرنے</translation>
    </message>
    <message>
        <source>Request payments (generates QR codes and kawra: URIs)</source>
        <translation type="unfinished">ادائیگی کی درخواست کریں: ( کوئیک رسپانس ( کیو۔آر ) کوڈ اور بٹ کوائن ( یونیورسل ادائیگیوں کا نظام) کے ذریعے سے</translation>
    </message>
    <message>
        <source>Show the list of used sending addresses and labels</source>
        <translation type="unfinished">استعمال شدہ بھیجنے والے پتے اور لیبلز کی فہرست دکھائیں۔</translation>
    </message>
    <message>
        <source>Show the list of used receiving addresses and labels</source>
        <translation type="unfinished">استعمال شدہ وصول کرنے والے پتوں اور لیبلز کی فہرست دکھائیں۔</translation>
    </message>
    <message>
        <source>&amp;Command-line options</source>
        <translation type="unfinished">اور کمانڈ لائن اختیارات</translation>
    </message>
    <message numerus="yes">
        <source>Processed %n block(s) of transaction history.</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message>
        <source>%1 behind</source>
        <translation type="unfinished">'%1'پیچھے</translation>
    </message>
    <message>
        <source>Catching up…</source>
        <translation type="unfinished">پکڑنا</translation>
    </message>
    <message>
        <source>Last received block was generated %1 ago.</source>
        <translation type="unfinished">آخری موصول شدہ 1 '%1' پہلے تیار کیا گیا تھا۔</translation>
    </message>
    <message>
        <source>Transactions after this will not yet be visible.</source>
        <translation type="unfinished">اس کے بعد کی لین دین ابھی نظر نہیں آئے گی۔</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">نقص</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation type="unfinished">انتباہ</translation>
    </message>
    <message>
        <source>Information</source>
        <translation type="unfinished">معلومات</translation>
    </message>
    <message>
        <source>Up to date</source>
        <translation type="unfinished">سب سے نیا</translation>
    </message>
    <message>
        <source>Load Partially Signed Kawra Transaction</source>
        <translation type="unfinished">جزوی طور پر دستخط شدہ بٹ کوائن ٹرانزیکشن لوڈ کریں۔</translation>
    </message>
    <message>
        <source>Load Partially Signed Kawra Transaction from clipboard</source>
        <translation type="unfinished">کلپ بورڈ سے جزوی طور پر دستخط شدہ بٹ کوائن ٹرانزیکشن لوڈ کریں۔</translation>
    </message>
    <message>
        <source>Node window</source>
        <translation type="unfinished">نوڈ ونڈو</translation>
    </message>
    <message>
        <source>Open node debugging and diagnostic console</source>
        <translation type="unfinished">نوڈ ڈیبگنگ اور تشخیصی کنسول کھولیں۔</translation>
    </message>
    <message>
        <source>&amp;Sending addresses</source>
        <translation type="unfinished">اور بھیجنے والے پتے</translation>
    </message>
    <message>
        <source>&amp;Receiving addresses</source>
        <translation type="unfinished">اور پتے وصول کرنا</translation>
    </message>
    <message>
        <source>Open a kawra: URI</source>
        <translation type="unfinished">بٹ کوائن کا یو۔آر۔آئی۔ کھولیں</translation>
    </message>
    <message>
        <source>Open Wallet</source>
        <translation type="unfinished">والیٹ کھولیں</translation>
    </message>
    <message>
        <source>Open a wallet</source>
        <translation type="unfinished">والیٹ کھولیں</translation>
    </message>
    <message>
        <source>Close wallet</source>
        <translation type="unfinished">والیٹ بند کریں</translation>
    </message>
    <message>
        <source>Close all wallets</source>
        <translation type="unfinished">تمام والیٹس بند کریں</translation>
    </message>
    <message>
        <source>Show the %1 help message to get a list with possible Kawra command-line options</source>
        <translation type="unfinished">ممکنہ بٹ کوائن کمانڈ لائن اختیارات کے ساتھ فہرست حاصل کرنے کے لیے %1 مدد کا پیغام دکھائیں۔</translation>
    </message>
    <message>
        <source>&amp;Mask values</source>
        <translation type="unfinished">قدروں کو چھپائیں</translation>
    </message>
    <message>
        <source>Mask the values in the Overview tab</source>
        <translation type="unfinished">جائزہ ٹیب میں اقدار کو ماسک کریں۔</translation>
    </message>
    <message>
        <source>default wallet</source>
        <translation type="unfinished">پہلے سے طے شدہ والیٹ</translation>
    </message>
    <message>
        <source>No wallets available</source>
        <translation type="unfinished">کوئی والیٹ دستیاب نہیں ہیں۔</translation>
    </message>
    <message>
        <source>Wallet Name</source>
        <extracomment>Label of the input field where the name of the wallet is entered.</extracomment>
        <translation type="unfinished">والیٹ کا نام</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation type="unfinished">اور ونڈو</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation type="unfinished">بغور جائزہ لینا</translation>
    </message>
    <message>
        <source>Main Window</source>
        <translation type="unfinished">مین ونڈو</translation>
    </message>
    <message>
        <source>%1 client</source>
        <translation type="unfinished">'%1'کلائنٹ</translation>
    </message>
    <message numerus="yes">
        <source>%n active connection(s) to Kawra network.</source>
        <extracomment>A substring of the tooltip.</extracomment>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message>
        <source>Click for more actions.</source>
        <extracomment>A substring of the tooltip. "More actions" are available via the context menu.</extracomment>
        <translation type="unfinished">مزید کارروائی کے لیے کلک کریں۔</translation>
    </message>
    <message>
        <source>Show Peers tab</source>
        <extracomment>A context menu item. The "Peers tab" is an element of the "Node window".</extracomment>
        <translation type="unfinished">پیئرز ٹیب دکھائیں۔</translation>
    </message>
    <message>
        <source>Disable network activity</source>
        <extracomment>A context menu item.</extracomment>
        <translation type="unfinished">نیٹ ورک کی سرگرمی کو غیر فعال کریں۔</translation>
    </message>
    <message>
        <source>Enable network activity</source>
        <extracomment>A context menu item. The network activity was disabled previously.</extracomment>
        <translation type="unfinished">نیٹ ورک کی سرگرمی کو فعال کریں۔</translation>
    </message>
    <message>
        <source>Error: %1</source>
        <translation type="unfinished">خرابی:%1</translation>
    </message>
    <message>
        <source>Warning: %1</source>
        <translation type="unfinished">1%1 انتباہ</translation>
    </message>
    <message>
        <source>Date: %1
</source>
        <translation type="unfinished">1%1' تاریخ۔
</translation>
    </message>
    <message>
        <source>Amount: %1
</source>
        <translation type="unfinished">1%1' مقدار
</translation>
    </message>
    <message>
        <source>Wallet: %1
</source>
        <translation type="unfinished">1%1' والیٹ
</translation>
    </message>
    <message>
        <source>Type: %1
</source>
        <translation type="unfinished">1 %1'قسم
</translation>
    </message>
    <message>
        <source>Label: %1
</source>
        <translation type="unfinished">1%1'لیبل
</translation>
    </message>
    <message>
        <source>Address: %1
</source>
        <translation type="unfinished">1%1' پتہ
</translation>
    </message>
    <message>
        <source>Sent transaction</source>
        <translation type="unfinished">بھیجی گئی ٹرانزیکشن</translation>
    </message>
    <message>
        <source>Incoming transaction</source>
        <translation type="unfinished">آنے والی ٹرانزیکشن</translation>
    </message>
    <message>
        <source>HD key generation is &lt;b&gt;enabled&lt;/b&gt;</source>
        <translation type="unfinished">درجہ بندی کا تعین کرنے والی ایچ۔ڈی کلیدی جنریشن &lt;b&gt;فعال&lt;/b&gt; ہے</translation>
    </message>
    <message>
        <source>HD key generation is &lt;b&gt;disabled&lt;/b&gt;</source>
        <translation type="unfinished">درجہ بندی کا تعین کرنے والی ایچ۔ ڈی کلیدی جنریشن&lt;b&gt; غیر فعال&lt;/b&gt; ہے</translation>
    </message>
    <message>
        <source>Private key &lt;b&gt;disabled&lt;/b&gt;</source>
        <translation type="unfinished">نجی کلید &lt;b&gt;غیر فعال &lt;b/&gt;ہے۔</translation>
    </message>
    <message>
        <source>Original message:</source>
        <translation type="unfinished">اصل پیغام:</translation>
    </message>
</context>
<context>
    <name>UnitDisplayStatusBarControl</name>
    <message>
        <source>Unit to show amounts in. Click to select another unit.</source>
        <translation type="unfinished">رقم ظاہر کرنے کے لیے یونٹ۔ دوسری اکائی کو منتخب کرنے کے لیے کلک کریں۔</translation>
    </message>
</context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Coin Selection</source>
        <translation type="unfinished">سکے کا انتخاب</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation type="unfinished">مقدار:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation type="unfinished">بائٹس:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation type="unfinished">رقم:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation type="unfinished">فیس:</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation type="unfinished">نہ ہونے کے برابر</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation type="unfinished">فیس کے بعد:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation type="unfinished">تبدیلی:</translation>
    </message>
    <message>
        <source>(un)select all</source>
        <translation type="unfinished">سب کو غیر منتخب کریں</translation>
    </message>
    <message>
        <source>Tree mode</source>
        <translation type="unfinished">ٹری موڈ</translation>
    </message>
    <message>
        <source>List mode</source>
        <translation type="unfinished">فہرست موڈ</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">رقم</translation>
    </message>
    <message>
        <source>Received with label</source>
        <translation type="unfinished">لیبل کے ساتھ موصول ہوا۔</translation>
    </message>
    <message>
        <source>Received with address</source>
        <translation type="unfinished">پتے کے ساتھ موصول ہوا۔</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished">تاریخ</translation>
    </message>
    <message>
        <source>Confirmations</source>
        <translation type="unfinished">تصدیقات</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation type="unfinished">تصدیق شدہ</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation type="unfinished">رقم کاپی کریں۔</translation>
    </message>
    <message>
        <source>&amp;Copy address</source>
        <translation type="unfinished">ایڈریس کاپی کریں۔</translation>
    </message>
    <message>
        <source>Copy &amp;label</source>
        <translation type="unfinished">کاپی اور لیبل</translation>
    </message>
    <message>
        <source>Copy &amp;amount</source>
        <translation type="unfinished">کاپی اور رقم</translation>
    </message>
    <message>
        <source>L&amp;ock unspent</source>
        <translation type="unfinished">غیر خرچ شدہ آؤٹ پٹ بند کریں</translation>
    </message>
    <message>
        <source>&amp;Unlock unspent</source>
        <translation type="unfinished">غیر خرچ شدہ کھولیں</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation type="unfinished">مقدار کاپی کریں</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation type="unfinished">فیس کاپی کریں</translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation type="unfinished">فیس کے بعد کاپی کریں۔</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation type="unfinished">بائٹس کاپی کریں</translation>
    </message>
    <message>
        <source>Copy dust</source>
        <translation type="unfinished">باقی شدہ کاپی کریں</translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation type="unfinished">تبدیلی کاپی کریں</translation>
    </message>
    <message>
        <source>(%1 locked)</source>
        <translation type="unfinished">مقفل'%1</translation>
    </message>
    <message>
        <source>yes</source>
        <translation type="unfinished">جی ہاں</translation>
    </message>
    <message>
        <source>no</source>
        <translation type="unfinished">نہیں</translation>
    </message>
    <message>
        <source>This label turns red if any recipient receives an amount smaller than the current dust threshold.</source>
        <translation type="unfinished">یہ لیبل سرخ ہو جاتا ہے اگر کوئی وصول کنندہ موجودہ کم سے کم مقرر کردہ حد سے کم رقم وصول کرتا ہے۔</translation>
    </message>
    <message>
        <source>Can vary +/- %1 satoshi(s) per input.</source>
        <translation type="unfinished">مختلف ہو سکتے ہیں%1 +/- ساتوشی فی ان پٹ۔</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(کوئی لیبل نہیں)</translation>
    </message>
    <message>
        <source>change from %1 (%2)</source>
        <translation type="unfinished">%1 (%2)سے تبدیل کریں</translation>
    </message>
    <message>
        <source>(change)</source>
        <translation type="unfinished">تبدیلی</translation>
    </message>
</context>
<context>
    <name>CreateWalletActivity</name>
    <message>
        <source>Create Wallet</source>
        <extracomment>Title of window indicating the progress of creation of a new wallet.</extracomment>
        <translation type="unfinished">والیٹ بنائیں</translation>
    </message>
    <message>
        <source>Creating Wallet &lt;b&gt;%1&lt;/b&gt;…</source>
        <extracomment>Descriptive text of the create wallet progress window which indicates to the user which wallet is currently being created.</extracomment>
        <translation type="unfinished">والیٹ بنانا &lt;b&gt; %1&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Create wallet failed</source>
        <translation type="unfinished">والیٹ بنانا ناکام ہوگیا۔</translation>
    </message>
    <message>
        <source>Create wallet warning</source>
        <translation type="unfinished">والیٹ بنانے کےلئے انتباہ</translation>
    </message>
    <message>
        <source>Can't list signers</source>
        <translation type="unfinished">دستخط کنندگان کی فہرست نہیں بن سکتی</translation>
    </message>
    </context>
<context>
    <name>OpenWalletActivity</name>
    <message>
        <source>Open wallet failed</source>
        <translation type="unfinished">والیٹ کھولنا ناکام ہو گیا</translation>
    </message>
    <message>
        <source>Open wallet warning</source>
        <translation type="unfinished">والیٹ کھولنے کی انتباہ</translation>
    </message>
    <message>
        <source>default wallet</source>
        <translation type="unfinished">پہلے سے طے شدہ والیٹ</translation>
    </message>
    <message>
        <source>Open Wallet</source>
        <extracomment>Title of window indicating the progress of opening of a wallet.</extracomment>
        <translation type="unfinished">والیٹ کھولیں</translation>
    </message>
    </context>
<context>
    <name>WalletController</name>
    <message>
        <source>Close wallet</source>
        <translation type="unfinished">والیٹ بند کریں</translation>
    </message>
    <message>
        <source>Closing the wallet for too long can result in having to resync the entire chain if pruning is enabled.</source>
        <translation type="unfinished">والیٹ کو زیادہ دیر تک بند کرنے کے نتیجے میں اگر کانٹ چھانٹ کو فعال کیا جاتا ہے تو پوری چین کو دوبارہ ہم آہنگ کرنا پڑ سکتا ہے۔</translation>
    </message>
    <message>
        <source>Close all wallets</source>
        <translation type="unfinished">تمام والیٹس بند کریں</translation>
    </message>
    <message>
        <source>Are you sure you wish to close all wallets?</source>
        <translation type="unfinished">کیا آپ واقعی تمام والیٹس بند کرنا چاہتے ہیں؟</translation>
    </message>
</context>
<context>
    <name>CreateWalletDialog</name>
    <message>
        <source>Create Wallet</source>
        <translation type="unfinished">والیٹ بنائیں</translation>
    </message>
    <message>
        <source>Wallet Name</source>
        <translation type="unfinished">والیٹ کا نام</translation>
    </message>
    <message>
        <source>Wallet</source>
        <translation type="unfinished">والیٹ</translation>
    </message>
    <message>
        <source>Encrypt the wallet. The wallet will be encrypted with a passphrase of your choice.</source>
        <translation type="unfinished">والیٹ کو خفیہ کریں۔ والیٹ کو آپ کی پسند کے پاسفریز کے ساتھ خفیہ کیا جائے گا۔</translation>
    </message>
    <message>
        <source>Encrypt Wallet</source>
        <translation type="unfinished">والیٹ کو خفیہ کریں۔</translation>
    </message>
    <message>
        <source>Advanced Options</source>
        <translation type="unfinished">اعلی درجے کے اختیارات</translation>
    </message>
    <message>
        <source>Disable private keys for this wallet. Wallets with private keys disabled will have no private keys and cannot have an HD seed or imported private keys. This is ideal for watch-only wallets.</source>
        <translation type="unfinished">اس والیٹ کے لیے نجی چابیوں کو غیر فعال کریں۔ غیر فعال نجی چابیوں والے والیٹ میں کوئی نجی چابیاں نہیں ہوں گی اور اس میں HD بیج یا درآمد شدہ نجی چابیاں نہیں ہو سکتیں۔ یہ صرف دیکھنے والے والیٹ کے لیے مثالی ہے۔</translation>
    </message>
    <message>
        <source>Disable Private Keys</source>
        <translation type="unfinished">نجی چابیاں غیر فعال کریں۔</translation>
    </message>
    <message>
        <source>Make a blank wallet. Blank wallets do not initially have private keys or scripts. Private keys and addresses can be imported, or an HD seed can be set, at a later time.</source>
        <translation type="unfinished">ایک خالی والیٹ بنائیں۔ خالی والیٹ میں ابتدائی طور پر نجی چابیاں یا اسکرپٹ نہیں ہوتے ہیں۔ نجی چابیاں اور پتے درآمد کیے جا سکتے ہیں، یا بعد میں ایک HD بیج سیٹ کیا جا سکتا ہے۔</translation>
    </message>
    <message>
        <source>Make Blank Wallet</source>
        <translation type="unfinished">خالی والیٹ بنائیں</translation>
    </message>
    <message>
        <source>Use descriptors for scriptPubKey management</source>
        <translation type="unfinished">ScriptPubKeys کے انتظام کے لیے وضاحت کنندگان کا استعمال کریں۔</translation>
    </message>
    <message>
        <source>Descriptor Wallet</source>
        <translation type="unfinished">وضاحتی والیٹ</translation>
    </message>
    <message>
        <source>Use an external signing device such as a hardware wallet. Configure the external signer script in wallet preferences first.</source>
        <translation type="unfinished">بیرونی دستخط کرنے والا آلہ استعمال کریں جیسے ہارڈ ویئر والیٹ۔ پہلے والیٹ کی ترجیحات میں بیرونی دستخط کنندہ اسکرپٹ کو ترتیب دیں۔</translation>
    </message>
    <message>
        <source>External signer</source>
        <translation type="unfinished">بیرونی دستخط کنندہ</translation>
    </message>
    <message>
        <source>Create</source>
        <translation type="unfinished">بنائیں</translation>
    </message>
    <message>
        <source>Compiled without sqlite support (required for descriptor wallets)</source>
        <translation type="unfinished"> SQliteسپورٹ کے بغیر مرتب کیا گیا (ڈسکرپٹر والیٹس کے لیے درکار)</translation>
    </message>
    <message>
        <source>Compiled without external signing support (required for external signing)</source>
        <extracomment>"External signing" means using devices such as hardware wallets.</extracomment>
        <translation type="unfinished">بیرونی دستخطی معاونت کے بغیر مرتب کیا گیا (بیرونی دستخط کے لیے درکار)</translation>
    </message>
</context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation type="unfinished">ایڈریس میں ترمیم کریں۔</translation>
    </message>
    <message>
        <source>&amp;Label</source>
        <translation type="unfinished">چٹ</translation>
    </message>
    <message>
        <source>The label associated with this address list entry</source>
        <translation type="unfinished">اس ایڈریس لسٹ کے اندراج سے وابستہ لیبل</translation>
    </message>
    <message>
        <source>The address associated with this address list entry. This can only be modified for sending addresses.</source>
        <translation type="unfinished">اس ایڈریس لسٹ کے اندراج سے وابستہ پتہ۔ اس میں صرف ایڈریس بھیجنے کے لیے ترمیم کی جا سکتی ہے۔</translation>
    </message>
    <message>
        <source>&amp;Address</source>
        <translation type="unfinished">پتہ</translation>
    </message>
    <message>
        <source>New sending address</source>
        <translation type="unfinished">نیا بھیجنے کا پتہ</translation>
    </message>
    <message>
        <source>Edit receiving address</source>
        <translation type="unfinished">وصول کنندہ ایڈریس میں ترمیم کریں۔</translation>
    </message>
    <message>
        <source>Edit sending address</source>
        <translation type="unfinished">بھیجنے کے پتے میں ترمیم کریں۔</translation>
    </message>
    <message>
        <source>Could not unlock wallet.</source>
        <translation type="unfinished">والیٹ کو غیر مقفل نہیں کیا جا سکا۔</translation>
    </message>
    <message>
        <source>New key generation failed.</source>
        <translation type="unfinished">نئی کلیدی نسل ناکام ہوگئی۔</translation>
    </message>
</context>
<context>
    <name>FreespaceChecker</name>
    <message>
        <source>A new data directory will be created.</source>
        <translation type="unfinished">ایک نئی ڈیٹا ڈائرکٹری بنائی جائے گی۔</translation>
    </message>
    <message>
        <source>name</source>
        <translation type="unfinished">نام</translation>
    </message>
    <message>
        <source>Path already exists, and is not a directory.</source>
        <translation type="unfinished">پاتھ پہلے سے موجود ہے، اور ڈائرکٹری نہیں ہے۔</translation>
    </message>
    <message>
        <source>Cannot create data directory here.</source>
        <translation type="unfinished">یہاں ڈیٹا ڈائرکٹری نہیں بن سکتی۔</translation>
    </message>
</context>
<context>
    <name>Intro</name>
    <message>
        <source>Kawra</source>
        <translation type="unfinished">بٹ کوائن</translation>
    </message>
    <message numerus="yes">
        <source>%n GB of space available</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>(of %n GB needed)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>(%n GB needed for full chain)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>(sufficient to restore backups %n day(s) old)</source>
        <extracomment>Explanatory text on the capability of the current prune target.</extracomment>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message>
        <source>The wallet will also be stored in this directory.</source>
        <translation type="unfinished">والیٹ بھی اس ڈائرکٹری میں محفوظ کیا جائے گا۔</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">نقص</translation>
    </message>
    <message>
        <source>Welcome</source>
        <translation type="unfinished">خوش آمدید</translation>
    </message>
    <message>
        <source>Limit block chain storage to</source>
        <translation type="unfinished">بلاک چین اسٹوریج کو محدود کریں۔</translation>
    </message>
    <message>
        <source>Reverting this setting requires re-downloading the entire blockchain. It is faster to download the full chain first and prune it later. Disables some advanced features.</source>
        <translation type="unfinished">اس ترتیب کو واپس کرنے کے لیے پورے بلاکچین کو دوبارہ ڈاؤن لوڈ کرنے کی ضرورت ہے۔ پہلے پوری چین کو ڈاؤن لوڈ کرنا اور بعد میں اسے کاٹنا تیز تر ہے۔ کچھ جدید خصوصیات کو غیر فعال کرتا ہے۔</translation>
    </message>
    <message>
        <source> GB</source>
        <translation type="unfinished">جی بی</translation>
    </message>
    <message>
        <source>If you have chosen to limit block chain storage (pruning), the historical data must still be downloaded and processed, but will be deleted afterward to keep your disk usage low.</source>
        <translation type="unfinished">اگر آپ نے بلاک چین اسٹوریج کو محدود کرنے کا انتخاب کیا ہے (کاٹنا)، تو تاریخی ڈیٹا کو ابھی بھی ڈاؤن لوڈ اور پروسیس کیا جانا چاہیے، لیکن آپ کے ڈسک کے استعمال کو کم رکھنے کے لیے اسے بعد میں حذف کر دیا جائے گا۔</translation>
    </message>
    <message>
        <source>Use the default data directory</source>
        <translation type="unfinished">پہلے سے طے شدہ ڈیٹا ڈائرکٹری استعمال کریں۔</translation>
    </message>
    <message>
        <source>Use a custom data directory:</source>
        <translation type="unfinished">اپنی مرضی کے مطابق ڈیٹا ڈائرکٹری کا استعمال کریں:</translation>
    </message>
</context>
<context>
    <name>HelpMessageDialog</name>
    <message>
        <source>version</source>
        <translation type="unfinished">ورژن</translation>
    </message>
    <message>
        <source>About %1</source>
        <translation type="unfinished">تقریبآ %1</translation>
    </message>
    <message>
        <source>Command-line options</source>
        <translation type="unfinished">کمانڈ لائن کے اختیارات</translation>
    </message>
</context>
<context>
    <name>ShutdownWindow</name>
    <message>
        <source>Do not shut down the computer until this window disappears.</source>
        <translation type="unfinished">جب تک یہ ونڈو غائب نہ ہوجائے کمپیوٹر کو بند نہ کریں۔</translation>
    </message>
</context>
<context>
    <name>ModalOverlay</name>
    <message>
        <source>Form</source>
        <translation type="unfinished">فارم</translation>
    </message>
    <message>
        <source>Recent transactions may not yet be visible, and therefore your wallet's balance might be incorrect. This information will be correct once your wallet has finished synchronizing with the kawra network, as detailed below.</source>
        <translation type="unfinished">ہو سکتا ہے حالیہ لین دین ابھی تک نظر نہ آئے، اور اس وجہ سے آپ کے والیٹ کا بیلنس غلط ہو سکتا ہے۔ یہ معلومات درست ہوں گی جب آپ کے والیٹ نے بٹ کوائن نیٹ ورک کے ساتھ مطابقت پذیری مکمل کر لی ہو، جیسا کہ ذیل میں تفصیل ہے۔</translation>
    </message>
    <message>
        <source>Attempting to spend kawras that are affected by not-yet-displayed transactions will not be accepted by the network.</source>
        <translation type="unfinished">ایسے بٹ کوائنز خرچ کرنے کی کوشش کرنا جو ابھی تک ظاہر نہ ہونے والے لین دین سے متاثر ہوں نیٹ ورک کے ذریعے قبول نہیں کیا جائے گا۔</translation>
    </message>
    <message>
        <source>Number of blocks left</source>
        <translation type="unfinished">باقی بلاکس کی تعداد</translation>
    </message>
    <message>
        <source>Unknown…</source>
        <translation type="unfinished">نامعلوم</translation>
    </message>
    <message>
        <source>calculating…</source>
        <translation type="unfinished">حساب لگانا</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation type="unfinished">آخری بلاک کا وقت</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation type="unfinished">پیش رفت</translation>
    </message>
    <message>
        <source>Progress increase per hour</source>
        <translation type="unfinished">فی گھنٹہ پیش رفت میں اضافہ</translation>
    </message>
    <message>
        <source>Estimated time left until synced</source>
        <translation type="unfinished">مطابقت پذیر ہونے میں تخمینی وقت باقی ہے۔</translation>
    </message>
    <message>
        <source>Hide</source>
        <translation type="unfinished">چھپائیں</translation>
    </message>
    </context>
<context>
    <name>OpenURIDialog</name>
    <message>
        <source>Open kawra URI</source>
        <translation type="unfinished">بٹ کوائن URI کھولیں۔</translation>
    </message>
    <message>
        <source>URI:</source>
        <translation type="unfinished">URI</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <extracomment>Tooltip text for button that allows you to paste an address that is in your clipboard.</extracomment>
        <translation type="unfinished">کلپ بورڈ سے پتہ چسپاں کریں۔</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation type="unfinished">اختیارات</translation>
    </message>
    <message>
        <source>&amp;Main</source>
        <translation type="unfinished">اور مرکزی</translation>
    </message>
    <message>
        <source>Enabling pruning significantly reduces the disk space required to store transactions. All blocks are still fully validated. Reverting this setting requires re-downloading the entire blockchain.</source>
        <translation type="unfinished">کٹائی کو فعال کرنا لین دین کو ذخیرہ کرنے کے لیے درکار ڈسک کی جگہ کو نمایاں طور پر کم کرتا ہے۔ تمام بلاکس اب بھی مکمل طور پر درست ہیں۔ اس ترتیب کو واپس کرنے کے لیے پورے بلاکچین کو دوبارہ ڈاؤن لوڈ کرنے کی ضرورت ہے۔</translation>
    </message>
    <message>
        <source>Size of &amp;database cache</source>
        <translation type="unfinished">ڈیٹا بیس کیشے کا سائز</translation>
    </message>
    <message>
        <source>Number of script &amp;verification threads</source>
        <translation type="unfinished">اسکرپٹ اور تصدیقی دھاگوں کی تعداد</translation>
    </message>
    <message>
        <source>IP address of the proxy (e.g. IPv4: 127.0.0.1 / IPv6: ::1)</source>
        <translation type="unfinished">پراکسی کا IP پتہ (جیسے IPv4: 127.0.0.1 / IPv6: ::1)</translation>
    </message>
    <message>
        <source>Shows if the supplied default SOCKS5 proxy is used to reach peers via this network type.</source>
        <translation type="unfinished">یہ دکھاتا ہے کہ کیا فراہم کردہ ڈیفالٹ SOCKS5 پراکسی اس نیٹ ورک کی قسم کے ذریعے ساتھی تک پہنچنے کے لیے استعمال ہوتی ہے۔</translation>
    </message>
    <message>
        <source>Minimize instead of exit the application when the window is closed. When this option is enabled, the application will be closed only after selecting Exit in the menu.</source>
        <translation type="unfinished">ونڈو بند ہونے پر ایپلیکیشن سے باہر نکلنے کے بجائے چھوٹا کریں۔ جب یہ آپشن فعال ہو جائے گا تو مینو میں ایگزٹ کو منتخب کرنے کے بعد ہی ایپلیکیشن بند ہو جائے گی۔</translation>
    </message>
    <message>
        <source>Open Configuration File</source>
        <translation type="unfinished">ترتیب والی فائل کھولیں۔</translation>
    </message>
    <message>
        <source>Reset all client options to default.</source>
        <translation type="unfinished">کلائنٹ کے تمام اختیارات کو ڈیفالٹ پر دوبارہ ترتیب دیں۔</translation>
    </message>
    <message>
        <source>&amp;Reset Options</source>
        <translation type="unfinished">اور دوبارہ ترتیب دینے کے اختیارات</translation>
    </message>
    <message>
        <source>&amp;Network</source>
        <translation type="unfinished">اور نیٹ ورک</translation>
    </message>
    <message>
        <source>GB</source>
        <translation type="unfinished">جی بی</translation>
    </message>
    <message>
        <source>Reverting this setting requires re-downloading the entire blockchain.</source>
        <translation type="unfinished">اس ترتیب کو واپس کرنے کے لیے پورے بلاکچین کو دوبارہ ڈاؤن لوڈ کرنے کی ضرورت ہے۔</translation>
    </message>
    <message>
        <source>Expert</source>
        <translation type="unfinished">ماہر</translation>
    </message>
    <message>
        <source>Enable coin &amp;control features</source>
        <translation type="unfinished">سکے اور کنٹرول کی خصوصیات کو فعال کریں۔</translation>
    </message>
    <message>
        <source>If you disable the spending of unconfirmed change, the change from a transaction cannot be used until that transaction has at least one confirmation. This also affects how your balance is computed.</source>
        <translation type="unfinished">اگر آپ غیر مصدقہ تبدیلی کے اخراجات کو غیر فعال کرتے ہیں، تو کسی لین دین کی تبدیلی کو اس وقت تک استعمال نہیں کیا جا سکتا جب تک کہ اس لین دین کی کم از کم ایک تصدیق نہ ہو۔ اس سے یہ بھی متاثر ہوتا ہے کہ آپ کے بیلنس کا حساب کیسے لیا جاتا ہے۔</translation>
    </message>
    <message>
        <source>&amp;Spend unconfirmed change</source>
        <translation type="unfinished">اور غیر مصدقہ تبدیلی خرچ کریں۔</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation type="unfinished">اور ونڈو</translation>
    </message>
    <message>
        <source>Compiled without external signing support (required for external signing)</source>
        <extracomment>"External signing" means using devices such as hardware wallets.</extracomment>
        <translation type="unfinished">بیرونی دستخطی معاونت کے بغیر مرتب کیا گیا (بیرونی دستخط کے لیے درکار)</translation>
    </message>
    <message>
        <source>default</source>
        <translation type="unfinished">پہلے سے طے شدہ</translation>
    </message>
    <message>
        <source>none</source>
        <translation type="unfinished">کوئی نہیں</translation>
    </message>
    <message>
        <source>Confirm options reset</source>
        <extracomment>Window title text of pop-up window shown when the user has chosen to reset options.</extracomment>
        <translation type="unfinished">اختیارات کو دوبارہ ترتیب دینے کی تصدیق کریں۔</translation>
    </message>
    <message>
        <source>Client restart required to activate changes.</source>
        <extracomment>Text explaining that the settings changed will not come into effect until the client is restarted.</extracomment>
        <translation type="unfinished">تبدیلیوں کو چالو کرنے کے لیے کلائنٹ کو دوبارہ شروع کرنا ضروری ہے۔</translation>
    </message>
    <message>
        <source>Client will be shut down. Do you want to proceed?</source>
        <extracomment>Text asking the user to confirm if they would like to proceed with a client shutdown.</extracomment>
        <translation type="unfinished">کلائنٹ کو بند کر دیا جائے گا۔ کیا آپ آگے بڑھنا چاہتے ہیں؟</translation>
    </message>
    <message>
        <source>Configuration options</source>
        <extracomment>Window title text of pop-up box that allows opening up of configuration file.</extracomment>
        <translation type="unfinished">کنفیگریشن کے اختیارات</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">نقص</translation>
    </message>
    <message>
        <source>This change would require a client restart.</source>
        <translation type="unfinished">اس تبدیلی کو کلائنٹ کو دوبارہ شروع کرنے کی ضرورت ہوگی۔</translation>
    </message>
    <message>
        <source>The supplied proxy address is invalid.</source>
        <translation type="unfinished">فراہم کردہ پراکسی پتہ غلط ہے۔</translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Form</source>
        <translation type="unfinished">فارم</translation>
    </message>
    <message>
        <source>The displayed information may be out of date. Your wallet automatically synchronizes with the Kawra network after a connection is established, but this process has not completed yet.</source>
        <translation type="unfinished">ظاہر کی گئی معلومات پرانی ہو سکتی ہے۔ کنکشن قائم ہونے کے بعد آپ کا والیٹ خود بخود بٹ کوائن نیٹ ورک کے ساتھ ہم آہنگ ہوجاتا ہے، لیکن یہ عمل ابھی مکمل نہیں ہوا ہے۔</translation>
    </message>
    <message>
        <source>Watch-only:</source>
        <translation type="unfinished">صرف دیکھنے کے لیے:</translation>
    </message>
    <message>
        <source>Available:</source>
        <translation type="unfinished">دستیاب:</translation>
    </message>
    <message>
        <source>Your current spendable balance</source>
        <translation type="unfinished">آپ کا موجودہ قابل خرچ بیلنس</translation>
    </message>
    <message>
        <source>Pending:</source>
        <translation type="unfinished">زیر التواء</translation>
    </message>
    <message>
        <source>Total of transactions that have yet to be confirmed, and do not yet count toward the spendable balance</source>
        <translation type="unfinished">کل ٹرانزیکشنز جن کی تصدیق ہونا باقی ہے، اور ابھی تک قابل خرچ بیلنس میں شمار نہیں ہوتے </translation>
    </message>
    <message>
        <source>Immature:</source>
        <translation type="unfinished">خام</translation>
    </message>
    <message>
        <source>Mined balance that has not yet matured</source>
        <translation type="unfinished">کان کنی کا توازن جو ابھی پختہ نہیں ہوا ہے۔</translation>
    </message>
    <message>
        <source>Balances</source>
        <translation type="unfinished">بیلنس</translation>
    </message>
    <message>
        <source>Total:</source>
        <translation type="unfinished">کل:</translation>
    </message>
    <message>
        <source>Your current total balance</source>
        <translation type="unfinished">آپ کا کل موجودہ بیلنس</translation>
    </message>
    <message>
        <source>Your current balance in watch-only addresses</source>
        <translation type="unfinished">صرف دیکھنے والے ایڈریسز میں آپ کا موجودہ بیلنس</translation>
    </message>
    <message>
        <source>Spendable:</source>
        <translation type="unfinished">قابل خرچ:</translation>
    </message>
    <message>
        <source>Recent transactions</source>
        <translation type="unfinished">حالیہ لین دین</translation>
    </message>
    <message>
        <source>Unconfirmed transactions to watch-only addresses</source>
        <translation type="unfinished">صرف دیکھنے والے پتوں پر غیر تصدیق شدہ لین دین</translation>
    </message>
    <message>
        <source>Current total balance in watch-only addresses</source>
        <translation type="unfinished">صرف دیکھنے کے پتوں میں کل موجودہ بیلنس</translation>
    </message>
    <message>
        <source>Privacy mode activated for the Overview tab. To unmask the values, uncheck Settings-&gt;Mask values.</source>
        <translation type="unfinished">جائزہ ٹیب کے لیے پرائیویسی موڈ کو فعال کر دیا گیا ہے۔ اقدار کو ہٹانے کے لیے، سیٹنگز-&gt;ماسک ویلیوز کو غیر چیک کریں۔</translation>
    </message>
</context>
<context>
    <name>PSBTOperationsDialog</name>
    <message>
        <source>Copy to Clipboard</source>
        <translation type="unfinished">کلپ بورڈ پر کاپی کریں۔</translation>
    </message>
    <message>
        <source>Save…</source>
        <translation type="unfinished">محفوظ کریں۔</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished">بند کریں</translation>
    </message>
    <message>
        <source>Failed to load transaction: %1</source>
        <translation type="unfinished">لین دین لوڈ کرنے میں ناکام:%1</translation>
    </message>
    <message>
        <source>Failed to sign transaction: %1</source>
        <translation type="unfinished">لین دین پر دستخط کرنے میں ناکام:%1</translation>
    </message>
    <message>
        <source>Could not sign any more inputs.</source>
        <translation type="unfinished">مزید ان پٹ پر دستخط نہیں ہو سکے۔</translation>
    </message>
    <message>
        <source>Save Transaction Data</source>
        <translation type="unfinished">لین دین کا ڈیٹا محفوظ کریں۔</translation>
    </message>
    <message>
        <source>Total Amount</source>
        <translation type="unfinished">کل رقم</translation>
    </message>
    <message>
        <source>or</source>
        <translation type="unfinished">یا</translation>
    </message>
    <message>
        <source>Transaction still needs signature(s).</source>
        <translation type="unfinished">لین دین کو ابھی بھی دستخط کی ضرورت ہے۔</translation>
    </message>
    <message>
        <source>(But this wallet cannot sign transactions.)</source>
        <translation type="unfinished">(لیکن یہ والیٹ لین دین پر دستخط نہیں کر سکتا۔)</translation>
    </message>
    <message>
        <source>Transaction status is unknown.</source>
        <translation type="unfinished">لین دین کی حیثیت نامعلوم ہے۔</translation>
    </message>
</context>
<context>
    <name>PaymentServer</name>
    <message>
        <source>Payment request error</source>
        <translation type="unfinished">ادائیگی کی درخواست کی خرابی۔</translation>
    </message>
    <message>
        <source>Cannot process payment request because BIP70 is not supported.
Due to widespread security flaws in BIP70 it's strongly recommended that any merchant instructions to switch wallets be ignored.
If you are receiving this error you should request the merchant provide a BIP21 compatible URI.</source>
        <translation type="unfinished">ادائیگی کی درخواست پر کارروائی نہیں کی جا سکتی کیونکہ BIP70 تعاون یافتہ نہیں ہے۔ BIP70 میں سیکورٹی کی وسیع خامیوں کی وجہ سے یہ پرزور مشورہ دیا جاتا ہے کہ والیٹ کو تبدیل کرنے کے لیے کسی بھی تاجر کی ہدایات کو نظر انداز کر دیا جائے۔ اگر آپ کو یہ خرابی موصول ہو رہی ہے تو آپ کو مرچنٹ سے BIP21 مطابقت پذیر URI فراہم کرنے کی درخواست کرنی چاہیے۔</translation>
    </message>
    </context>
<context>
    <name>PeerTableModel</name>
    <message>
        <source>User Agent</source>
        <extracomment>Title of Peers Table column which contains the peer's User Agent string.</extracomment>
        <translation type="unfinished">صارف ایجنٹ</translation>
    </message>
    <message>
        <source>Ping</source>
        <extracomment>Title of Peers Table column which indicates the current latency of the connection with the peer.</extracomment>
        <translation type="unfinished">پنگ</translation>
    </message>
    <message>
        <source>Peer</source>
        <extracomment>Title of Peers Table column which contains a unique number used to identify a connection.</extracomment>
        <translation type="unfinished">فریق</translation>
    </message>
    <message>
        <source>Sent</source>
        <extracomment>Title of Peers Table column which indicates the total amount of network information we have sent to the peer.</extracomment>
        <translation type="unfinished">بھیجا</translation>
    </message>
    <message>
        <source>Received</source>
        <extracomment>Title of Peers Table column which indicates the total amount of network information we have received from the peer.</extracomment>
        <translation type="unfinished">موصول ہوا۔</translation>
    </message>
    <message>
        <source>Address</source>
        <extracomment>Title of Peers Table column which contains the IP/Onion/I2P address of the connected peer.</extracomment>
        <translation type="unfinished">پتہ</translation>
    </message>
    <message>
        <source>Type</source>
        <extracomment>Title of Peers Table column which describes the type of peer connection. The "type" describes why the connection exists.</extracomment>
        <translation type="unfinished">قسم</translation>
    </message>
    <message>
        <source>Network</source>
        <extracomment>Title of Peers Table column which states the network the peer connected through.</extracomment>
        <translation type="unfinished">نیٹ ورک</translation>
    </message>
    </context>
<context>
    <name>QRImageWidget</name>
    <message>
        <source>&amp;Save Image…</source>
        <translation type="unfinished">اور تصویر محفوظ کریں…</translation>
    </message>
    <message>
        <source>&amp;Copy Image</source>
        <translation type="unfinished">اور تصویر کاپی کریں۔</translation>
    </message>
    <message>
        <source>Save QR Code</source>
        <translation type="unfinished">کیو آر کوڈ محفوظ کریں۔</translation>
    </message>
    </context>
<context>
    <name>RPCConsole</name>
    <message>
        <source>&amp;Information</source>
        <translation type="unfinished">اور معلومات</translation>
    </message>
    <message>
        <source>Startup time</source>
        <translation type="unfinished">آغاز کا وقت</translation>
    </message>
    <message>
        <source>Network</source>
        <translation type="unfinished">نیٹ ورک</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished">نام</translation>
    </message>
    <message>
        <source>Number of connections</source>
        <translation type="unfinished">رابطوں کی تعداد</translation>
    </message>
    <message>
        <source>Block chain</source>
        <translation type="unfinished">بلاک چین</translation>
    </message>
    <message>
        <source>Current number of transactions</source>
        <translation type="unfinished">لین دین کی موجودہ تعداد</translation>
    </message>
    <message>
        <source>Memory usage</source>
        <translation type="unfinished">استعمال یاد داشت</translation>
    </message>
    <message>
        <source>Wallet: </source>
        <translation type="unfinished">والیٹ</translation>
    </message>
    <message>
        <source>(none)</source>
        <translation type="unfinished">(کوئی نہیں)</translation>
    </message>
    <message>
        <source>Received</source>
        <translation type="unfinished">موصول ہوا۔</translation>
    </message>
    <message>
        <source>Sent</source>
        <translation type="unfinished">بھیجا</translation>
    </message>
    <message>
        <source>&amp;Peers</source>
        <translation type="unfinished">اور فریق</translation>
    </message>
    <message>
        <source>Banned peers</source>
        <translation type="unfinished">ممنوعہ فریقوں</translation>
    </message>
    <message>
        <source>Select a peer to view detailed information.</source>
        <translation type="unfinished">تفصیلی معلومات دیکھنے کے لیے فریق کا انتخاب کریں۔</translation>
    </message>
    <message>
        <source>Starting Block</source>
        <translation type="unfinished">شروع ہونے والا بلاک</translation>
    </message>
    <message>
        <source>Synced Blocks</source>
        <translation type="unfinished">مطابقت پذیر بلاکس</translation>
    </message>
    <message>
        <source>User Agent</source>
        <translation type="unfinished">صارف ایجنٹ</translation>
    </message>
    <message>
        <source>Node window</source>
        <translation type="unfinished">نوڈ ونڈو</translation>
    </message>
    <message>
        <source>Current block height</source>
        <translation type="unfinished">موجودہ بلاک کی اونچائی</translation>
    </message>
    <message>
        <source>Decrease font size</source>
        <translation type="unfinished">فونٹ کا سائز کم کریں۔</translation>
    </message>
    <message>
        <source>Increase font size</source>
        <translation type="unfinished">فونٹ سائز میں اضافہ کریں</translation>
    </message>
    <message>
        <source>Permissions</source>
        <translation type="unfinished">اجازتیں</translation>
    </message>
    <message>
        <source>Services</source>
        <translation type="unfinished">خدمات</translation>
    </message>
    <message>
        <source>Connection Time</source>
        <translation type="unfinished">کنکشن کا وقت</translation>
    </message>
    <message>
        <source>Elapsed time since a novel block passing initial validity checks was received from this peer.</source>
        <translation type="unfinished">اس فریق کی جانب سے ابتدائی درستگی کی جانچ پڑتال کرنے والا ایک نیا بلاک موصول ہونے کے بعد گزرا ہوا وقت۔</translation>
    </message>
    <message>
        <source>Last Block</source>
        <translation type="unfinished">آخری بلاک</translation>
    </message>
    <message>
        <source>Last Send</source>
        <translation type="unfinished">آخری بھیجا۔</translation>
    </message>
    <message>
        <source>Last Receive</source>
        <translation type="unfinished">آخری موصول</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation type="unfinished">آخری بلاک کا وقت</translation>
    </message>
    <message>
        <source>Totals</source>
        <translation type="unfinished">کل</translation>
    </message>
    <message>
        <source>Clear console</source>
        <translation type="unfinished">کنسول صاف کریں۔</translation>
    </message>
    <message>
        <source>In:</source>
        <translation type="unfinished">میں:</translation>
    </message>
    <message>
        <source>Out:</source>
        <translation type="unfinished">باہر:</translation>
    </message>
    <message>
        <source>&amp;Copy address</source>
        <extracomment>Context menu action to copy the address of a peer.</extracomment>
        <translation type="unfinished">ایڈریس کاپی کریں۔</translation>
    </message>
    <message>
        <source>&amp;Disconnect</source>
        <translation type="unfinished">اور منقطع کریں۔</translation>
    </message>
    <message>
        <source>Network activity disabled</source>
        <translation type="unfinished">نیٹ ورک کی سرگرمی غیر فعال ہے۔</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="unfinished">جی ہاں</translation>
    </message>
    <message>
        <source>No</source>
        <translation type="unfinished">نہیں</translation>
    </message>
    <message>
        <source>To</source>
        <translation type="unfinished">کو</translation>
    </message>
    <message>
        <source>From</source>
        <translation type="unfinished">سے</translation>
    </message>
    <message>
        <source>Ban for</source>
        <translation type="unfinished">کے لیے پابندی</translation>
    </message>
    <message>
        <source>Never</source>
        <translation type="unfinished">کبھی نہیں</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation type="unfinished">نامعلوم</translation>
    </message>
</context>
<context>
    <name>ReceiveCoinsDialog</name>
    <message>
        <source>&amp;Amount:</source>
        <translation type="unfinished">اور رقم</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation type="unfinished">اور لیبل</translation>
    </message>
    <message>
        <source>&amp;Message:</source>
        <translation type="unfinished">اور پیغام</translation>
    </message>
    <message>
        <source>An optional message to attach to the payment request, which will be displayed when the request is opened. Note: The message will not be sent with the payment over the Kawra network.</source>
        <translation type="unfinished">ادائیگی کی درخواست کے ساتھ منسلک کرنے کے لیے ایک اختیاری پیغام، جو درخواست کے کھلنے پر ظاہر ہوگا۔ نوٹ: پیغام بٹ کوائن نیٹ ورک پر ادائیگی کے ساتھ نہیں بھیجا جائے گا۔</translation>
    </message>
    <message>
        <source>An optional label to associate with the new receiving address.</source>
        <translation type="unfinished">نئے وصول کنندہ پتے کے ساتھ منسلک کرنے کے لیے ایک اختیاری لیبل۔</translation>
    </message>
    <message>
        <source>An optional amount to request. Leave this empty or zero to not request a specific amount.</source>
        <translation type="unfinished">درخواست کرنے کے لیے ایک اختیاری رقم۔ کسی مخصوص رقم کی درخواست نہ کرنے کے لیے اسے خالی یا صفر چھوڑ دیں۔</translation>
    </message>
    <message>
        <source>An optional label to associate with the new receiving address (used by you to identify an invoice).  It is also attached to the payment request.</source>
        <translation type="unfinished">وصول کرنے والے نئے پتے کے ساتھ منسلک کرنے کے لیے ایک اختیاری لیبل (آپ کی طرف سے رسید کی شناخت کے لیے استعمال کیا جاتا ہے)۔ یہ ادائیگی کی درخواست کے ساتھ بھی منسلک ہے۔</translation>
    </message>
    <message>
        <source>An optional message that is attached to the payment request and may be displayed to the sender.</source>
        <translation type="unfinished">ایک اختیاری پیغام جو ادائیگی کی درخواست کے ساتھ منسلک ہے اور بھیجنے والے کو دکھایا جا سکتا ہے۔</translation>
    </message>
    <message>
        <source>&amp;Create new receiving address</source>
        <translation type="unfinished">اور وصول کرنے کا نیا پتہ بنائیں</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation type="unfinished">صاف</translation>
    </message>
    <message>
        <source>&amp;Copy address</source>
        <translation type="unfinished">ایڈریس کاپی کریں۔</translation>
    </message>
    <message>
        <source>Copy &amp;label</source>
        <translation type="unfinished">کاپی اور لیبل</translation>
    </message>
    <message>
        <source>Copy &amp;amount</source>
        <translation type="unfinished">کاپی اور رقم</translation>
    </message>
    <message>
        <source>Could not unlock wallet.</source>
        <translation type="unfinished">والیٹ کو غیر مقفل نہیں کیا جا سکا۔</translation>
    </message>
    </context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>Request payment to …</source>
        <translation type="unfinished">ادائیگی کی درخواست کریں…</translation>
    </message>
    <message>
        <source>Address:</source>
        <translation type="unfinished">پتہ:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation type="unfinished">رقم:</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation type="unfinished">لیبل</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation type="unfinished">پیغام</translation>
    </message>
    <message>
        <source>Wallet:</source>
        <translation type="unfinished">پرس:</translation>
    </message>
    <message>
        <source>Copy &amp;Address</source>
        <translation type="unfinished">کاپی پتہ</translation>
    </message>
    <message>
        <source>&amp;Save Image…</source>
        <translation type="unfinished">اور تصویر محفوظ کریں…</translation>
    </message>
    </context>
<context>
    <name>RecentRequestsTableModel</name>
    <message>
        <source>Date</source>
        <translation type="unfinished">تاریخ</translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished">لیبل</translation>
    </message>
    <message>
        <source>Message</source>
        <translation type="unfinished">پیغام</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(کوئی لیبل نہیں)</translation>
    </message>
    <message>
        <source>Requested</source>
        <translation type="unfinished">درخواست کی۔</translation>
    </message>
</context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Send Coins</source>
        <translation type="unfinished">سکے بھیجیں۔</translation>
    </message>
    <message>
        <source>Coin Control Features</source>
        <translation type="unfinished">سکوں کے کنٹرول کی خصوصیات</translation>
    </message>
    <message>
        <source>automatically selected</source>
        <translation type="unfinished">خود بخود منتخب</translation>
    </message>
    <message>
        <source>Insufficient funds!</source>
        <translation type="unfinished">ناکافی فنڈز</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation type="unfinished">مقدار:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation type="unfinished">بائٹس:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation type="unfinished">رقم:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation type="unfinished">فیس:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation type="unfinished">فیس کے بعد:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation type="unfinished">تبدیلی:</translation>
    </message>
    <message>
        <source>If this is activated, but the change address is empty or invalid, change will be sent to a newly generated address.</source>
        <translation type="unfinished">اگر یہ فعال ہے، لیکن تبدیلی کا پتہ خالی یا غلط ہے، تبدیلی کو نئے پیدا کردہ پتے پر بھیج دیا جائے گا۔</translation>
    </message>
    <message>
        <source>Transaction Fee:</source>
        <translation type="unfinished">ٹرانزیکشن فیس:</translation>
    </message>
    <message>
        <source>Warning: Fee estimation is currently not possible.</source>
        <translation type="unfinished">انتباہ: فیس کا تخمینہ فی الحال ممکن نہیں ہے۔</translation>
    </message>
    <message>
        <source>per kilobyte</source>
        <translation type="unfinished">فی کلو بائٹ(kb)</translation>
    </message>
    <message>
        <source>Hide</source>
        <translation type="unfinished">چھپائیں</translation>
    </message>
    <message>
        <source>Recommended:</source>
        <translation type="unfinished">تجویز کردہ:</translation>
    </message>
    <message>
        <source>Custom:</source>
        <translation type="unfinished">اپنی مرضی کے مطابق:</translation>
    </message>
    <message>
        <source>Send to multiple recipients at once</source>
        <translation type="unfinished">ایک ساتھ متعدد وصول کنندگان کو بھیجیں۔</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation type="unfinished">نہ ہونے کے برابر</translation>
    </message>
    <message>
        <source>Choose…</source>
        <translation type="unfinished">منتخب کریں…</translation>
    </message>
    <message>
        <source>Hide transaction fee settings</source>
        <translation type="unfinished">لین دین کی فیس کی ترتیبات چھپائیں۔</translation>
    </message>
    <message>
        <source>A too low fee might result in a never confirming transaction (read the tooltip)</source>
        <translation type="unfinished">بہت کم فیس کے نتیجے میں کبھی بھی تصدیق نہ ہونے والی لین دین ہو سکتی ہے (ٹول ٹپ پڑھیں)</translation>
    </message>
    <message>
        <source>Confirmation time target:</source>
        <translation type="unfinished">تصدیقی وقت کا ہدف:</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation type="unfinished">بیلنس:</translation>
    </message>
    <message>
        <source>Confirm the send action</source>
        <translation type="unfinished">بھیجنے کی کارروائی کی تصدیق کریں۔</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation type="unfinished">مقدار کاپی کریں</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation type="unfinished">رقم کاپی کریں۔</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation type="unfinished">فیس کاپی کریں</translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation type="unfinished">فیس کے بعد کاپی کریں۔</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation type="unfinished">بائٹس کاپی کریں</translation>
    </message>
    <message>
        <source>Copy dust</source>
        <translation type="unfinished">باقی شدہ کاپی کریں</translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation type="unfinished">تبدیلی کاپی کریں</translation>
    </message>
    <message>
        <source>Connect your hardware wallet first.</source>
        <translation type="unfinished">پہلے اپنے ہارڈویئر والیٹ کو جوڑیں۔</translation>
    </message>
    <message>
        <source>To review recipient list click "Show Details…"</source>
        <translation type="unfinished">وصول کنندگان کی فہرست کا جائزہ لینے کے لیے "تفصیلات دکھائیں..." پر کلک کریں۔</translation>
    </message>
    <message>
        <source>Sign failed</source>
        <translation type="unfinished">دستخط ناکام ہوگیا</translation>
    </message>
    <message>
        <source>External signer not found</source>
        <extracomment>"External signer" means using devices such as hardware wallets.</extracomment>
        <translation type="unfinished">بیرونی دستخط کنندہ نہیں ملا</translation>
    </message>
    <message>
        <source>External signer failure</source>
        <extracomment>"External signer" means using devices such as hardware wallets.</extracomment>
        <translation type="unfinished">بیرونی دستخط کنندہ کی ناکامی۔</translation>
    </message>
    <message>
        <source>Save Transaction Data</source>
        <translation type="unfinished">لین دین کا ڈیٹا محفوظ کریں۔</translation>
    </message>
    <message>
        <source>External balance:</source>
        <translation type="unfinished">بیرونی توازن:</translation>
    </message>
    <message>
        <source>or</source>
        <translation type="unfinished">یا</translation>
    </message>
    <message>
        <source>Please, review your transaction.</source>
        <extracomment>Text to prompt a user to review the details of the transaction they are attempting to send.</extracomment>
        <translation type="unfinished">براہ کرم، اپنے لین دین کا جائزہ لیں۔</translation>
    </message>
    <message>
        <source>Transaction fee</source>
        <translation type="unfinished">ٹرانزیکشن فیس</translation>
    </message>
    <message>
        <source>Total Amount</source>
        <translation type="unfinished">کل رقم</translation>
    </message>
    <message>
        <source>Confirm send coins</source>
        <translation type="unfinished">سکے بھیجنے کی تصدیق کریں۔</translation>
    </message>
    <message>
        <source>The recipient address is not valid. Please recheck.</source>
        <translation type="unfinished">وصول کنندہ کا پتہ درست نہیں ہے۔ براہ کرم دوبارہ چیک کریں۔</translation>
    </message>
    <message>
        <source>The amount to pay must be larger than 0.</source>
        <translation type="unfinished">ادا کرنے کی رقم 0 سے زیادہ ہونی چاہیے۔</translation>
    </message>
    <message>
        <source>The amount exceeds your balance.</source>
        <translation type="unfinished">رقم آپ کے بیلنس سے زیادہ ہے۔</translation>
    </message>
    <message>
        <source>Duplicate address found: addresses should only be used once each.</source>
        <translation type="unfinished">ڈپلیکیٹ پتہ ملا: پتے صرف ایک بار استعمال کیے جائیں۔</translation>
    </message>
    <message>
        <source>Transaction creation failed!</source>
        <translation type="unfinished">لین دین کی تخلیق ناکام ہو گئی!</translation>
    </message>
    <message numerus="yes">
        <source>Estimated to begin confirmation within %n block(s).</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message>
        <source>Warning: Invalid Kawra address</source>
        <translation type="unfinished">انتباہ: غلط بٹ کوائن ایڈریس</translation>
    </message>
    <message>
        <source>Warning: Unknown change address</source>
        <translation type="unfinished">انتباہ: نامعلوم تبدیلی کا پتہ</translation>
    </message>
    <message>
        <source>Confirm custom change address</source>
        <translation type="unfinished">اپنی مرضی کے مطابق ایڈریس کی تبدیلی کی تصدیق کریں۔</translation>
    </message>
    <message>
        <source>The address you selected for change is not part of this wallet. Any or all funds in your wallet may be sent to this address. Are you sure?</source>
        <translation type="unfinished">آپ نے تبدیلی کے لیے جو پتہ منتخب کیا ہے وہ اس والیٹ کا حصہ نہیں ہے۔ آپ کے والیٹ میں موجود کوئی بھی یا تمام فنڈز اس پتے پر بھیجے جا سکتے ہیں۔ کیا آپ کو یقین ہے؟</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(کوئی لیبل نہیں)</translation>
    </message>
</context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>&amp;Label:</source>
        <translation type="unfinished">اور لیبل</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation type="unfinished">پہلے استعمال شدہ پتہ کا انتخاب کریں۔</translation>
    </message>
    <message>
        <source>The Kawra address to send the payment to</source>
        <translation type="unfinished">ادائیگی بھیجنے کے لیے بٹ کوائن کا پتہ</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation type="unfinished">کلپ بورڈ سے پتہ چسپاں کریں۔</translation>
    </message>
    <message>
        <source>Remove this entry</source>
        <translation type="unfinished">اس اندراج کو ہٹا دیں۔</translation>
    </message>
    <message>
        <source>The amount to send in the selected unit</source>
        <translation type="unfinished">منتخب یونٹ میں بھیجی جانے والی رقم</translation>
    </message>
    <message>
        <source>The fee will be deducted from the amount being sent. The recipient will receive less kawras than you enter in the amount field. If multiple recipients are selected, the fee is split equally.</source>
        <translation type="unfinished">بھیجی جانے والی رقم سے فیس کاٹی جائے گی۔ وصول کنندہ کو اس سے کم بٹ کوائنز موصول ہوں گے جو آپ رقم کے خانے میں داخل کریں گے۔ اگر متعدد وصول کنندگان کو منتخب کیا جاتا ہے، تو فیس کو برابر تقسیم کیا جاتا ہے۔</translation>
    </message>
    <message>
        <source>Use available balance</source>
        <translation type="unfinished">دستیاب بیلنس استعمال کریں۔</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation type="unfinished">پیغام</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to the list of used addresses</source>
        <translation type="unfinished">استعمال شدہ پتوں کی فہرست میں شامل کرنے کے لیے اس پتے کے لیے ایک لیبل درج کریں۔</translation>
    </message>
    </context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>Signatures - Sign / Verify a Message</source>
        <translation type="unfinished">دستخط - ایک پیغام پر دستخط / تصدیق کریں۔</translation>
    </message>
    <message>
        <source>You can sign messages/agreements with your addresses to prove you can receive kawras sent to them. Be careful not to sign anything vague or random, as phishing attacks may try to trick you into signing your identity over to them. Only sign fully-detailed statements you agree to.</source>
        <translation type="unfinished">آپ یہ ثابت کرنے کے لیے اپنے پتوں کے ساتھ پیغامات/معاہدوں پر دستخط کر سکتے ہیں کہ آپ ان پر بھیجے گئے بٹ کوائنز وصول کر سکتے ہیں۔ ہوشیار رہیں کہ کسی بھی مبہم یا بے ترتیب پر دستخط نہ کریں، کیونکہ فریب دہی کے حملے آپ کو اپنی شناخت پر دستخط کرنے کے لیے دھوکہ دینے کی کوشش کر سکتے ہیں۔ صرف مکمل تفصیلی بیانات پر دستخط کریں جن سے آپ اتفاق کرتے ہیں۔</translation>
    </message>
    <message>
        <source>The Kawra address to sign the message with</source>
        <translation type="unfinished">پیغام پر دستخط کرنے کے لیے بٹ کوائن کا پتہ</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation type="unfinished">پہلے استعمال شدہ پتہ کا انتخاب کریں۔</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation type="unfinished">کلپ بورڈ سے پتہ چسپاں کریں۔</translation>
    </message>
    <message>
        <source>Enter the message you want to sign here</source>
        <translation type="unfinished">وہ پیغام درج کریں جس پر آپ دستخط کرنا چاہتے ہیں۔</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation type="unfinished">دستخط</translation>
    </message>
    <message>
        <source>The entered address is invalid.</source>
        <translation type="unfinished">درج کیا گیا پتہ غلط ہے۔</translation>
    </message>
    <message>
        <source>Please check the address and try again.</source>
        <translation type="unfinished">براہ کرم پتہ چیک کریں اور دوبارہ کوشش کریں۔</translation>
    </message>
    <message>
        <source>No error</source>
        <translation type="unfinished">کوئی غلطی نہیں۔</translation>
    </message>
    <message>
        <source>Message signing failed.</source>
        <translation type="unfinished">پیغام پر دستخط ناکام ہو گئے۔</translation>
    </message>
    <message>
        <source>The signature could not be decoded.</source>
        <translation type="unfinished">دستخط کو ڈی کوڈ نہیں کیا جا سکا۔</translation>
    </message>
    <message>
        <source>Please check the signature and try again.</source>
        <translation type="unfinished">براہ کرم دستخط چیک کریں اور دوبارہ کوشش کریں۔</translation>
    </message>
    <message>
        <source>Message verification failed.</source>
        <translation type="unfinished">پیغام کی تصدیق ناکام ہو گئی۔</translation>
    </message>
    <message>
        <source>Message verified.</source>
        <translation type="unfinished">پیغام کی تصدیق ہو گئی۔</translation>
    </message>
</context>
<context>
    <name>TransactionDesc</name>
    <message>
        <source>Date</source>
        <translation type="unfinished">تاریخ</translation>
    </message>
    <message>
        <source>From</source>
        <translation type="unfinished">سے</translation>
    </message>
    <message>
        <source>unknown</source>
        <translation type="unfinished">نامعلوم</translation>
    </message>
    <message>
        <source>To</source>
        <translation type="unfinished">کو</translation>
    </message>
    <message numerus="yes">
        <source>matures in %n more block(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message>
        <source>Transaction fee</source>
        <translation type="unfinished">ٹرانزیکشن فیس</translation>
    </message>
    <message>
        <source>Message</source>
        <translation type="unfinished">پیغام</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">رقم</translation>
    </message>
    </context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Date</source>
        <translation type="unfinished">تاریخ</translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished">قسم</translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished">لیبل</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(کوئی لیبل نہیں)</translation>
    </message>
    </context>
<context>
    <name>TransactionView</name>
    <message>
        <source>&amp;Copy address</source>
        <translation type="unfinished">ایڈریس کاپی کریں۔</translation>
    </message>
    <message>
        <source>Copy &amp;label</source>
        <translation type="unfinished">کاپی اور لیبل</translation>
    </message>
    <message>
        <source>Copy &amp;amount</source>
        <translation type="unfinished">کاپی اور رقم</translation>
    </message>
    <message>
        <source>Copy transaction &amp;ID</source>
        <translation type="unfinished">لین دین اور شناخت کی تفصیلات(ID) کاپی کریں۔</translation>
    </message>
    <message>
        <source>Comma separated file</source>
        <extracomment>Expanded name of the CSV file format. See: https://en.wikipedia.org/wiki/Comma-separated_values.</extracomment>
        <translation type="unfinished">کوما سے الگ فائل</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation type="unfinished">تصدیق شدہ</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished">تاریخ</translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished">قسم</translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished">لیبل</translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="unfinished">پتہ</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation type="unfinished">ایکسپورٹ ناکام ہوا</translation>
    </message>
    </context>
<context>
    <name>WalletFrame</name>
    <message>
        <source>Create a new wallet</source>
        <translation type="unfinished">ایک نیا پرس بنائیں</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">نقص</translation>
    </message>
    </context>
<context>
    <name>WalletModel</name>
    <message>
        <source>Send Coins</source>
        <translation type="unfinished">سکے بھیجیں۔</translation>
    </message>
    <message>
        <source>default wallet</source>
        <translation type="unfinished">پہلے سے طے شدہ والیٹ</translation>
    </message>
</context>
<context>
    <name>WalletView</name>
    <message>
        <source>&amp;Export</source>
        <translation type="unfinished">برآمد</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation type="unfinished">موجودہ ڈیٹا کو فائیل میں محفوظ کریں</translation>
    </message>
    </context>
<context>
    <name>kawra-core</name>
    <message>
        <source>Insufficient funds</source>
        <translation type="unfinished">ناکافی فنڈز</translation>
    </message>
    </context>
</TS>