<TS version="2.1" language="eo">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Right-click to edit address or label</source>
        <translation type="unfinished">Dekstre-klaku por redakti adreson aŭ etikedon</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation type="unfinished">Krei novan adreson</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation type="unfinished">&amp;Nova</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation type="unfinished">Kopii elektitan adreson al la tondejo</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation type="unfinished">&amp;Kopii</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation type="unfinished">&amp;Fermi</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation type="unfinished">Forigi la elektitan adreson el la listo</translation>
    </message>
    <message>
        <source>Enter address or label to search</source>
        <translation type="unfinished">Tajpu adreson aŭ etikedon por serĉi</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation type="unfinished">Eksporti la datumojn el la aktuala langeto al dosiero</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation type="unfinished">&amp;Eksporti</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation type="unfinished">&amp;Forigi</translation>
    </message>
    <message>
        <source>Choose the address to send coins to</source>
        <translation type="unfinished">Elekti la adreson por sendi monerojn</translation>
    </message>
    <message>
        <source>Choose the address to receive coins with</source>
        <translation type="unfinished">Elekti la adreson ricevi monerojn kun</translation>
    </message>
    <message>
        <source>C&amp;hoose</source>
        <translation type="unfinished">&amp;Elekti</translation>
    </message>
    <message>
        <source>Sending addresses</source>
        <translation type="unfinished">Sendaj adresoj</translation>
    </message>
    <message>
        <source>Receiving addresses</source>
        <translation type="unfinished">Ricevaj adresoj</translation>
    </message>
    <message>
        <source>These are your Kawra addresses for sending payments. Always check the amount and the receiving address before sending coins.</source>
        <translation type="unfinished">Jen viaj Bitmon-adresoj por sendi pagojn. Zorge kontrolu la sumon kaj la alsendan adreson antaŭ ol sendi.</translation>
    </message>
    <message>
        <source>These are your Kawra addresses for receiving payments. Use the 'Create new receiving address' button in the receive tab to create new addresses.
Signing is only possible with addresses of the type 'legacy'.</source>
        <translation type="unfinished">Jen viaj bitmonaj adresoj por ricevi pagojn. Estas konsilinde uzi apartan ricevan adreson por ĉiu transakcio.</translation>
    </message>
    <message>
        <source>&amp;Copy Address</source>
        <translation type="unfinished">&amp;Kopii Adreson</translation>
    </message>
    <message>
        <source>Copy &amp;Label</source>
        <translation type="unfinished">Kopii &amp;Etikedon</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation type="unfinished">&amp;Redakti</translation>
    </message>
    <message>
        <source>Export Address List</source>
        <translation type="unfinished">Eksporti Adresliston</translation>
    </message>
    <message>
        <source>Comma separated file</source>
        <extracomment>Expanded name of the CSV file format. See: https://en.wikipedia.org/wiki/Comma-separated_values.</extracomment>
        <translation type="unfinished">Perkome disigita dosiero</translation>
    </message>
    <message>
        <source>There was an error trying to save the address list to %1. Please try again.</source>
        <extracomment>An error message. %1 is a stand-in argument for the name of the file we attempted to save to.</extracomment>
        <translation type="unfinished">Okazis eraron dum konservo de adreslisto al %1. Bonvolu provi denove.</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation type="unfinished">ekspotado malsukcesinta</translation>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Label</source>
        <translation type="unfinished">Etikedo</translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="unfinished">Adreso</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(neniu etikedo)</translation>
    </message>
</context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Passphrase Dialog</source>
        <translation type="unfinished">Dialogo pri pasfrazo</translation>
    </message>
    <message>
        <source>Enter passphrase</source>
        <translation type="unfinished">Enigu pasfrazon</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation type="unfinished">Nova pasfrazo</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation type="unfinished">Ripetu la novan pasfrazon</translation>
    </message>
    <message>
        <source>Show passphrase</source>
        <translation type="unfinished">Montri pasfrazon</translation>
    </message>
    <message>
        <source>Encrypt wallet</source>
        <translation type="unfinished">Ĉifri la monujon</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation type="unfinished">Ĉi tiu operacio bezonas vian monujan pasfrazon, por malŝlosi la monujon.</translation>
    </message>
    <message>
        <source>Unlock wallet</source>
        <translation type="unfinished">Malŝlosi la monujon</translation>
    </message>
    <message>
        <source>Change passphrase</source>
        <translation type="unfinished">Ŝanĝi la pasfrazon</translation>
    </message>
    <message>
        <source>Confirm wallet encryption</source>
        <translation type="unfinished">Konfirmo de ĉifrado de la monujo</translation>
    </message>
    <message>
        <source>Warning: If you encrypt your wallet and lose your passphrase, you will &lt;b&gt;LOSE ALL OF YOUR KAWRAS&lt;/b&gt;!</source>
        <translation type="unfinished">Atentu! Se vi ĉifras vian monujon kaj perdas la pasfrazon, vi &lt;b&gt;PERDOS LA TUTON DE VIA BITMONO&lt;b&gt;!</translation>
    </message>
    <message>
        <source>Are you sure you wish to encrypt your wallet?</source>
        <translation type="unfinished">Ĉu vi certas, ke vi volas ĉifri la monujon?</translation>
    </message>
    <message>
        <source>Wallet encrypted</source>
        <translation type="unfinished">La monujo estas ĉifrita</translation>
    </message>
    <message>
        <source>Enter the new passphrase for the wallet.&lt;br/&gt;Please use a passphrase of &lt;b&gt;ten or more random characters&lt;/b&gt;, or &lt;b&gt;eight or more words&lt;/b&gt;.</source>
        <translation type="unfinished">Enigi la novan pasfrazon por la monujo. &lt;br/&gt;Bonvolu uzi pasfrazon de &lt;b&gt;dek aŭ pli hazardaj signoj&lt;/b&gt;, aŭ &lt;b&gt;ok aŭ pli vortoj&lt;/b&gt;.</translation>
    </message>
    <message>
        <source>Enter the old passphrase and new passphrase for the wallet.</source>
        <translation type="unfinished">Enigi la malnovan pasfrazon kaj la novan pasfrazon por la monujo.</translation>
    </message>
    <message>
        <source>Wallet to be encrypted</source>
        <translation type="unfinished">Monujo ĉifriĝota</translation>
    </message>
    <message>
        <source>Your wallet is about to be encrypted. </source>
        <translation type="unfinished">Via monujo estas ĉifriĝota.</translation>
    </message>
    <message>
        <source>Your wallet is now encrypted. </source>
        <translation type="unfinished">Via monujo ĵus estas ĉifrata.</translation>
    </message>
    <message>
        <source>IMPORTANT: Any previous backups you have made of your wallet file should be replaced with the newly generated, encrypted wallet file. For security reasons, previous backups of the unencrypted wallet file will become useless as soon as you start using the new, encrypted wallet.</source>
        <translation type="unfinished">GRAVE: antaŭaj sekur-kopioj de via monujo-dosiero estas forigindaj kiam vi havas nove kreitan ĉifritan monujo-dosieron. Pro sekureco, antaŭaj kopioj de la neĉifrita dosiero ne plu funkcios tuj kiam vi ekuzos la novan ĉifritan dosieron.</translation>
    </message>
    <message>
        <source>Wallet encryption failed</source>
        <translation type="unfinished">Ĉifrado de la monujo fiaskis</translation>
    </message>
    <message>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation type="unfinished">Ĉifrado de monujo fiaskis pro interna eraro. Via monujo ne estas ĉifrita.</translation>
    </message>
    <message>
        <source>The supplied passphrases do not match.</source>
        <translation type="unfinished">La pasfrazoj entajpitaj ne samas.</translation>
    </message>
    <message>
        <source>Wallet unlock failed</source>
        <translation type="unfinished">Malŝloso de la monujo fiaskis</translation>
    </message>
    <message>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation type="unfinished">La pasfrazo enigita por ĉifrado de monujo ne ĝustas.</translation>
    </message>
    <message>
        <source>Wallet passphrase was successfully changed.</source>
        <translation type="unfinished">Vi sukcese ŝanĝis la pasfrazon de la monujo.</translation>
    </message>
    <message>
        <source>Warning: The Caps Lock key is on!</source>
        <translation type="unfinished">Atentu: la majuskla baskulo estas ŝaltita!</translation>
    </message>
</context>
<context>
    <name>BanTableModel</name>
    <message>
        <source>Banned Until</source>
        <translation type="unfinished">Ekzilita Ĝis</translation>
    </message>
</context>
<context>
    <name>KawraApplication</name>
    <message>
        <source>A fatal error occurred. %1 can no longer continue safely and will quit.</source>
        <translation type="unfinished">Neriparebla eraro okazis. %1 ne plu sekure povas daŭri kaj ĝi ĉesiĝos.</translation>
    </message>
    </context>
<context>
    <name>QObject</name>
    <message>
        <source>Error: %1</source>
        <translation type="unfinished">Eraro: %1</translation>
    </message>
    <message>
        <source>unknown</source>
        <translation type="unfinished">nekonata</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">Sumo</translation>
    </message>
    <message>
        <source>None</source>
        <translation type="unfinished">Neniu</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation type="unfinished">neaplikebla</translation>
    </message>
    <message numerus="yes">
        <source>%n second(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n minute(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n hour(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n day(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n week(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message>
        <source>%1 and %2</source>
        <translation type="unfinished">%1 kaj %2</translation>
    </message>
    <message numerus="yes">
        <source>%n year(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    </context>
<context>
    <name>KawraGUI</name>
    <message>
        <source>&amp;Overview</source>
        <translation type="unfinished">&amp;Superrigardo</translation>
    </message>
    <message>
        <source>Show general overview of wallet</source>
        <translation type="unfinished">Vidigi ĝeneralan superrigardon de la monujo</translation>
    </message>
    <message>
        <source>&amp;Transactions</source>
        <translation type="unfinished">&amp;Transakcioj</translation>
    </message>
    <message>
        <source>Browse transaction history</source>
        <translation type="unfinished">Esplori historion de transakcioj</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation type="unfinished">&amp;Eliri</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation type="unfinished">Eliri la aplikaĵon</translation>
    </message>
    <message>
        <source>&amp;About %1</source>
        <translation type="unfinished">&amp;Pri %1</translation>
    </message>
    <message>
        <source>Show information about %1</source>
        <translation type="unfinished">Montri informojn pri %1</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation type="unfinished">Pri &amp;Qt</translation>
    </message>
    <message>
        <source>Show information about Qt</source>
        <translation type="unfinished">Vidigi informojn pri Qt</translation>
    </message>
    <message>
        <source>Modify configuration options for %1</source>
        <translation type="unfinished">Ŝanĝi agordojn por %1</translation>
    </message>
    <message>
        <source>Create a new wallet</source>
        <translation type="unfinished">Krei novan monujon</translation>
    </message>
    <message>
        <source>Wallet:</source>
        <translation type="unfinished">Monujo:</translation>
    </message>
    <message>
        <source>Network activity disabled.</source>
        <extracomment>A substring of the tooltip.</extracomment>
        <translation type="unfinished">Retaj agadoj malebliĝas.</translation>
    </message>
    <message>
        <source>Send coins to a Kawra address</source>
        <translation type="unfinished">Sendi monon al Bitmon-adreso</translation>
    </message>
    <message>
        <source>Backup wallet to another location</source>
        <translation type="unfinished">Krei alilokan sekurkopion de monujo</translation>
    </message>
    <message>
        <source>Change the passphrase used for wallet encryption</source>
        <translation type="unfinished">Ŝanĝi la pasfrazon por ĉifri la monujon</translation>
    </message>
    <message>
        <source>&amp;Send</source>
        <translation type="unfinished">&amp;Sendi</translation>
    </message>
    <message>
        <source>&amp;Receive</source>
        <translation type="unfinished">&amp;Ricevi</translation>
    </message>
    <message>
        <source>Encrypt the private keys that belong to your wallet</source>
        <translation type="unfinished">Ĉifri la privatajn ŝlosilojn de via monujo</translation>
    </message>
    <message>
        <source>Sign messages with your Kawra addresses to prove you own them</source>
        <translation type="unfinished">Subskribi mesaĝojn per via Bitmon-adresoj por pravigi, ke vi estas la posedanto</translation>
    </message>
    <message>
        <source>Verify messages to ensure they were signed with specified Kawra addresses</source>
        <translation type="unfinished">Kontroli mesaĝojn por kontroli ĉu ili estas subskribitaj per specifaj Bitmon-adresoj</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation type="unfinished">&amp;Dosiero</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation type="unfinished">&amp;Agordoj</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation type="unfinished">&amp;Helpo</translation>
    </message>
    <message>
        <source>Tabs toolbar</source>
        <translation type="unfinished">Langeto-breto</translation>
    </message>
    <message>
        <source>Request payments (generates QR codes and kawra: URIs)</source>
        <translation type="unfinished">Peti pagon (kreas QR-kodojn kaj URI-ojn kun prefikso kawra:)</translation>
    </message>
    <message>
        <source>Show the list of used sending addresses and labels</source>
        <translation type="unfinished">Vidigi la liston de uzitaj sendaj adresoj kaj etikedoj</translation>
    </message>
    <message>
        <source>Show the list of used receiving addresses and labels</source>
        <translation type="unfinished">Vidigi la liston de uzitaj ricevaj adresoj kaj etikedoj</translation>
    </message>
    <message>
        <source>&amp;Command-line options</source>
        <translation type="unfinished">&amp;Komandliniaj agordaĵoj</translation>
    </message>
    <message numerus="yes">
        <source>Processed %n block(s) of transaction history.</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message>
        <source>%1 behind</source>
        <translation type="unfinished">mankas %1</translation>
    </message>
    <message>
        <source>Last received block was generated %1 ago.</source>
        <translation type="unfinished">Lasta ricevita bloko kreiĝis antaŭ %1.</translation>
    </message>
    <message>
        <source>Transactions after this will not yet be visible.</source>
        <translation type="unfinished">Transakcioj por tio ankoraŭ ne videblas.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">Eraro</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation type="unfinished">Averto</translation>
    </message>
    <message>
        <source>Information</source>
        <translation type="unfinished">Informoj</translation>
    </message>
    <message>
        <source>Up to date</source>
        <translation type="unfinished">Ĝisdata</translation>
    </message>
    <message>
        <source>Open Wallet</source>
        <translation type="unfinished">Malfermi la Monujon</translation>
    </message>
    <message>
        <source>Open a wallet</source>
        <translation type="unfinished">Malfermi monujon</translation>
    </message>
    <message>
        <source>Close wallet</source>
        <translation type="unfinished">Fermi monujon</translation>
    </message>
    <message>
        <source>Close all wallets</source>
        <translation type="unfinished">Fermi ĉiujn monujojn</translation>
    </message>
    <message>
        <source>default wallet</source>
        <translation type="unfinished">defaŭlta monujo</translation>
    </message>
    <message>
        <source>Wallet Name</source>
        <extracomment>Label of the input field where the name of the wallet is entered.</extracomment>
        <translation type="unfinished">Monujo-Nomo</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation type="unfinished">&amp;Fenestro</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation type="unfinished">Zomi</translation>
    </message>
    <message>
        <source>Main Window</source>
        <translation type="unfinished">Ĉefa Fenestro</translation>
    </message>
    <message numerus="yes">
        <source>%n active connection(s) to Kawra network.</source>
        <extracomment>A substring of the tooltip.</extracomment>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message>
        <source>Error: %1</source>
        <translation type="unfinished">Eraro: %1</translation>
    </message>
    <message>
        <source>Warning: %1</source>
        <translation type="unfinished">Averto: %1</translation>
    </message>
    <message>
        <source>Date: %1
</source>
        <translation type="unfinished">Dato: %1
</translation>
    </message>
    <message>
        <source>Amount: %1
</source>
        <translation type="unfinished">Sumo: %1
</translation>
    </message>
    <message>
        <source>Wallet: %1
</source>
        <translation type="unfinished">Monujo: %1
</translation>
    </message>
    <message>
        <source>Type: %1
</source>
        <translation type="unfinished">Tipo: %1
</translation>
    </message>
    <message>
        <source>Label: %1
</source>
        <translation type="unfinished">Etikedo: %1
</translation>
    </message>
    <message>
        <source>Address: %1
</source>
        <translation type="unfinished">Adreso: %1
</translation>
    </message>
    <message>
        <source>Sent transaction</source>
        <translation type="unfinished">Sendita transakcio</translation>
    </message>
    <message>
        <source>Incoming transaction</source>
        <translation type="unfinished">Envenanta transakcio</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation type="unfinished">Monujo estas &lt;b&gt;ĉifrita&lt;/b&gt; kaj aktuale &lt;b&gt;malŝlosita&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation type="unfinished">Monujo estas &lt;b&gt;ĉifrita&lt;/b&gt; kaj aktuale &lt;b&gt;ŝlosita&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Original message:</source>
        <translation type="unfinished">Originala mesaĝo:</translation>
    </message>
</context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Coin Selection</source>
        <translation type="unfinished">Monero-Elektaĵo</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation type="unfinished">Kvanto:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation type="unfinished">Bajtoj:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation type="unfinished">Sumo:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation type="unfinished">Krompago:</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation type="unfinished">Polvo:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation type="unfinished">Post krompago:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation type="unfinished">Restmono:</translation>
    </message>
    <message>
        <source>(un)select all</source>
        <translation type="unfinished">(mal)elekti ĉion</translation>
    </message>
    <message>
        <source>Tree mode</source>
        <translation type="unfinished">Arboreĝimo</translation>
    </message>
    <message>
        <source>List mode</source>
        <translation type="unfinished">Listreĝimo</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">Sumo</translation>
    </message>
    <message>
        <source>Received with label</source>
        <translation type="unfinished">Ricevita kun etikedo</translation>
    </message>
    <message>
        <source>Received with address</source>
        <translation type="unfinished">Ricevita kun adreso</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished">Dato</translation>
    </message>
    <message>
        <source>Confirmations</source>
        <translation type="unfinished">Konfirmoj</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation type="unfinished">Konfirmita</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation type="unfinished">Kopii sumon</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation type="unfinished">Kopii kvanton</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation type="unfinished">Kopii krompagon</translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation type="unfinished">Kopii post krompago</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation type="unfinished">Kopii bajtojn</translation>
    </message>
    <message>
        <source>Copy dust</source>
        <translation type="unfinished">Kopii polvon</translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation type="unfinished">Kopii restmonon</translation>
    </message>
    <message>
        <source>(%1 locked)</source>
        <translation type="unfinished">(%1 ŝlosita)</translation>
    </message>
    <message>
        <source>yes</source>
        <translation type="unfinished">jes</translation>
    </message>
    <message>
        <source>no</source>
        <translation type="unfinished">ne</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(neniu etikedo)</translation>
    </message>
    <message>
        <source>change from %1 (%2)</source>
        <translation type="unfinished">restmono de %1 (%2)</translation>
    </message>
    <message>
        <source>(change)</source>
        <translation type="unfinished">(restmono)</translation>
    </message>
</context>
<context>
    <name>CreateWalletActivity</name>
    <message>
        <source>Create Wallet</source>
        <extracomment>Title of window indicating the progress of creation of a new wallet.</extracomment>
        <translation type="unfinished">Krei Monujon</translation>
    </message>
    <message>
        <source>Create wallet failed</source>
        <translation type="unfinished">Krei monujon malsukcesis</translation>
    </message>
    <message>
        <source>Create wallet warning</source>
        <translation type="unfinished">Averto pro krei monujon</translation>
    </message>
    </context>
<context>
    <name>OpenWalletActivity</name>
    <message>
        <source>Open wallet failed</source>
        <translation type="unfinished">Malfermi monujon malsukcesis</translation>
    </message>
    <message>
        <source>Open wallet warning</source>
        <translation type="unfinished">Malfermi monujon averto</translation>
    </message>
    <message>
        <source>default wallet</source>
        <translation type="unfinished">defaŭlta monujo</translation>
    </message>
    <message>
        <source>Open Wallet</source>
        <extracomment>Title of window indicating the progress of opening of a wallet.</extracomment>
        <translation type="unfinished">Malfermi la Monujon</translation>
    </message>
    </context>
<context>
    <name>WalletController</name>
    <message>
        <source>Close wallet</source>
        <translation type="unfinished">Fermi monujon</translation>
    </message>
    <message>
        <source>Close all wallets</source>
        <translation type="unfinished">Fermi ĉiujn monujojn</translation>
    </message>
    </context>
<context>
    <name>CreateWalletDialog</name>
    <message>
        <source>Create Wallet</source>
        <translation type="unfinished">Krei Monujon</translation>
    </message>
    <message>
        <source>Wallet Name</source>
        <translation type="unfinished">Monujo-Nomo</translation>
    </message>
    <message>
        <source>Wallet</source>
        <translation type="unfinished">Monujo</translation>
    </message>
    <message>
        <source>Encrypt Wallet</source>
        <translation type="unfinished">Ĉifri Monujon</translation>
    </message>
    <message>
        <source>Disable private keys for this wallet. Wallets with private keys disabled will have no private keys and cannot have an HD seed or imported private keys. This is ideal for watch-only wallets.</source>
        <translation type="unfinished">Malebligi privatajn ŝlosilojn por ĉi tiu monujo. Monujoj kun malebligitaj privataj ŝlosiloj ne havos privatajn ŝlosilojn, kaj povas havi nek HD-semon nek importatajn privatajn ŝlosilojn. Ĉi tio estas ideale por nurspektaj monujoj.</translation>
    </message>
    <message>
        <source>Disable Private Keys</source>
        <translation type="unfinished">Malebligi Privatajn Ŝlosilojn</translation>
    </message>
    <message>
        <source>Create</source>
        <translation type="unfinished">Krei</translation>
    </message>
    </context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation type="unfinished">Redakti Adreson</translation>
    </message>
    <message>
        <source>&amp;Label</source>
        <translation type="unfinished">&amp;Etikedo</translation>
    </message>
    <message>
        <source>The label associated with this address list entry</source>
        <translation type="unfinished">La etikedo ligita al tiu ĉi adreslistero</translation>
    </message>
    <message>
        <source>The address associated with this address list entry. This can only be modified for sending addresses.</source>
        <translation type="unfinished">La adreso ligita al tiu ĉi adreslistero. Eblas modifi tion nur por sendaj adresoj.</translation>
    </message>
    <message>
        <source>&amp;Address</source>
        <translation type="unfinished">&amp;Adreso</translation>
    </message>
    <message>
        <source>New sending address</source>
        <translation type="unfinished">Nova adreso por sendi</translation>
    </message>
    <message>
        <source>Edit receiving address</source>
        <translation type="unfinished">Redakti adreson por ricevi</translation>
    </message>
    <message>
        <source>Edit sending address</source>
        <translation type="unfinished">Redakti adreson por sendi</translation>
    </message>
    <message>
        <source>The entered address "%1" is not a valid Kawra address.</source>
        <translation type="unfinished">La adreso enigita "%1" ne estas valida Bitmon-adreso.</translation>
    </message>
    <message>
        <source>Could not unlock wallet.</source>
        <translation type="unfinished">Ne eblis malŝlosi monujon.</translation>
    </message>
    <message>
        <source>New key generation failed.</source>
        <translation type="unfinished">Fiaskis kreo de nova ŝlosilo.</translation>
    </message>
</context>
<context>
    <name>FreespaceChecker</name>
    <message>
        <source>A new data directory will be created.</source>
        <translation type="unfinished">Kreiĝos nova dosierujo por la datumoj.</translation>
    </message>
    <message>
        <source>name</source>
        <translation type="unfinished">nomo</translation>
    </message>
    <message>
        <source>Directory already exists. Add %1 if you intend to create a new directory here.</source>
        <translation type="unfinished">Tiu dosierujo jam ekzistas. Aldonu %1 si vi volas krei novan dosierujon ĉi tie.</translation>
    </message>
    <message>
        <source>Path already exists, and is not a directory.</source>
        <translation type="unfinished">Vojo jam ekzistas, kaj ne estas dosierujo.</translation>
    </message>
    <message>
        <source>Cannot create data directory here.</source>
        <translation type="unfinished">Ne eblas krei dosierujon por datumoj ĉi tie.</translation>
    </message>
</context>
<context>
    <name>Intro</name>
    <message>
        <source>Kawra</source>
        <translation type="unfinished">Bitmono</translation>
    </message>
    <message numerus="yes">
        <source>%n GB of space available</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>(of %n GB needed)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>(%n GB needed for full chain)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>(sufficient to restore backups %n day(s) old)</source>
        <extracomment>Explanatory text on the capability of the current prune target.</extracomment>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">Eraro</translation>
    </message>
    <message>
        <source>Welcome</source>
        <translation type="unfinished">Bonvenon</translation>
    </message>
    <message>
        <source>Welcome to %1.</source>
        <translation type="unfinished">Bonvenon al %1.</translation>
    </message>
    <message>
        <source>Use the default data directory</source>
        <translation type="unfinished">Uzi la defaŭltan dosierujon por datumoj</translation>
    </message>
    <message>
        <source>Use a custom data directory:</source>
        <translation type="unfinished">Uzi alian dosierujon por datumoj:</translation>
    </message>
</context>
<context>
    <name>HelpMessageDialog</name>
    <message>
        <source>version</source>
        <translation type="unfinished">versio</translation>
    </message>
    <message>
        <source>About %1</source>
        <translation type="unfinished">Pri %1</translation>
    </message>
    <message>
        <source>Command-line options</source>
        <translation type="unfinished">Komandliniaj agordaĵoj</translation>
    </message>
</context>
<context>
    <name>ShutdownWindow</name>
    <message>
        <source>Do not shut down the computer until this window disappears.</source>
        <translation type="unfinished">Ne sistemfermu ĝis ĉi tiu fenestro malaperas.</translation>
    </message>
</context>
<context>
    <name>ModalOverlay</name>
    <message>
        <source>Form</source>
        <translation type="unfinished">Formularo</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation type="unfinished">Horo de la lasta bloko</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation type="unfinished">Progreso</translation>
    </message>
    <message>
        <source>Progress increase per hour</source>
        <translation type="unfinished">Hora pligrandigo da progreso</translation>
    </message>
    <message>
        <source>Hide</source>
        <translation type="unfinished">Kaŝi</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation type="unfinished">Esk</translation>
    </message>
    <message>
        <source>%1 is currently syncing.  It will download headers and blocks from peers and validate them until reaching the tip of the block chain.</source>
        <translation type="unfinished">%1 sinkronigadas. Ĝi elŝutos kapaĵojn kaj blokojn de samtavolanoj, kaj validigos ilin, ĝis ĝi atingas la pinton de la blokĉeno.</translation>
    </message>
    </context>
<context>
    <name>OpenURIDialog</name>
    <message>
        <source>Open kawra URI</source>
        <translation type="unfinished">Malfermi na la URI de bitmono</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <extracomment>Tooltip text for button that allows you to paste an address that is in your clipboard.</extracomment>
        <translation type="unfinished">Alglui adreson de tondejo</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation type="unfinished">Agordaĵoj</translation>
    </message>
    <message>
        <source>&amp;Main</source>
        <translation type="unfinished">Ĉ&amp;efa</translation>
    </message>
    <message>
        <source>Automatically start %1 after logging in to the system.</source>
        <translation type="unfinished">Aŭtomate komenci na %1 post ensalutis en la sistemon.</translation>
    </message>
    <message>
        <source>&amp;Start %1 on system login</source>
        <translation type="unfinished">&amp;Komenci na %1 kiam ensaluti en la sistemon</translation>
    </message>
    <message>
        <source>Size of &amp;database cache</source>
        <translation type="unfinished">Dosiergrando de &amp;datumbasa kaŝmemoro</translation>
    </message>
    <message>
        <source>Number of script &amp;verification threads</source>
        <translation type="unfinished">Kvanto da skriptaj kaj kontroleraraj fadenoj</translation>
    </message>
    <message>
        <source>IP address of the proxy (e.g. IPv4: 127.0.0.1 / IPv6: ::1)</source>
        <translation type="unfinished">IP-adreso de prokurilo (ekz. IPv4: 127.0.0.1 / IPv6: ::1)</translation>
    </message>
    <message>
        <source>Reset all client options to default.</source>
        <translation type="unfinished">Reagordi ĉion al defaŭlataj valoroj.</translation>
    </message>
    <message>
        <source>&amp;Reset Options</source>
        <translation type="unfinished">&amp;Rekomenci agordadon</translation>
    </message>
    <message>
        <source>&amp;Network</source>
        <translation type="unfinished">&amp;Reto</translation>
    </message>
    <message>
        <source>W&amp;allet</source>
        <translation type="unfinished">Monujo</translation>
    </message>
    <message>
        <source>Expert</source>
        <translation type="unfinished">Fakulo</translation>
    </message>
    <message>
        <source>Automatically open the Kawra client port on the router. This only works when your router supports UPnP and it is enabled.</source>
        <translation type="unfinished">Aŭtomate malfermi la kursilan pordon por Bitmono. Tio funkcias nur se via kursilo havas la UPnP-funkcion, kaj se tiu ĉi estas ŝaltita.</translation>
    </message>
    <message>
        <source>Map port using &amp;UPnP</source>
        <translation type="unfinished">Mapigi pordon per &amp;UPnP</translation>
    </message>
    <message>
        <source>Proxy &amp;IP:</source>
        <translation type="unfinished">Prokurila &amp;IP:</translation>
    </message>
    <message>
        <source>&amp;Port:</source>
        <translation type="unfinished">&amp;Pordo:</translation>
    </message>
    <message>
        <source>Port of the proxy (e.g. 9050)</source>
        <translation type="unfinished">la pordo de la prokurilo (ekz. 9050)</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation type="unfinished">&amp;Fenestro</translation>
    </message>
    <message>
        <source>Show only a tray icon after minimizing the window.</source>
        <translation type="unfinished">Montri nur sistempletan piktogramon post minimumigo de la fenestro.</translation>
    </message>
    <message>
        <source>&amp;Minimize to the tray instead of the taskbar</source>
        <translation type="unfinished">&amp;Minimumigi al la sistempleto anstataŭ al la taskopleto</translation>
    </message>
    <message>
        <source>M&amp;inimize on close</source>
        <translation type="unfinished">M&amp;inimumigi je fermo</translation>
    </message>
    <message>
        <source>&amp;Display</source>
        <translation type="unfinished">&amp;Aspekto</translation>
    </message>
    <message>
        <source>User Interface &amp;language:</source>
        <translation type="unfinished">&amp;Lingvo de la fasado:</translation>
    </message>
    <message>
        <source>&amp;Unit to show amounts in:</source>
        <translation type="unfinished">&amp;Unuo por vidigi sumojn:</translation>
    </message>
    <message>
        <source>Choose the default subdivision unit to show in the interface and when sending coins.</source>
        <translation type="unfinished">Elekti la defaŭltan manieron por montri bitmonajn sumojn en la interfaco, kaj kiam vi sendos bitmonon.</translation>
    </message>
    <message>
        <source>Whether to show coin control features or not.</source>
        <translation type="unfinished">Ĉu montri detalan adres-regilon, aŭ ne.</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation type="unfinished">&amp;Bone</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="unfinished">&amp;Nuligi</translation>
    </message>
    <message>
        <source>default</source>
        <translation type="unfinished">defaŭlta</translation>
    </message>
    <message>
        <source>none</source>
        <translation type="unfinished">neniu</translation>
    </message>
    <message>
        <source>Confirm options reset</source>
        <extracomment>Window title text of pop-up window shown when the user has chosen to reset options.</extracomment>
        <translation type="unfinished">Konfirmi reŝargo de agordoj</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">Eraro</translation>
    </message>
    <message>
        <source>The supplied proxy address is invalid.</source>
        <translation type="unfinished">La prokurila adreso estas malvalida.</translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Form</source>
        <translation type="unfinished">Formularo</translation>
    </message>
    <message>
        <source>The displayed information may be out of date. Your wallet automatically synchronizes with the Kawra network after a connection is established, but this process has not completed yet.</source>
        <translation type="unfinished">Eblas, ke la informoj videblaj ĉi tie estas eksdataj. Via monujo aŭtomate sinkoniĝas kun la bitmona reto kiam ili konektiĝas, sed tiu procezo ankoraŭ ne finfariĝis.</translation>
    </message>
    <message>
        <source>Available:</source>
        <translation type="unfinished">Disponebla:</translation>
    </message>
    <message>
        <source>Your current spendable balance</source>
        <translation type="unfinished">via aktuala elspezebla saldo</translation>
    </message>
    <message>
        <source>Total of transactions that have yet to be confirmed, and do not yet count toward the spendable balance</source>
        <translation type="unfinished">la sumo de transakcioj ankoraŭ ne konfirmitaj, kiuj ankoraŭ ne elspezeblas</translation>
    </message>
    <message>
        <source>Immature:</source>
        <translation type="unfinished">Nematura:</translation>
    </message>
    <message>
        <source>Mined balance that has not yet matured</source>
        <translation type="unfinished">Minita saldo, kiu ankoraŭ ne maturiĝis</translation>
    </message>
    <message>
        <source>Balances</source>
        <translation type="unfinished">Saldoj</translation>
    </message>
    <message>
        <source>Total:</source>
        <translation type="unfinished">Totalo:</translation>
    </message>
    <message>
        <source>Your current total balance</source>
        <translation type="unfinished">via aktuala totala saldo</translation>
    </message>
    <message>
        <source>Spendable:</source>
        <translation type="unfinished">Elspezebla:</translation>
    </message>
    <message>
        <source>Recent transactions</source>
        <translation type="unfinished">Lastaj transakcioj</translation>
    </message>
    </context>
<context>
    <name>PSBTOperationsDialog</name>
    <message>
        <source>Close</source>
        <translation type="unfinished">Fermi</translation>
    </message>
    <message>
        <source>Total Amount</source>
        <translation type="unfinished">Totala Sumo</translation>
    </message>
    <message>
        <source>or</source>
        <translation type="unfinished">aŭ</translation>
    </message>
    </context>
<context>
    <name>PaymentServer</name>
    <message>
        <source>Payment request error</source>
        <translation type="unfinished">Eraro dum pagopeto</translation>
    </message>
    <message>
        <source>Cannot start kawra: click-to-pay handler</source>
        <translation type="unfinished">Ne eblas lanĉi la ilon 'klaki-por-pagi'</translation>
    </message>
    <message>
        <source>URI handling</source>
        <translation type="unfinished">Traktado de URI-oj</translation>
    </message>
    </context>
<context>
    <name>PeerTableModel</name>
    <message>
        <source>User Agent</source>
        <extracomment>Title of Peers Table column which contains the peer's User Agent string.</extracomment>
        <translation type="unfinished">Uzanto Agento</translation>
    </message>
    <message>
        <source>Sent</source>
        <extracomment>Title of Peers Table column which indicates the total amount of network information we have sent to the peer.</extracomment>
        <translation type="unfinished">Sendita</translation>
    </message>
    <message>
        <source>Received</source>
        <extracomment>Title of Peers Table column which indicates the total amount of network information we have received from the peer.</extracomment>
        <translation type="unfinished">Ricevita</translation>
    </message>
    <message>
        <source>Address</source>
        <extracomment>Title of Peers Table column which contains the IP/Onion/I2P address of the connected peer.</extracomment>
        <translation type="unfinished">Adreso</translation>
    </message>
    <message>
        <source>Type</source>
        <extracomment>Title of Peers Table column which describes the type of peer connection. The "type" describes why the connection exists.</extracomment>
        <translation type="unfinished">Tipo</translation>
    </message>
    <message>
        <source>Network</source>
        <extracomment>Title of Peers Table column which states the network the peer connected through.</extracomment>
        <translation type="unfinished">Reto</translation>
    </message>
    </context>
<context>
    <name>QRImageWidget</name>
    <message>
        <source>&amp;Copy Image</source>
        <translation type="unfinished">&amp;Kopii Bildon</translation>
    </message>
    <message>
        <source>Resulting URI too long, try to reduce the text for label / message.</source>
        <translation type="unfinished">La rezultanta URI estas tro longa. Provu malplilongigi la tekston de la etikedo / mesaĝo.</translation>
    </message>
    <message>
        <source>Error encoding URI into QR Code.</source>
        <translation type="unfinished">Eraro de kodigo de URI en la QR-kodon.</translation>
    </message>
    <message>
        <source>Save QR Code</source>
        <translation type="unfinished">Konservi QR-kodon</translation>
    </message>
    </context>
<context>
    <name>RPCConsole</name>
    <message>
        <source>N/A</source>
        <translation type="unfinished">neaplikebla</translation>
    </message>
    <message>
        <source>Client version</source>
        <translation type="unfinished">Versio de kliento</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation type="unfinished">&amp;Informoj</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="unfinished">Ĝenerala</translation>
    </message>
    <message>
        <source>Startup time</source>
        <translation type="unfinished">Horo de lanĉo</translation>
    </message>
    <message>
        <source>Network</source>
        <translation type="unfinished">Reto</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished">Nomo</translation>
    </message>
    <message>
        <source>Number of connections</source>
        <translation type="unfinished">Nombro de konektoj</translation>
    </message>
    <message>
        <source>Block chain</source>
        <translation type="unfinished">Blokĉeno</translation>
    </message>
    <message>
        <source>Wallet: </source>
        <translation type="unfinished">Monujo:</translation>
    </message>
    <message>
        <source>Received</source>
        <translation type="unfinished">Ricevita</translation>
    </message>
    <message>
        <source>Sent</source>
        <translation type="unfinished">Sendita</translation>
    </message>
    <message>
        <source>&amp;Peers</source>
        <translation type="unfinished">&amp;Samuloj</translation>
    </message>
    <message>
        <source>Banned peers</source>
        <translation type="unfinished">Malpermesita samuloj.</translation>
    </message>
    <message>
        <source>Version</source>
        <translation type="unfinished">Versio</translation>
    </message>
    <message>
        <source>User Agent</source>
        <translation type="unfinished">Uzanto Agento</translation>
    </message>
    <message>
        <source>Services</source>
        <translation type="unfinished">Servoj</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation type="unfinished">Horo de la lasta bloko</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation type="unfinished">&amp;Malfermi</translation>
    </message>
    <message>
        <source>&amp;Console</source>
        <translation type="unfinished">&amp;Konzolo</translation>
    </message>
    <message>
        <source>&amp;Network Traffic</source>
        <translation type="unfinished">&amp;Reta Trafiko</translation>
    </message>
    <message>
        <source>Totals</source>
        <translation type="unfinished">Totaloj</translation>
    </message>
    <message>
        <source>Debug log file</source>
        <translation type="unfinished">Sencimiga protokoldosiero</translation>
    </message>
    <message>
        <source>Clear console</source>
        <translation type="unfinished">Malplenigi konzolon</translation>
    </message>
    <message>
        <source>In:</source>
        <translation type="unfinished">En:</translation>
    </message>
    <message>
        <source>Out:</source>
        <translation type="unfinished">El:</translation>
    </message>
    <message>
        <source>1 &amp;hour</source>
        <translation type="unfinished">1 &amp;horo</translation>
    </message>
    <message>
        <source>1 &amp;week</source>
        <translation type="unfinished">1 &amp;semajno</translation>
    </message>
    <message>
        <source>1 &amp;year</source>
        <translation type="unfinished">1 &amp;jaro</translation>
    </message>
    <message>
        <source>&amp;Unban</source>
        <translation type="unfinished">&amp;Malekzili</translation>
    </message>
    <message>
        <source>To</source>
        <translation type="unfinished">Al</translation>
    </message>
    <message>
        <source>From</source>
        <translation type="unfinished">De</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation type="unfinished">Nekonata</translation>
    </message>
</context>
<context>
    <name>ReceiveCoinsDialog</name>
    <message>
        <source>&amp;Amount:</source>
        <translation type="unfinished">&amp;Kvanto:</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation type="unfinished">&amp;Etikedo:</translation>
    </message>
    <message>
        <source>&amp;Message:</source>
        <translation type="unfinished">&amp;Mesaĝo:</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation type="unfinished">Malplenigi ĉiujn kampojn de la formularo.</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation type="unfinished">Forigi</translation>
    </message>
    <message>
        <source>Show</source>
        <translation type="unfinished">Vidigi</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished">Forigi</translation>
    </message>
    <message>
        <source>Copy &amp;URI</source>
        <translation type="unfinished">Kopii &amp;URI</translation>
    </message>
    <message>
        <source>Could not unlock wallet.</source>
        <translation type="unfinished">Ne eblis malŝlosi monujon.</translation>
    </message>
    </context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>Address:</source>
        <translation type="unfinished">Adreso:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation type="unfinished">Sumo:</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation type="unfinished">Etikedo:</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation type="unfinished">Mesaĝo:</translation>
    </message>
    <message>
        <source>Wallet:</source>
        <translation type="unfinished">Monujo:</translation>
    </message>
    <message>
        <source>Copy &amp;URI</source>
        <translation type="unfinished">Kopii &amp;URI</translation>
    </message>
    <message>
        <source>Copy &amp;Address</source>
        <translation type="unfinished">Kopii &amp;Adreson</translation>
    </message>
    <message>
        <source>Payment information</source>
        <translation type="unfinished">Paginformoj</translation>
    </message>
    <message>
        <source>Request payment to %1</source>
        <translation type="unfinished">Peti pagon al %1</translation>
    </message>
</context>
<context>
    <name>RecentRequestsTableModel</name>
    <message>
        <source>Date</source>
        <translation type="unfinished">Dato</translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished">Etikedo</translation>
    </message>
    <message>
        <source>Message</source>
        <translation type="unfinished">Mesaĝo</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(neniu etikedo)</translation>
    </message>
    <message>
        <source>(no message)</source>
        <translation type="unfinished">(neniu mesaĝo)</translation>
    </message>
    </context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Send Coins</source>
        <translation type="unfinished">Sendi Bitmonon</translation>
    </message>
    <message>
        <source>Coin Control Features</source>
        <translation type="unfinished">Monregaj Opcioj</translation>
    </message>
    <message>
        <source>Insufficient funds!</source>
        <translation type="unfinished">Nesufiĉa mono!</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation type="unfinished">Kvanto:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation type="unfinished">Bajtoj:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation type="unfinished">Sumo:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation type="unfinished">Krompago:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation type="unfinished">Post krompago:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation type="unfinished">Restmono:</translation>
    </message>
    <message>
        <source>Transaction Fee:</source>
        <translation type="unfinished">Krompago:</translation>
    </message>
    <message>
        <source>Hide</source>
        <translation type="unfinished">Kaŝi</translation>
    </message>
    <message>
        <source>Send to multiple recipients at once</source>
        <translation type="unfinished">Sendi samtempe al pluraj ricevantoj</translation>
    </message>
    <message>
        <source>Add &amp;Recipient</source>
        <translation type="unfinished">Aldoni &amp;Ricevonton</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation type="unfinished">Malplenigi ĉiujn kampojn de la formularo.</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation type="unfinished">Polvo:</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation type="unfinished">&amp;Forigi Ĉion</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation type="unfinished">Saldo:</translation>
    </message>
    <message>
        <source>Confirm the send action</source>
        <translation type="unfinished">Konfirmi la sendon</translation>
    </message>
    <message>
        <source>S&amp;end</source>
        <translation type="unfinished">Ŝendi</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation type="unfinished">Kopii kvanton</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation type="unfinished">Kopii sumon</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation type="unfinished">Kopii krompagon</translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation type="unfinished">Kopii post krompago</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation type="unfinished">Kopii bajtojn</translation>
    </message>
    <message>
        <source>Copy dust</source>
        <translation type="unfinished">Kopii polvon</translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation type="unfinished">Kopii restmonon</translation>
    </message>
    <message>
        <source>%1 to %2</source>
        <translation type="unfinished">%1 al %2</translation>
    </message>
    <message>
        <source>or</source>
        <translation type="unfinished">aŭ</translation>
    </message>
    <message>
        <source>Transaction fee</source>
        <translation type="unfinished">Krompago</translation>
    </message>
    <message>
        <source>Total Amount</source>
        <translation type="unfinished">Totala Sumo</translation>
    </message>
    <message>
        <source>Confirm send coins</source>
        <translation type="unfinished">Konfirmi sendon de bitmono</translation>
    </message>
    <message>
        <source>The amount to pay must be larger than 0.</source>
        <translation type="unfinished">La pagenda sumo devas esti pli ol 0.</translation>
    </message>
    <message>
        <source>The amount exceeds your balance.</source>
        <translation type="unfinished">La sumo estas pli granda ol via saldo.</translation>
    </message>
    <message>
        <source>The total exceeds your balance when the %1 transaction fee is included.</source>
        <translation type="unfinished">La sumo kun la %1 krompago estas pli granda ol via saldo.</translation>
    </message>
    <message>
        <source>Transaction creation failed!</source>
        <translation type="unfinished">Kreo de transakcio fiaskis!</translation>
    </message>
    <message numerus="yes">
        <source>Estimated to begin confirmation within %n block(s).</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message>
        <source>Warning: Invalid Kawra address</source>
        <translation type="unfinished">Averto: Nevalida Bitmon-adreso</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(neniu etikedo)</translation>
    </message>
</context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>A&amp;mount:</source>
        <translation type="unfinished">&amp;Sumo:</translation>
    </message>
    <message>
        <source>Pay &amp;To:</source>
        <translation type="unfinished">&amp;Ricevonto:</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation type="unfinished">&amp;Etikedo:</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation type="unfinished">Elektu la jam uzitan adreson</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation type="unfinished">Alglui adreson de tondejo</translation>
    </message>
    <message>
        <source>Remove this entry</source>
        <translation type="unfinished">Forigu ĉi tiun enskribon</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation type="unfinished">Mesaĝo:</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to the list of used addresses</source>
        <translation type="unfinished">Tajpu etikedon por tiu ĉi adreso por aldoni ĝin al la listo de uzitaj adresoj</translation>
    </message>
    </context>
<context>
    <name>SendConfirmationDialog</name>
    <message>
        <source>Send</source>
        <translation type="unfinished">Sendi</translation>
    </message>
    </context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>Signatures - Sign / Verify a Message</source>
        <translation type="unfinished">Subskriboj - Subskribi / Kontroli mesaĝon</translation>
    </message>
    <message>
        <source>&amp;Sign Message</source>
        <translation type="unfinished">&amp;Subskribi Mesaĝon</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation type="unfinished">Elektu la jam uzitan adreson</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation type="unfinished">Alglui adreson de tondejo</translation>
    </message>
    <message>
        <source>Enter the message you want to sign here</source>
        <translation type="unfinished">Tajpu la mesaĝon, kiun vi volas sendi, cîi tie</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation type="unfinished">Subskribo</translation>
    </message>
    <message>
        <source>Copy the current signature to the system clipboard</source>
        <translation type="unfinished">Kopii la aktualan subskribon al la tondejo</translation>
    </message>
    <message>
        <source>Sign the message to prove you own this Kawra address</source>
        <translation type="unfinished">Subskribi la mesaĝon por pravigi, ke vi estas la posedanto de tiu Bitmon-adreso</translation>
    </message>
    <message>
        <source>Sign &amp;Message</source>
        <translation type="unfinished">Subskribi &amp;Mesaĝon</translation>
    </message>
    <message>
        <source>Reset all sign message fields</source>
        <translation type="unfinished">Reagordigi ĉiujn prisubskribajn kampojn</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation type="unfinished">&amp;Forigi Ĉion</translation>
    </message>
    <message>
        <source>&amp;Verify Message</source>
        <translation type="unfinished">&amp;Kontroli Mesaĝon</translation>
    </message>
    <message>
        <source>Verify the message to ensure it was signed with the specified Kawra address</source>
        <translation type="unfinished">Kontroli la mesaĝon por pravigi, ke ĝi ja estas subskribita per la specifa Bitmon-adreso</translation>
    </message>
    <message>
        <source>Verify &amp;Message</source>
        <translation type="unfinished">Kontroli &amp;Mesaĝon</translation>
    </message>
    <message>
        <source>Reset all verify message fields</source>
        <translation type="unfinished">Reagordigi ĉiujn prikontrolajn kampojn</translation>
    </message>
    <message>
        <source>Click "Sign Message" to generate signature</source>
        <translation type="unfinished">Klaku "Subskribi Mesaĝon" por krei subskribon</translation>
    </message>
    <message>
        <source>The entered address is invalid.</source>
        <translation type="unfinished">La adreso, kiun vi enmetis, estas nevalida.</translation>
    </message>
    <message>
        <source>Please check the address and try again.</source>
        <translation type="unfinished">Bonvolu kontroli la adreson kaj reprovi.</translation>
    </message>
    <message>
        <source>The entered address does not refer to a key.</source>
        <translation type="unfinished">La adreso, kiun vi enmetis, referencas neniun ŝlosilon.</translation>
    </message>
    <message>
        <source>Wallet unlock was cancelled.</source>
        <translation type="unfinished">Malŝloso de monujo estas nuligita.</translation>
    </message>
    <message>
        <source>Private key for the entered address is not available.</source>
        <translation type="unfinished">La privata ŝlosilo por la enigita adreso ne disponeblas.</translation>
    </message>
    <message>
        <source>Message signing failed.</source>
        <translation type="unfinished">Subskribo de mesaĝo fiaskis.</translation>
    </message>
    <message>
        <source>Message signed.</source>
        <translation type="unfinished">Mesaĝo estas subskribita.</translation>
    </message>
    <message>
        <source>The signature could not be decoded.</source>
        <translation type="unfinished">Ne eblis malĉifri la subskribon.</translation>
    </message>
    <message>
        <source>Please check the signature and try again.</source>
        <translation type="unfinished">Bonvolu kontroli la subskribon kaj reprovu.</translation>
    </message>
    <message>
        <source>The signature did not match the message digest.</source>
        <translation type="unfinished">La subskribo ne kongruis kun la mesaĝ-kompilaĵo.</translation>
    </message>
    <message>
        <source>Message verification failed.</source>
        <translation type="unfinished">Kontrolo de mesaĝo malsukcesis.</translation>
    </message>
    <message>
        <source>Message verified.</source>
        <translation type="unfinished">Mesaĝo sukcese kontrolita.</translation>
    </message>
</context>
<context>
    <name>TransactionDesc</name>
    <message>
        <source>%1/unconfirmed</source>
        <extracomment>Text explaining the current status of a transaction, shown in the status field of the details window for this transaction. This status represents a transaction confirmed in at least one block, but less than 6 blocks.</extracomment>
        <translation type="unfinished">%1/nekonfirmite</translation>
    </message>
    <message>
        <source>%1 confirmations</source>
        <extracomment>Text explaining the current status of a transaction, shown in the status field of the details window for this transaction. This status represents a transaction confirmed in 6 or more blocks.</extracomment>
        <translation type="unfinished">%1 konfirmoj</translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished">Stato</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished">Dato</translation>
    </message>
    <message>
        <source>Source</source>
        <translation type="unfinished">Fonto</translation>
    </message>
    <message>
        <source>Generated</source>
        <translation type="unfinished">Kreita</translation>
    </message>
    <message>
        <source>From</source>
        <translation type="unfinished">De</translation>
    </message>
    <message>
        <source>unknown</source>
        <translation type="unfinished">nekonata</translation>
    </message>
    <message>
        <source>To</source>
        <translation type="unfinished">Al</translation>
    </message>
    <message>
        <source>own address</source>
        <translation type="unfinished">propra adreso</translation>
    </message>
    <message>
        <source>label</source>
        <translation type="unfinished">etikedo</translation>
    </message>
    <message>
        <source>Credit</source>
        <translation type="unfinished">Kredito</translation>
    </message>
    <message numerus="yes">
        <source>matures in %n more block(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message>
        <source>not accepted</source>
        <translation type="unfinished">ne akceptita</translation>
    </message>
    <message>
        <source>Debit</source>
        <translation type="unfinished">Debeto</translation>
    </message>
    <message>
        <source>Transaction fee</source>
        <translation type="unfinished">Krompago</translation>
    </message>
    <message>
        <source>Net amount</source>
        <translation type="unfinished">Neta sumo</translation>
    </message>
    <message>
        <source>Message</source>
        <translation type="unfinished">Mesaĝo</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation type="unfinished">Komento</translation>
    </message>
    <message>
        <source>Transaction ID</source>
        <translation type="unfinished">Transakcia ID</translation>
    </message>
    <message>
        <source>Merchant</source>
        <translation type="unfinished">Vendisto</translation>
    </message>
    <message>
        <source>Generated coins must mature %1 blocks before they can be spent. When you generated this block, it was broadcast to the network to be added to the block chain. If it fails to get into the chain, its state will change to "not accepted" and it won't be spendable. This may occasionally happen if another node generates a block within a few seconds of yours.</source>
        <translation type="unfinished">Kreitaj moneroj devas esti maturaj je %1 blokoj antaŭ ol eblas elspezi ilin. Kiam vi generis tiun ĉi blokon, ĝi estis elsendita al la reto por aldono al la blokĉeno. Se tiu aldono malsukcesas, ĝia stato ŝanĝiĝos al "neakceptita" kaj ne eblos elspezi ĝin. Tio estas malofta, sed povas okazi se alia bloko estas kreita je preskaŭ la sama momento kiel la via.</translation>
    </message>
    <message>
        <source>Debug information</source>
        <translation type="unfinished">Sencimigaj informoj</translation>
    </message>
    <message>
        <source>Transaction</source>
        <translation type="unfinished">Transakcio</translation>
    </message>
    <message>
        <source>Inputs</source>
        <translation type="unfinished">Enigoj</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">Sumo</translation>
    </message>
    <message>
        <source>true</source>
        <translation type="unfinished">vera</translation>
    </message>
    <message>
        <source>false</source>
        <translation type="unfinished">malvera</translation>
    </message>
</context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <source>This pane shows a detailed description of the transaction</source>
        <translation type="unfinished">Tiu ĉi panelo montras detalan priskribon de la transakcio</translation>
    </message>
    </context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Date</source>
        <translation type="unfinished">Dato</translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished">Tipo</translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished">Etikedo</translation>
    </message>
    <message>
        <source>Unconfirmed</source>
        <translation type="unfinished">Nekonfirmita</translation>
    </message>
    <message>
        <source>Confirmed (%1 confirmations)</source>
        <translation type="unfinished">Konfirmita (%1 konfirmoj)</translation>
    </message>
    <message>
        <source>Generated but not accepted</source>
        <translation type="unfinished">Kreita sed ne akceptita</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation type="unfinished">Ricevita kun</translation>
    </message>
    <message>
        <source>Received from</source>
        <translation type="unfinished">Ricevita de</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation type="unfinished">Sendita al</translation>
    </message>
    <message>
        <source>Payment to yourself</source>
        <translation type="unfinished">Pago al vi mem</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation type="unfinished">Minita</translation>
    </message>
    <message>
        <source>(n/a)</source>
        <translation type="unfinished">neaplikebla</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(neniu etikedo)</translation>
    </message>
    <message>
        <source>Transaction status. Hover over this field to show number of confirmations.</source>
        <translation type="unfinished">Transakcia stato. Ŝvebi super tiu ĉi kampo por montri la nombron de konfirmoj.</translation>
    </message>
    <message>
        <source>Date and time that the transaction was received.</source>
        <translation type="unfinished">Dato kaj horo kiam la transakcio alvenis.</translation>
    </message>
    <message>
        <source>Type of transaction.</source>
        <translation type="unfinished">Tipo de transakcio.</translation>
    </message>
    <message>
        <source>Amount removed from or added to balance.</source>
        <translation type="unfinished">Sumo elprenita de aŭ aldonita al la saldo.</translation>
    </message>
</context>
<context>
    <name>TransactionView</name>
    <message>
        <source>All</source>
        <translation type="unfinished">Ĉiuj</translation>
    </message>
    <message>
        <source>Today</source>
        <translation type="unfinished">Hodiaŭ</translation>
    </message>
    <message>
        <source>This week</source>
        <translation type="unfinished">Ĉi-semajne</translation>
    </message>
    <message>
        <source>This month</source>
        <translation type="unfinished">Ĉi-monate</translation>
    </message>
    <message>
        <source>Last month</source>
        <translation type="unfinished">Pasintmonate</translation>
    </message>
    <message>
        <source>This year</source>
        <translation type="unfinished">Ĉi-jare</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation type="unfinished">Ricevita kun</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation type="unfinished">Sendita al</translation>
    </message>
    <message>
        <source>To yourself</source>
        <translation type="unfinished">Al vi mem</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation type="unfinished">Minita</translation>
    </message>
    <message>
        <source>Other</source>
        <translation type="unfinished">Aliaj</translation>
    </message>
    <message>
        <source>Min amount</source>
        <translation type="unfinished">Minimuma sumo</translation>
    </message>
    <message>
        <source>Comma separated file</source>
        <extracomment>Expanded name of the CSV file format. See: https://en.wikipedia.org/wiki/Comma-separated_values.</extracomment>
        <translation type="unfinished">Perkome disigita dosiero</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation type="unfinished">Konfirmita</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished">Dato</translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished">Tipo</translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished">Etikedo</translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="unfinished">Adreso</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation type="unfinished">ekspotado malsukcesinta</translation>
    </message>
    <message>
        <source>Range:</source>
        <translation type="unfinished">Intervalo:</translation>
    </message>
    <message>
        <source>to</source>
        <translation type="unfinished">al</translation>
    </message>
</context>
<context>
    <name>WalletFrame</name>
    <message>
        <source>Create a new wallet</source>
        <translation type="unfinished">Krei novan monujon</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">Eraro</translation>
    </message>
    </context>
<context>
    <name>WalletModel</name>
    <message>
        <source>Send Coins</source>
        <translation type="unfinished">Sendi Bitmonon</translation>
    </message>
    <message>
        <source>default wallet</source>
        <translation type="unfinished">defaŭlta monujo</translation>
    </message>
</context>
<context>
    <name>WalletView</name>
    <message>
        <source>&amp;Export</source>
        <translation type="unfinished">&amp;Eksporti</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation type="unfinished">Eksporti la datumojn el la aktuala langeto al dosiero</translation>
    </message>
    <message>
        <source>Backup Wallet</source>
        <translation type="unfinished">Krei sekurkopion de monujo</translation>
    </message>
    <message>
        <source>Backup Failed</source>
        <translation type="unfinished">Malsukcesis sekurkopio</translation>
    </message>
    <message>
        <source>Backup Successful</source>
        <translation type="unfinished">Sukcesis krei sekurkopion</translation>
    </message>
    </context>
<context>
    <name>kawra-core</name>
    <message>
        <source>This is a pre-release test build - use at your own risk - do not use for mining or merchant applications</source>
        <translation type="unfinished">Tiu ĉi estas antaŭeldona testa versio - uzu laŭ via propra risko - ne uzu por minado aŭ por aplikaĵoj por vendistoj</translation>
    </message>
    <message>
        <source>Warning: We do not appear to fully agree with our peers! You may need to upgrade, or other nodes may need to upgrade.</source>
        <translation type="unfinished">Averto: ŝajne ni ne tute konsentas kun niaj samtavolanoj! Eble vi devas ĝisdatigi vian klienton, aŭ eble aliaj nodoj faru same.</translation>
    </message>
    <message>
        <source>Corrupted block database detected</source>
        <translation type="unfinished">Difektita blokdatumbazo trovita</translation>
    </message>
    <message>
        <source>Do you want to rebuild the block database now?</source>
        <translation type="unfinished">Ĉu vi volas rekonstrui la blokdatumbazon nun?</translation>
    </message>
    <message>
        <source>Done loading</source>
        <translation type="unfinished">Ŝargado finiĝis</translation>
    </message>
    <message>
        <source>Error initializing block database</source>
        <translation type="unfinished">Eraro dum pravalorizado de blokdatumbazo</translation>
    </message>
    <message>
        <source>Error initializing wallet database environment %s!</source>
        <translation type="unfinished">Eraro dum pravalorizado de monuj-datumbaza ĉirkaŭaĵo %s!</translation>
    </message>
    <message>
        <source>Error loading block database</source>
        <translation type="unfinished">Eraro dum ŝargado de blokdatumbazo</translation>
    </message>
    <message>
        <source>Error opening block database</source>
        <translation type="unfinished">Eraro dum malfermado de blokdatumbazo</translation>
    </message>
    <message>
        <source>Failed to listen on any port. Use -listen=0 if you want this.</source>
        <translation type="unfinished">Ne sukcesis aŭskulti ajnan pordon. Uzu -listen=0 se tion vi volas.</translation>
    </message>
    <message>
        <source>Incorrect or no genesis block found. Wrong datadir for network?</source>
        <translation type="unfinished">Geneza bloko aŭ netrovita aŭ neĝusta. Ĉu eble la datadir de la reto malĝustas?</translation>
    </message>
    <message>
        <source>Insufficient funds</source>
        <translation type="unfinished">Nesufiĉa mono</translation>
    </message>
    <message>
        <source>Not enough file descriptors available.</source>
        <translation type="unfinished">Nesufiĉa nombro de dosierpriskribiloj disponeblas.</translation>
    </message>
    <message>
        <source>Signing transaction failed</source>
        <translation type="unfinished">Subskriba transakcio fiaskis</translation>
    </message>
    <message>
        <source>This is experimental software.</source>
        <translation type="unfinished">ĝi estas eksperimenta programo</translation>
    </message>
    <message>
        <source>Transaction amount too small</source>
        <translation type="unfinished">Transakcia sumo tro malgranda</translation>
    </message>
    <message>
        <source>Transaction too large</source>
        <translation type="unfinished">Transakcio estas tro granda</translation>
    </message>
    <message>
        <source>Unknown network specified in -onlynet: '%s'</source>
        <translation type="unfinished">Nekonata reto specifita en -onlynet: '%s'</translation>
    </message>
    </context>
</TS>