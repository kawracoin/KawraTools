<TS version="2.1" language="kl">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>&amp;New</source>
        <translation type="unfinished">&amp;Nutaamik sanagit</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation type="unfinished">&amp;Kopeeruk</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation type="unfinished">M&amp;atuguk</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation type="unfinished">Allattorsimaffimminngaanniit toqqakkat peeruk</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation type="unfinished">&amp;Peeruk</translation>
    </message>
    </context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Label</source>
        <translation type="unfinished">Taaguut</translation>
    </message>
    </context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Enter passphrase</source>
        <translation type="unfinished">Isissutissaq allaguk</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation type="unfinished">Isissutissaq nutaaq sanajuk</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation type="unfinished">Isissutissaq ilaaqqiguk</translation>
    </message>
    <message>
        <source>Show passphrase</source>
        <translation type="unfinished">Isissutissaq nuisiguk</translation>
    </message>
    <message>
        <source>Encrypt wallet</source>
        <translation type="unfinished">Aningaasiviit kode-leruk</translation>
    </message>
    <message>
        <source>Unlock wallet</source>
        <translation type="unfinished">Aningaasiviit parnaarunnaaruk</translation>
    </message>
    <message>
        <source>Change passphrase</source>
        <translation type="unfinished">Isertaatik allanngortiguk</translation>
    </message>
    <message>
        <source>Confirm wallet encryption</source>
        <translation type="unfinished">Aningaasivippit matuersaataa uppernarsaruk</translation>
    </message>
    <message>
        <source>Wallet encrypted</source>
        <translation type="unfinished">Angingaasivik paasipuminaappoq</translation>
    </message>
    <message>
        <source>Wallet passphrase was successfully changed.</source>
        <translation type="unfinished">Aningaasiviup isissutissaa taarserpoq</translation>
    </message>
    </context>
<context>
    <name>QObject</name>
    <message>
        <source>Amount</source>
        <translation type="unfinished">Aningaasat amerlassusaa</translation>
    </message>
    <message>
        <source>%1 h</source>
        <translation type="unfinished">%1 t</translation>
    </message>
    <message numerus="yes">
        <source>%n second(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n minute(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n hour(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n day(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n week(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n year(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    </context>
<context>
    <name>KawraGUI</name>
    <message>
        <source>Wallet:</source>
        <translation type="unfinished">Aningaasivik:</translation>
    </message>
    <message numerus="yes">
        <source>Processed %n block(s) of transaction history.</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message>
        <source>Open Wallet</source>
        <translation type="unfinished">Ammaruk aningaasivik</translation>
    </message>
    <message numerus="yes">
        <source>%n active connection(s) to Kawra network.</source>
        <extracomment>A substring of the tooltip.</extracomment>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message>
        <source>Amount: %1
</source>
        <translation type="unfinished">Kawra amerlassusaa: %1
</translation>
    </message>
    </context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Fee:</source>
        <translation type="unfinished">Akileraarut</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation type="unfinished">Akileraarut peereerlugu:</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">Aningaasat amerlassusaa</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished">Ulloq</translation>
    </message>
    <message>
        <source>Confirmations</source>
        <translation type="unfinished">Akuersissutit</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation type="unfinished">Akuerineqarpoq</translation>
    </message>
    </context>
<context>
    <name>OpenWalletActivity</name>
    <message>
        <source>Open Wallet</source>
        <extracomment>Title of window indicating the progress of opening of a wallet.</extracomment>
        <translation type="unfinished">Ammaruk aningaasivik</translation>
    </message>
    </context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>&amp;Label</source>
        <translation type="unfinished">&amp;Taajuut</translation>
    </message>
    <message>
        <source>Could not unlock wallet.</source>
        <translation type="unfinished">Aningaasivik ammarneqanngilaq</translation>
    </message>
    </context>
<context>
    <name>Intro</name>
    <message numerus="yes">
        <source>%n GB of space available</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>(of %n GB needed)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>(%n GB needed for full chain)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>(sufficient to restore backups %n day(s) old)</source>
        <extracomment>Explanatory text on the capability of the current prune target.</extracomment>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message>
        <source>Welcome</source>
        <translation type="unfinished">Tikilluarit</translation>
    </message>
    <message>
        <source>Welcome to %1.</source>
        <translation type="unfinished">Tikilluarit uunga %1</translation>
    </message>
    </context>
<context>
    <name>ModalOverlay</name>
    <message>
        <source>Hide</source>
        <translation type="unfinished">Tarrisiguk</translation>
    </message>
    </context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation type="unfinished">Toqqagassat</translation>
    </message>
    </context>
<context>
    <name>ReceiveCoinsDialog</name>
    <message>
        <source>Could not unlock wallet.</source>
        <translation type="unfinished">Aningaasivik ammarneqanngilaq</translation>
    </message>
    </context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>Wallet:</source>
        <translation type="unfinished">Aningaasivik:</translation>
    </message>
    </context>
<context>
    <name>RecentRequestsTableModel</name>
    <message>
        <source>Date</source>
        <translation type="unfinished">Ulloq</translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished">Taaguut</translation>
    </message>
    </context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Fee:</source>
        <translation type="unfinished">Akileraarut</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation type="unfinished">Akileraarut peereerlugu:</translation>
    </message>
    <message>
        <source>Hide</source>
        <translation type="unfinished">Tarrisiguk</translation>
    </message>
    <message numerus="yes">
        <source>Estimated to begin confirmation within %n block(s).</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    </context>
<context>
    <name>TransactionDesc</name>
    <message>
        <source>Date</source>
        <translation type="unfinished">Ulloq</translation>
    </message>
    <message numerus="yes">
        <source>matures in %n more block(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">Aningaasat amerlassusaa</translation>
    </message>
    </context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Date</source>
        <translation type="unfinished">Ulloq</translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished">Taaguut</translation>
    </message>
    </context>
<context>
    <name>TransactionView</name>
    <message>
        <source>Confirmed</source>
        <translation type="unfinished">Akuerineqarpoq</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished">Ulloq</translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished">Taaguut</translation>
    </message>
    </context>
</TS>