<TS version="2.1" language="km">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Right-click to edit address or label</source>
        <translation type="unfinished">ចុចម៉ៅស្តាំ ដើម្បីកែសម្រួលអាសយដ្ឋាន រឺស្លាក</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation type="unfinished">បង្កើតអាសយដ្ឋានថ្មី</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation type="unfinished">ថ្មី(&amp;N)</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation type="unfinished">ចម្លងអាសយដ្ឋានបច្ចុប្បន្នដែលបានជ្រើសទៅក្ដារតម្រៀបរបស់ប្រព័ន្ធ</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation type="unfinished">ចម្លង(&amp;C)</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation type="unfinished">បិទ(&amp;l)</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation type="unfinished">លុប​អាសយដ្ឋានដែល​បានជ្រើស​ពី​បញ្ជី</translation>
    </message>
    <message>
        <source>Enter address or label to search</source>
        <translation type="unfinished">បញ្ចូលអាសយដ្ឋាន រឺ ស្លាក​ ដើម្បីស្វែងរក</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation type="unfinished">នាំចេញទិន្នន័យនៃផ្ទាំងបច្ចុប្បន្នទៅជាឯកសារមួយ</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation type="unfinished">នាំចេញ(&amp;E)</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation type="unfinished">លុប(&amp;D)</translation>
    </message>
    <message>
        <source>Choose the address to send coins to</source>
        <translation type="unfinished">ជ្រើសរើសអាសយដ្ឋានដើម្បីផ្ញើកាក់ទៅ</translation>
    </message>
    <message>
        <source>Choose the address to receive coins with</source>
        <translation type="unfinished">ជ្រើសរើសអាសយដ្ឋានដើម្បីទទួលយកកាក់ជាមួយ</translation>
    </message>
    <message>
        <source>C&amp;hoose</source>
        <translation type="unfinished">ជ្រើសរើស(&amp;h)</translation>
    </message>
    <message>
        <source>Sending addresses</source>
        <translation type="unfinished">អាសយដ្ឋានសម្រាប់ផ្ញើ</translation>
    </message>
    <message>
        <source>Receiving addresses</source>
        <translation type="unfinished">អាសយដ្ឋានសម្រាប់ទទួល</translation>
    </message>
    <message>
        <source>These are your Kawra addresses for sending payments. Always check the amount and the receiving address before sending coins.</source>
        <translation type="unfinished">ទាំងនេះ​គឺជាអាសយដ្ឋាន Kawra របស់អ្នកសម្រាប់ធ្វើការផ្ញើការបង់ប្រាក់។ តែងតែពិនិត្យមើលចំនួនប្រាក់ និងអាសយដ្ឋានដែលទទួល មុនពេលផ្ញើប្រាក់។</translation>
    </message>
    <message>
        <source>These are your Kawra addresses for receiving payments. Use the 'Create new receiving address' button in the receive tab to create new addresses.
Signing is only possible with addresses of the type 'legacy'.</source>
        <translation type="unfinished">ទាំងនេះគឺជាអាសយដ្ឋាន Kawra របស់អ្នកសម្រាប់ការទទួលការទូទាត់។ ប្រើប៊ូតុង 'បង្កើតអាសយដ្ឋានទទួលថ្មី' នៅក្នុងផ្ទាំងទទួល ដើម្បីបង្កើតអាសយដ្ឋានថ្មី។ 
ការចុះហត្ថលេខាគឺអាចធ្វើទៅបានតែជាមួយអាសយដ្ឋាននៃប្រភេទ 'legacy' ប៉ុណ្ណោះ។</translation>
    </message>
    <message>
        <source>&amp;Copy Address</source>
        <translation type="unfinished">ចម្លងអាសយដ្ឋាន(&amp;C)</translation>
    </message>
    <message>
        <source>Copy &amp;Label</source>
        <translation type="unfinished">ចម្លង ស្លាក​សញ្ញា(&amp;L)</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation type="unfinished">កែសម្រួល(&amp;E)</translation>
    </message>
    <message>
        <source>Export Address List</source>
        <translation type="unfinished">នាំចេញនូវបញ្ជីអាសយដ្ឋាន</translation>
    </message>
    <message>
        <source>Comma separated file</source>
        <extracomment>Expanded name of the CSV file format. See: https://en.wikipedia.org/wiki/Comma-separated_values.</extracomment>
        <translation type="unfinished">Comma បំបែកឯកសារ</translation>
    </message>
    <message>
        <source>There was an error trying to save the address list to %1. Please try again.</source>
        <extracomment>An error message. %1 is a stand-in argument for the name of the file we attempted to save to.</extracomment>
        <translation type="unfinished">មានបញ្ហាក្នុងការព្យាយាម រក្សាទុកបញ្ជីអាសយដ្ឋានដល់ %1។ សូមព្យាយាមម្ដងទៀត។</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation type="unfinished">ការនាំចេញបានបរាជ័យ</translation>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Label</source>
        <translation type="unfinished">ស្លាក​</translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="unfinished">អាសយដ្ឋាន</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(គ្មាន​ស្លាក​)</translation>
    </message>
</context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Passphrase Dialog</source>
        <translation type="unfinished">ការហៅឃ្លាសម្ងាត់</translation>
    </message>
    <message>
        <source>Enter passphrase</source>
        <translation type="unfinished">បញ្ចូលឃ្លាសម្ងាត់</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation type="unfinished">ឃ្លាសម្ងាត់ថ្មី</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation type="unfinished">ឃ្លាសម្ងាត់ថ្នីម្ដងទៀត</translation>
    </message>
    <message>
        <source>Show passphrase</source>
        <translation type="unfinished">បង្ហាញឃ្លាសម្ងាត់</translation>
    </message>
    <message>
        <source>Encrypt wallet</source>
        <translation type="unfinished">អ៊ិនគ្រីបកាបូប​ចល័ត</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation type="unfinished">ប្រតិបត្តិការនេះ ត្រូវការឃ្លាសម្ងាត់កាបូបចល័តរបស់អ្នក ដើម្បីដោះសោរកាបូបចល័ត។</translation>
    </message>
    <message>
        <source>Unlock wallet</source>
        <translation type="unfinished">ដោះសោរកាបូបចល័ត</translation>
    </message>
    <message>
        <source>Change passphrase</source>
        <translation type="unfinished">ផ្លាស់ប្ដូរឃ្លាសម្ងាត់</translation>
    </message>
    <message>
        <source>Confirm wallet encryption</source>
        <translation type="unfinished">បញ្ជាក់ការអ៊ិនគ្រីបកាបូបចល័ត</translation>
    </message>
    <message>
        <source>Warning: If you encrypt your wallet and lose your passphrase, you will &lt;b&gt;LOSE ALL OF YOUR KAWRAS&lt;/b&gt;!</source>
        <translation type="unfinished">ការព្រមាន៖ ប្រសិនបើអ្នកអ៊ិនគ្រីបកាបូបចល័តរបស់អ្នក ហើយអ្នកភ្លេចបាត់ឃ្លាសម្ងាត់ នោះអ្នកនិង &lt;b&gt;បាត់បង់ KAWRAS របស់អ្នកទាំងអស់&lt;/b&gt;!</translation>
    </message>
    <message>
        <source>Are you sure you wish to encrypt your wallet?</source>
        <translation type="unfinished">តើអ្នកពិតជាចង់អ៊ិនគ្រីបកាបូបចល័តរបស់អ្នកឬ?</translation>
    </message>
    <message>
        <source>Wallet encrypted</source>
        <translation type="unfinished">កាបូបចល័ត ដែលបានអ៊ិនគ្រីប</translation>
    </message>
    <message>
        <source>Enter the new passphrase for the wallet.&lt;br/&gt;Please use a passphrase of &lt;b&gt;ten or more random characters&lt;/b&gt;, or &lt;b&gt;eight or more words&lt;/b&gt;.</source>
        <translation type="unfinished">បញ្ចូលឃ្លាសម្ងាត់សំរាប់កាបូប។ &lt;br/&gt;សូមប្រើឃ្លាសម្ងាត់ពី&lt;b&gt;១០ តួ&lt;/b&gt;ឬ&lt;b&gt;ច្រើនជាងនេះ, ៨ពាក្យឬច្រើនជាងនេះ&lt;/b&gt;។.</translation>
    </message>
    <message>
        <source>Enter the old passphrase and new passphrase for the wallet.</source>
        <translation type="unfinished">វាយបញ្ចូលឃ្លាសម្ងាត់ចាស់ និងឃ្លាសសម្លាត់ថ្មី សម្រាប់កាបូបចល័តរបស់អ្នក។</translation>
    </message>
    <message>
        <source>Remember that encrypting your wallet cannot fully protect your kawras from being stolen by malware infecting your computer.</source>
        <translation type="unfinished">សូមចងចាំថាការអ៊ិនគ្រីបកាបូបរបស់អ្នកមិនអាចការពារបានពេញលេញនូវ kawras របស់អ្នកពីការលួចដោយមេរោគដែលឆ្លងកុំព្យូទ័ររបស់អ្នក។</translation>
    </message>
    <message>
        <source>Wallet to be encrypted</source>
        <translation type="unfinished">កាបូបចល័ត ដែលត្រូវបានអ៊ិនគ្រីប</translation>
    </message>
    <message>
        <source>Your wallet is about to be encrypted. </source>
        <translation type="unfinished">កាបូបចល័តរបស់អ្នក ជិតត្រូវបានអ៊ិនគ្រីបហើយ។</translation>
    </message>
    <message>
        <source>Your wallet is now encrypted. </source>
        <translation type="unfinished">កាបូបចល័តរបស់អ្នក ឥឡូវត្រូវបានអ៊ិនគ្រីប។</translation>
    </message>
    <message>
        <source>IMPORTANT: Any previous backups you have made of your wallet file should be replaced with the newly generated, encrypted wallet file. For security reasons, previous backups of the unencrypted wallet file will become useless as soon as you start using the new, encrypted wallet.</source>
        <translation type="unfinished">សំខាន់៖ ការបម្រុងទុកពីមុនណាមួយដែលអ្នកបានធ្វើពីឯកសារកាបូបរបស់អ្នកគួរតែត្រូវបានជំនួសដោយឯកសារកាបូបដែលបានអ៊ិនគ្រីបដែលបានបង្កើតថ្មី។សម្រាប់ហេតុផលសុវត្ថិភាព ការបម្រុងទុកពីមុននៃឯកសារកាបូបដែលមិនបានអ៊ិនគ្រីបនឹងក្លាយទៅជាគ្មានប្រយោជន៍ភ្លាមៗនៅពេលដែលអ្នកចាប់ផ្តើមប្រើកាបូបដែលបានអ៊ិនគ្រីបថ្មី។</translation>
    </message>
    <message>
        <source>Wallet encryption failed</source>
        <translation type="unfinished">កាបូបចល័ត បានអ៊ិនគ្រីបបរាជ័យ</translation>
    </message>
    <message>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation type="unfinished">ការអ៊ិនគ្រីបកាបូបចល័ត បានបរាជ័យដោយសារកំហុសខាងក្នុង។ កាបូបចល័តរបស់អ្នកមិនត្រូវបានអ៊ិនគ្រីបទេ។</translation>
    </message>
    <message>
        <source>The supplied passphrases do not match.</source>
        <translation type="unfinished">ឃ្លាសម្ងាត់ ដែលបានផ្គត់ផ្គង់មិនត្រូវគ្នាទេ។</translation>
    </message>
    <message>
        <source>Wallet unlock failed</source>
        <translation type="unfinished">បរាជ័យដោះសោរកាបូបចល័ត</translation>
    </message>
    <message>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation type="unfinished">ឃ្លាសម្ងាត់ ដែលបានបញ្ចូលសម្រាប់ការអ៊ិនគ្រីបកាបូបចល័តគឺមិនត្រឹមត្រូវទេ។</translation>
    </message>
    <message>
        <source>The passphrase entered for the wallet decryption is incorrect. It contains a null character (ie - a zero byte). If the passphrase was set with a version of this software prior to 25.0, please try again with only the characters up to — but not including — the first null character. If this is successful, please set a new passphrase to avoid this issue in the future.</source>
        <translation type="unfinished">ឃ្លាសម្ងាត់ដែលបានបញ្ចូលសម្រាប់ការឌិគ្រីបកាបូបគឺមិនត្រឹមត្រូវទេ។ វាមានតួអក្សរទទេ (ឧ - សូន្យបៃ)។ ប្រសិនបើឃ្លាសម្ងាត់ត្រូវបានកំណត់ជាមួយនឹងកំណែនៃកម្មវិធីនេះមុន 25.0 សូមព្យាយាមម្តងទៀតដោយប្រើតែតួអក្សររហូតដល់ — ប៉ុន្តែមិនរាប់បញ្ចូល — តួអក្សរទទេដំបូង។ ប្រសិនបើ​វា​ជោគជ័យ សូម​កំណត់​ឃ្លាសម្ងាត់​ថ្មី ដើម្បី​ចៀសវាង​បញ្ហា​នេះ​នៅពេល​អនាគត។</translation>
    </message>
    <message>
        <source>Wallet passphrase was successfully changed.</source>
        <translation type="unfinished">ឃ្លាសម្ងាត់នៃកាបូបចល័ត ត្រូវបានផ្លាស់ប្តូរដោយជោគជ័យ។</translation>
    </message>
    <message>
        <source>Passphrase change failed</source>
        <translation type="unfinished">ប្ដូរ​ឃ្លា​សម្ងាត់​បាន​បរាជ័យ</translation>
    </message>
    <message>
        <source>The old passphrase entered for the wallet decryption is incorrect. It contains a null character (ie - a zero byte). If the passphrase was set with a version of this software prior to 25.0, please try again with only the characters up to — but not including — the first null character.</source>
        <translation type="unfinished">ឃ្លាសម្ងាត់ចាស់ដែលបានបញ្ចូលសម្រាប់ការឌិគ្រីបកាបូបគឺមិនត្រឹមត្រូវទេ។ វាមានតួអក្សរទទេ (ឧ - សូន្យបៃ)។ ប្រសិនបើឃ្លាសម្ងាត់ត្រូវបានកំណត់ជាមួយនឹងកំណែនៃកម្មវិធីនេះមុន 25.0 សូមព្យាយាមម្តងទៀតដោយប្រើតែតួអក្សររហូតដល់ — ប៉ុន្តែមិនរាប់បញ្ចូល — តួអក្សរទទេដំបូង។</translation>
    </message>
    <message>
        <source>Warning: The Caps Lock key is on!</source>
        <translation type="unfinished">ការព្រមាន៖ ឃី Caps Lock គឺបើក!</translation>
    </message>
</context>
<context>
    <name>BanTableModel</name>
    <message>
        <source>Banned Until</source>
        <translation type="unfinished">បានហាមឃាត់រហូតដល់</translation>
    </message>
</context>
<context>
    <name>KawraApplication</name>
    <message>
        <source>Settings file %1 might be corrupt or invalid.</source>
        <translation type="unfinished">ឯកសារការកំណត់%1អាចខូច ឬមិនត្រឹមត្រូវ។</translation>
    </message>
    <message>
        <source>Runaway exception</source>
        <translation type="unfinished">ករណីលើកលែងដែលរត់គេចខ្លួន</translation>
    </message>
    <message>
        <source>A fatal error occurred. %1 can no longer continue safely and will quit.</source>
        <translation type="unfinished">កំហុសធ្ងន់ធ្ងរបានកើតឡើង។ %1 មិនអាចបន្តដោយសុវត្ថិភាពទៀតទេ ហើយនឹងឈប់ដំណើរការ។</translation>
    </message>
    <message>
        <source>Internal error</source>
        <translation type="unfinished">ខាងក្នុងបញ្ហា</translation>
    </message>
    <message>
        <source>An internal error occurred. %1 will attempt to continue safely. This is an unexpected bug which can be reported as described below.</source>
        <translation type="unfinished">កំហុសខាងក្នុងបានកើតឡើង។ %1នឹងព្យាយាមបន្តដោយសុវត្ថិភាព។ នេះ​ជា​កំហុស​ដែល​មិន​នឹក​ស្មាន​ដល់ ដែល​អាច​ត្រូវ​បាន​រាយការណ៍​ដូច​បាន​ពណ៌នា​ខាង​ក្រោម។</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Do you want to reset settings to default values, or to abort without making changes?</source>
        <extracomment>Explanatory text shown on startup when the settings file cannot be read. Prompts user to make a choice between resetting or aborting.</extracomment>
        <translation type="unfinished">តើ​អ្នក​ចង់​កំណត់​ការ​កំណត់​ឡើង​វិញ​ទៅ​ជា​តម្លៃ​លំនាំដើម ឬ​បោះបង់​ដោយ​មិន​ធ្វើ​ការ​ផ្លាស់ប្ដូរ?</translation>
    </message>
    <message>
        <source>A fatal error occurred. Check that settings file is writable, or try running with -nosettings.</source>
        <extracomment>Explanatory text shown on startup when the settings file could not be written. Prompts user to check that we have the ability to write to the file. Explains that the user has the option of running without a settings file.</extracomment>
        <translation type="unfinished">កំហុសធ្ងន់ធ្ងរបានកើតឡើង។ ពិនិត្យមើលថាឯកសារការកំណត់អាចសរសេរបាន ឬព្យាយាមដំណើរការជាមួយ -nosettings។</translation>
    </message>
    <message>
        <source>Error: %1</source>
        <translation type="unfinished">កំហុស៖%1</translation>
    </message>
    <message>
        <source>%1 didn't yet exit safely…</source>
        <translation type="unfinished">%1មិនទាន់ចេញដោយសុវត្ថិភាពទេ…</translation>
    </message>
    <message>
        <source>unknown</source>
        <translation type="unfinished">មិនស្គាល់</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">ចំនួន</translation>
    </message>
    <message>
        <source>Full Relay</source>
        <extracomment>Peer connection type that relays all network information.</extracomment>
        <translation type="unfinished">ការបញ្ជូនតពេញ</translation>
    </message>
    <message>
        <source>Block Relay</source>
        <extracomment>Peer connection type that relays network information about blocks and not transactions or addresses.</extracomment>
        <translation type="unfinished">ប្លុកបញ្ជូនត</translation>
    </message>
    <message>
        <source>Manual</source>
        <extracomment>Peer connection type established manually through one of several methods.</extracomment>
        <translation type="unfinished">ហត្ថកម្ម</translation>
    </message>
    <message>
        <source>Address Fetch</source>
        <extracomment>Short-lived peer connection type that solicits known addresses from a peer.</extracomment>
        <translation type="unfinished">ទាញអាសយដ្ឋាន</translation>
    </message>
    <message>
        <source>None</source>
        <translation type="unfinished">មិន</translation>
    </message>
    <message numerus="yes">
        <source>%n second(s)</source>
        <translation type="unfinished">
            <numerusform>%n(ច្រើន)វិនាទី</numerusform>
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n minute(s)</source>
        <translation type="unfinished">
            <numerusform>%n(ច្រើន)នាទី</numerusform>
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n hour(s)</source>
        <translation type="unfinished">
            <numerusform>%n(ច្រើន)ម៉ោង</numerusform>
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n day(s)</source>
        <translation type="unfinished">
            <numerusform>%n(ច្រើន)</numerusform>
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n week(s)</source>
        <translation type="unfinished">
            <numerusform>%n(ច្រើន)</numerusform>
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n year(s)</source>
        <translation type="unfinished">
            <numerusform>%n(ច្រើន)</numerusform>
            <numerusform />
        </translation>
    </message>
    <message>
        <source>%1 kB</source>
        <translation type="unfinished"> %1 kB</translation>
    </message>
    </context>
<context>
    <name>KawraGUI</name>
    <message>
        <source>&amp;Overview</source>
        <translation type="unfinished">ទិដ្ឋភាពទូទៅ</translation>
    </message>
    <message>
        <source>Show general overview of wallet</source>
        <translation type="unfinished">បង្ហាញទិដ្ឋភាពទូទៅនៃកាបូបចល័ត</translation>
    </message>
    <message>
        <source>&amp;Transactions</source>
        <translation type="unfinished">ប្រតិបត្តិការ</translation>
    </message>
    <message>
        <source>Browse transaction history</source>
        <translation type="unfinished">រកមើលប្រវត្តិប្រតិបត្តិការ</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation type="unfinished">ចាកចេញ</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation type="unfinished">បោះបង់កម្មវិធី</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation type="unfinished">អំពី &amp;Qt</translation>
    </message>
    <message>
        <source>Show information about Qt</source>
        <translation type="unfinished">បង្ហាញព័ត៍មានអំពី Qt</translation>
    </message>
    <message>
        <source>Modify configuration options for %1</source>
        <translation type="unfinished">កែប្រែជម្រើសកំណត់រចនាសម្ព័ន្ធសម្រាប់ %1</translation>
    </message>
    <message>
        <source>Create a new wallet</source>
        <translation type="unfinished">បង្កើតកាបូបចល័តថ្មីមួយ</translation>
    </message>
    <message>
        <source>&amp;Minimize</source>
        <translation type="unfinished">&amp;បង្រួមអប្បបរមា</translation>
    </message>
    <message>
        <source>Wallet:</source>
        <translation type="unfinished">កាបូបចល័ត៖</translation>
    </message>
    <message>
        <source>Network activity disabled.</source>
        <extracomment>A substring of the tooltip.</extracomment>
        <translation type="unfinished">សកម្មភាពបណ្ដាញត្រូវបានផ្ដាច់។</translation>
    </message>
    <message>
        <source>Proxy is &lt;b&gt;enabled&lt;/b&gt;: %1</source>
        <translation type="unfinished">ប្រូកស៊ី ត្រូវបាន &lt;b&gt;អនុញ្ញាត&lt;/b&gt;៖ %1</translation>
    </message>
    <message>
        <source>Send coins to a Kawra address</source>
        <translation type="unfinished">ផ្ញើកាក់ទៅកាន់ អាសយដ្ឋាន Kawra មួយ</translation>
    </message>
    <message>
        <source>Backup wallet to another location</source>
        <translation type="unfinished">បម្រុកទុកនូវកាបូបចល័ត ទៅទីតាំងមួយផ្សេងទៀត</translation>
    </message>
    <message>
        <source>Change the passphrase used for wallet encryption</source>
        <translation type="unfinished">ផ្លាស់ប្ដូរឃ្លាសម្ងាត់ ដែលបានប្រើសម្រាប់ការអ៊ិនគ្រីបកាបូបចល័ត</translation>
    </message>
    <message>
        <source>&amp;Send</source>
        <translation type="unfinished">&amp;ផ្ងើរ</translation>
    </message>
    <message>
        <source>&amp;Receive</source>
        <translation type="unfinished">&amp;ទទួល</translation>
    </message>
    <message>
        <source>&amp;Options…</source>
        <translation type="unfinished">&amp;ជម្រើស…</translation>
    </message>
    <message>
        <source>&amp;Encrypt Wallet…</source>
        <translation type="unfinished">&amp;អ៊ិនគ្រីបកាបូប...</translation>
    </message>
    <message>
        <source>Encrypt the private keys that belong to your wallet</source>
        <translation type="unfinished">បំលែងលេខសំម្ងាត់សម្រាប់កាបូបអេឡិចត្រូនិច របស់អ្នកឲ្យទៅជាភាសាកុំព្យូទ័រ </translation>
    </message>
    <message>
        <source>&amp;Backup Wallet…</source>
        <translation type="unfinished">&amp;ការបម្រុងទុកកាបូប...</translation>
    </message>
    <message>
        <source>&amp;Change Passphrase…</source>
        <translation type="unfinished">&amp;ការផ្លាស់ប្តូរឃ្លាសម្ងាត់</translation>
    </message>
    <message>
        <source>Sign &amp;message…</source>
        <translation type="unfinished">ចុះហត្ថលេខា&amp;សារ…</translation>
    </message>
    <message>
        <source>Sign messages with your Kawra addresses to prove you own them</source>
        <translation type="unfinished">ចុះហត្ថលេខាលើសារ អាសយដ្ឋានប៊ីតខញរបស់អ្នក ដើម្បីបញ្ចាក់ថាអ្នកជាម្ចាស់</translation>
    </message>
    <message>
        <source>&amp;Verify message…</source>
        <translation type="unfinished">&amp;ផ្ទៀងផ្ទាត់សារ...</translation>
    </message>
    <message>
        <source>Verify messages to ensure they were signed with specified Kawra addresses</source>
        <translation type="unfinished">ធ្វើការបញ្ចាក់សារ ដើម្បីធានាថាសារទាំំងនោះបានចុះហត្ថលេខា ជាមួយអាសយដ្ខានប៊ីតខញ</translation>
    </message>
    <message>
        <source>&amp;Load PSBT from file…</source>
        <translation type="unfinished">&amp;ផ្ទុក PSBT ពីឯកសារ...</translation>
    </message>
    <message>
        <source>Open &amp;URI…</source>
        <translation type="unfinished">បើក &amp;URI…</translation>
    </message>
    <message>
        <source>Close Wallet…</source>
        <translation type="unfinished">បិទកាបូប…</translation>
    </message>
    <message>
        <source>Create Wallet…</source>
        <translation type="unfinished">បង្កើតកាបូប...</translation>
    </message>
    <message>
        <source>Close All Wallets…</source>
        <translation type="unfinished">បិទកាបូបអេឡិចត្រូនិចទាំងអស់...</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation type="unfinished">ឯកសារ</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation type="unfinished">ការកំណត់</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation type="unfinished">&amp;ជំនួយ</translation>
    </message>
    <message>
        <source>Tabs toolbar</source>
        <translation type="unfinished">ធូបារថេប</translation>
    </message>
    <message>
        <source>Syncing Headers (%1%)…</source>
        <translation type="unfinished">កំពុងសមកាល បឋមកថា (%1%)...</translation>
    </message>
    <message>
        <source>Synchronizing with network…</source>
        <translation type="unfinished">កំពុងធ្វើសមកាលកម្មជាមួយបណ្ដាញ...</translation>
    </message>
    <message>
        <source>Indexing blocks on disk…</source>
        <translation type="unfinished">កំពុងធ្វើលិបិក្រមប្លុកនៅលើថាស...</translation>
    </message>
    <message>
        <source>Processing blocks on disk…</source>
        <translation type="unfinished">កំពុងដំណើរការប្លុកនៅលើថាស...</translation>
    </message>
    <message>
        <source>Connecting to peers…</source>
        <translation type="unfinished">កំពុងភ្ជាប់ទៅមិត្តភក្ដិ...</translation>
    </message>
    <message>
        <source>Request payments (generates QR codes and kawra: URIs)</source>
        <translation type="unfinished">សំណើរទូរទាត់​(បង្កើតកូដ QR និង ប៊ីតខញ: URLs)</translation>
    </message>
    <message>
        <source>Show the list of used sending addresses and labels</source>
        <translation type="unfinished">បង្ហាញបញ្ចីរអាសយដ្ឋាន និង ស្លាកសញ្ញាបញ្ចូនបានប្រើប្រាស់</translation>
    </message>
    <message>
        <source>Show the list of used receiving addresses and labels</source>
        <translation type="unfinished">បង្ហាញបញ្ចីរអាសយដ្ឋាន និង ស្លាកសញ្ញាទទួល បានប្រើប្រាស់</translation>
    </message>
    <message>
        <source>&amp;Command-line options</source>
        <translation type="unfinished">ជំរើសខំមែនឡាញ(&amp;C)</translation>
    </message>
    <message numerus="yes">
        <source>Processed %n block(s) of transaction history.</source>
        <translation type="unfinished">
            <numerusform>បានដំណើរការ %n ប្លុកនៃប្រវត្តិប្រត្តិបត្តិការ។</numerusform>
            <numerusform />
        </translation>
    </message>
    <message>
        <source>Catching up…</source>
        <translation type="unfinished">កំពុងចាប់...</translation>
    </message>
    <message>
        <source>Transactions after this will not yet be visible.</source>
        <translation type="unfinished">ប្រត្តិបត្តិការបន្ទាប់ពីនេះ នឹងមិនអាចទាន់មើលឃើញនៅឡើយទេ។</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">បញ្ហា</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation type="unfinished">ក្រើនរំលឹកឲ្យប្រុងប្រយ័ត្ន</translation>
    </message>
    <message>
        <source>Information</source>
        <translation type="unfinished">ព័ត៍មាន</translation>
    </message>
    <message>
        <source>Up to date</source>
        <translation type="unfinished">ទាន់ពេល និង ទាន់សម័យ</translation>
    </message>
    <message>
        <source>Load Partially Signed Kawra Transaction</source>
        <translation type="unfinished">បង្ហាញប្រត្តិបត្តិការប៊ីតខញដែលបានចុះហត្ថលេខាដោយផ្នែក</translation>
    </message>
    <message>
        <source>Load PSBT from &amp;clipboard…</source>
        <translation type="unfinished">ផ្ទុក PSBT ពី &amp;clipboard...</translation>
    </message>
    <message>
        <source>Load Partially Signed Kawra Transaction from clipboard</source>
        <translation type="unfinished">បង្ហាញប្រត្តិបត្តិការប៊ីតខញដែលបានចុះហត្ថលេខាដោយផ្នែកពីក្ដារតម្រៀប</translation>
    </message>
    <message>
        <source>&amp;Receiving addresses</source>
        <translation type="unfinished">&amp;អាសយដ្ឋានទទួល</translation>
    </message>
    <message>
        <source>Open a kawra: URI</source>
        <translation type="unfinished">បើកប៊ីតខញមួយៈ URl</translation>
    </message>
    <message>
        <source>Open Wallet</source>
        <translation type="unfinished">បើកកាបូបអេឡិចត្រូនិច</translation>
    </message>
    <message>
        <source>Open a wallet</source>
        <translation type="unfinished">បើកកាបូបអេឡិចត្រូនិចមួយ</translation>
    </message>
    <message>
        <source>Close wallet</source>
        <translation type="unfinished">បិតកាបូបអេឡិចត្រូនិច</translation>
    </message>
    <message>
        <source>Restore Wallet…</source>
        <extracomment>Name of the menu item that restores wallet from a backup file.</extracomment>
        <translation type="unfinished">ស្តារកាបូប…</translation>
    </message>
    <message>
        <source>Restore a wallet from a backup file</source>
        <extracomment>Status tip for Restore Wallet menu item</extracomment>
        <translation type="unfinished">ស្តារកាបូបពីឯកសារបម្រុងទុក</translation>
    </message>
    <message>
        <source>Close all wallets</source>
        <translation type="unfinished">បិទកាបូបអេឡិចត្រូនិចទាំងអស់</translation>
    </message>
    <message>
        <source>No wallets available</source>
        <translation type="unfinished">មិនមានកាបូបអេឡិចត្រូនិច</translation>
    </message>
    <message>
        <source>Wallet Data</source>
        <extracomment>Name of the wallet data file format.</extracomment>
        <translation type="unfinished">ទិន្នន័យកាបូប</translation>
    </message>
    <message>
        <source>Load Wallet Backup</source>
        <extracomment>The title for Restore Wallet File Windows</extracomment>
        <translation type="unfinished">ទាញការបម្រុងទុកកាបូប</translation>
    </message>
    <message>
        <source>Restore Wallet</source>
        <extracomment>Title of pop-up window shown when the user is attempting to restore a wallet.</extracomment>
        <translation type="unfinished">ស្តារកាបូប</translation>
    </message>
    <message>
        <source>Wallet Name</source>
        <extracomment>Label of the input field where the name of the wallet is entered.</extracomment>
        <translation type="unfinished">ឈ្មោះកាបូប</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation type="unfinished">វិនដូ(&amp;W)</translation>
    </message>
    <message>
        <source>Main Window</source>
        <translation type="unfinished">វិនដូចម្បង</translation>
    </message>
    <message>
        <source>%1 client</source>
        <translation type="unfinished">%1 អតិថិជន</translation>
    </message>
    <message>
        <source>&amp;Hide</source>
        <translation type="unfinished">លាក់(&amp;H)</translation>
    </message>
    <message>
        <source>S&amp;how</source>
        <translation type="unfinished">របៀប(&amp;S)</translation>
    </message>
    <message numerus="yes">
        <source>%n active connection(s) to Kawra network.</source>
        <extracomment>A substring of the tooltip.</extracomment>
        <translation type="unfinished">
            <numerusform>%n ការតភ្ជាប់សកម្មទៅបណ្តាញ Kawra ។</numerusform>
            <numerusform />
        </translation>
    </message>
    <message>
        <source>Click for more actions.</source>
        <extracomment>A substring of the tooltip. "More actions" are available via the context menu.</extracomment>
        <translation type="unfinished">ចុចសម្រាប់សកម្មភាពបន្ថែម។</translation>
    </message>
    <message>
        <source>Show Peers tab</source>
        <extracomment>A context menu item. The "Peers tab" is an element of the "Node window".</extracomment>
        <translation type="unfinished">បង្ហាញផ្ទាំង Peers</translation>
    </message>
    <message>
        <source>Disable network activity</source>
        <extracomment>A context menu item.</extracomment>
        <translation type="unfinished">បិទសកម្មភាពបណ្តាញ</translation>
    </message>
    <message>
        <source>Enable network activity</source>
        <extracomment>A context menu item. The network activity was disabled previously.</extracomment>
        <translation type="unfinished">បើកសកម្មភាពបណ្តាញ</translation>
    </message>
    <message>
        <source>Error: %1</source>
        <translation type="unfinished">កំហុស៖%1</translation>
    </message>
    <message>
        <source>Warning: %1</source>
        <translation type="unfinished">ប្រុងប្រយ័ត្នៈ %1</translation>
    </message>
    <message>
        <source>Date: %1
</source>
        <translation type="unfinished">ថ្ងៃ៖%1
</translation>
    </message>
    <message>
        <source>Amount: %1
</source>
        <translation type="unfinished">ចំនួន៖%1
</translation>
    </message>
    <message>
        <source>Wallet: %1
</source>
        <translation type="unfinished">កាបូប៖%1
</translation>
    </message>
    <message>
        <source>Type: %1
</source>
        <translation type="unfinished">ប្រភេទ៖%1
</translation>
    </message>
    <message>
        <source>Label: %1
</source>
        <translation type="unfinished">ស្លាក៖%1
</translation>
    </message>
    <message>
        <source>Address: %1
</source>
        <translation type="unfinished">អាសយដ្ឋាន៖%1
</translation>
    </message>
    <message>
        <source>Sent transaction</source>
        <translation type="unfinished">បានបញ្ចូនប្រត្តិបត្តិការ</translation>
    </message>
    <message>
        <source>Incoming transaction</source>
        <translation type="unfinished">ប្រត្តិបត្តិការកំពុងមកដល់</translation>
    </message>
    <message>
        <source>HD key generation is &lt;b&gt;enabled&lt;/b&gt;</source>
        <translation type="unfinished">លេខសម្ងាត់ HD គឺ&lt;b&gt;ត្រូវបាន​បើក&lt;/b&gt;</translation>
    </message>
    <message>
        <source>HD key generation is &lt;b&gt;disabled&lt;/b&gt;</source>
        <translation type="unfinished">លេខសម្ងាត់ HD គឺ&lt;b&gt;ត្រូវបានបិទ&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Private key &lt;b&gt;disabled&lt;/b&gt;</source>
        <translation type="unfinished">លេខសម្ងាត់ &lt;b&gt;ត្រូវបានបិទ&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation type="unfinished">កាបូបអេឡិចត្រូនិចគឺ&lt;b&gt;ត្រូវបានបំលែងជាកូដ&lt;/b&gt;និងបច្ចុប្បន្ន&lt;b&gt;ត្រូវបានចាក់សោរ&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation type="unfinished">កាបូបអេឡិចត្រនិច&lt;b&gt;ត្រូវបានបំលែងជាកូដ&lt;/b&gt;និងបច្ចុប្បន្ន&lt;b&gt;ត្រូវបានចាក់សោរ&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Original message:</source>
        <translation type="unfinished">សារដើម៖</translation>
    </message>
</context>
<context>
    <name>UnitDisplayStatusBarControl</name>
    <message>
        <source>Unit to show amounts in. Click to select another unit.</source>
        <translation type="unfinished">ឯកតា​ដើម្បី​បង្ហាញ​ចំនួន​ចូល។ ចុច​ដើម្បី​ជ្រើសរើស​ឯកតា​ផ្សេងទៀត។</translation>
    </message>
</context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Coin Selection</source>
        <translation type="unfinished">ជ្រើសកាក់</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation type="unfinished">បរិមាណ៖</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation type="unfinished">Bytes៖</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation type="unfinished">ចំនួនទឹកប្រាក់៖</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation type="unfinished">តម្លៃសេវា៖</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation type="unfinished">ធូលី៖</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation type="unfinished">បន្ទាប់ពីតម្លៃសេវា៖</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation type="unfinished">ប្តូរ៖</translation>
    </message>
    <message>
        <source>(un)select all</source>
        <translation type="unfinished">(កុំ)ជ្រើសរើសទាំងអស់</translation>
    </message>
    <message>
        <source>Tree mode</source>
        <translation type="unfinished">ម៉ូតដើមឈើ</translation>
    </message>
    <message>
        <source>List mode</source>
        <translation type="unfinished">ម៉ូតបញ្ជី</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">ចំនួន</translation>
    </message>
    <message>
        <source>Received with label</source>
        <translation type="unfinished">បានទទួលជាមួយនឹងស្លាកសញ្ញា</translation>
    </message>
    <message>
        <source>Received with address</source>
        <translation type="unfinished">បានទទួលជាមួយនឹងអាសយដ្ឋាន</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished">កាលបរិច្ឆេទ</translation>
    </message>
    <message>
        <source>Confirmations</source>
        <translation type="unfinished">ការបញ្ជាក់</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation type="unfinished">បានបញ្ជាក់</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation type="unfinished">ចម្លងចំនួនទឹកប្រាក់</translation>
    </message>
    <message>
        <source>&amp;Copy address</source>
        <translation type="unfinished">ចម្លងអាសយដ្ឋាន(&amp;C)</translation>
    </message>
    <message>
        <source>Copy &amp;label</source>
        <translation type="unfinished">ចម្លង &amp; ស្លាក</translation>
    </message>
    <message>
        <source>Copy &amp;amount</source>
        <translation type="unfinished">ចម្លង &amp; ចំនួនទឹកប្រាក់</translation>
    </message>
    <message>
        <source>Copy transaction &amp;ID and output index</source>
        <translation type="unfinished">ចម្លងប្រតិបត្តិការ &amp; លេខសម្គាល់ និងសន្ទស្សន៍ទិន្នផល</translation>
    </message>
    <message>
        <source>L&amp;ock unspent</source>
        <translation type="unfinished">L&amp;ock មិនបានចំណាយ</translation>
    </message>
    <message>
        <source>&amp;Unlock unspent</source>
        <translation type="unfinished">&amp;ដោះសោដោយមិនបានចំណាយ</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation type="unfinished">ចម្លងបរិមាណ</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation type="unfinished">ចម្លងតម្លៃ</translation>
    </message>
    <message>
        <source>Copy dust</source>
        <translation type="unfinished">ចម្លងធូលី</translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation type="unfinished">ចម្លងការផ្លាស់ប្តូរ</translation>
    </message>
    <message>
        <source>(%1 locked)</source>
        <translation type="unfinished">(%1បានចាក់សោរ)</translation>
    </message>
    <message>
        <source>yes</source>
        <translation type="unfinished">បាទ ឬ ចាស</translation>
    </message>
    <message>
        <source>no</source>
        <translation type="unfinished">ទេ</translation>
    </message>
    <message>
        <source>This label turns red if any recipient receives an amount smaller than the current dust threshold.</source>
        <translation type="unfinished">ស្លាកសញ្ញានេះបង្ហាញពណ៌ក្រហម ប្រសិនបើអ្នកទទួល ទទួលបានចំនួនមួយតិចជាងចំនួនចាប់ផ្តើមបច្ចុប្បន្ន។</translation>
    </message>
    <message>
        <source>Can vary +/- %1 satoshi(s) per input.</source>
        <translation type="unfinished">អាច +/- %1 satoshi(s)ច្រើនក្នុងការបញ្ជូលមួយ។</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(គ្មាន​ស្លាក​)</translation>
    </message>
    <message>
        <source>change from %1 (%2)</source>
        <translation type="unfinished">ប្តូរពី %1 (%2)</translation>
    </message>
    <message>
        <source>(change)</source>
        <translation type="unfinished">(ផ្លាស់ប្តូរ)</translation>
    </message>
</context>
<context>
    <name>CreateWalletActivity</name>
    <message>
        <source>Create Wallet</source>
        <extracomment>Title of window indicating the progress of creation of a new wallet.</extracomment>
        <translation type="unfinished">បង្កើតកាបូប</translation>
    </message>
    <message>
        <source>Creating Wallet &lt;b&gt;%1&lt;/b&gt;…</source>
        <extracomment>Descriptive text of the create wallet progress window which indicates to the user which wallet is currently being created.</extracomment>
        <translation type="unfinished">ការបង្កើតកាបូប&lt;b&gt;%1&lt;/b&gt;...</translation>
    </message>
    <message>
        <source>Create wallet failed</source>
        <translation type="unfinished">បង្កើតកាបូបអេឡិចត្រូនិច មិនជោគជ័យ</translation>
    </message>
    <message>
        <source>Create wallet warning</source>
        <translation type="unfinished">ការព្រមានបង្កើតកាបូប</translation>
    </message>
    <message>
        <source>Can't list signers</source>
        <translation type="unfinished">មិនអាចចុះបញ្ជីអ្នកចុះហត្ថលេខាបានទេ។</translation>
    </message>
    <message>
        <source>Too many external signers found</source>
        <translation type="unfinished">បានរកឃើញអ្នកចុះហត្ថលេខាខាងក្រៅច្រើនពេក</translation>
    </message>
</context>
<context>
    <name>LoadWalletsActivity</name>
    <message>
        <source>Load Wallets</source>
        <extracomment>Title of progress window which is displayed when wallets are being loaded.</extracomment>
        <translation type="unfinished">ទាញកាបូប</translation>
    </message>
    <message>
        <source>Loading wallets…</source>
        <extracomment>Descriptive text of the load wallets progress window which indicates to the user that wallets are currently being loaded.</extracomment>
        <translation type="unfinished">កំពុងទាញកាបូប...</translation>
    </message>
</context>
<context>
    <name>OpenWalletActivity</name>
    <message>
        <source>Open wallet failed</source>
        <translation type="unfinished">បើកកាបូបអេឡិចត្រូនិច មិនជៅគជ័យ</translation>
    </message>
    <message>
        <source>Open wallet warning</source>
        <translation type="unfinished">ក្រើនរំលឹកឲ្យប្រយ័ត្នក្នុងការបើកកាបូបអេឡិចត្រូនិច</translation>
    </message>
    <message>
        <source>Open Wallet</source>
        <extracomment>Title of window indicating the progress of opening of a wallet.</extracomment>
        <translation type="unfinished">បើកកាបូបអេឡិចត្រូនិច</translation>
    </message>
    <message>
        <source>Opening Wallet &lt;b&gt;%1&lt;/b&gt;…</source>
        <extracomment>Descriptive text of the open wallet progress window which indicates to the user which wallet is currently being opened.</extracomment>
        <translation type="unfinished">កាបូបការបើកកាបូប&lt;b&gt;%1&lt;/b&gt;...</translation>
    </message>
</context>
<context>
    <name>RestoreWalletActivity</name>
    <message>
        <source>Restore Wallet</source>
        <extracomment>Title of progress window which is displayed when wallets are being restored.</extracomment>
        <translation type="unfinished">ស្តារកាបូប</translation>
    </message>
    <message>
        <source>Restoring Wallet &lt;b&gt;%1&lt;/b&gt;…</source>
        <extracomment>Descriptive text of the restore wallets progress window which indicates to the user that wallets are currently being restored.</extracomment>
        <translation type="unfinished">កំពុងស្ដារកាបូប&lt;b&gt;%1&lt;/b&gt;…</translation>
    </message>
    <message>
        <source>Restore wallet failed</source>
        <extracomment>Title of message box which is displayed when the wallet could not be restored.</extracomment>
        <translation type="unfinished">ការស្តារកាបូបបានបរាជ័យ</translation>
    </message>
    <message>
        <source>Restore wallet warning</source>
        <extracomment>Title of message box which is displayed when the wallet is restored with some warning.</extracomment>
        <translation type="unfinished">ការព្រមានស្តារកាបូប</translation>
    </message>
    <message>
        <source>Restore wallet message</source>
        <extracomment>Title of message box which is displayed when the wallet is successfully restored.</extracomment>
        <translation type="unfinished">សារស្ដារកាបូប</translation>
    </message>
</context>
<context>
    <name>WalletController</name>
    <message>
        <source>Close wallet</source>
        <translation type="unfinished">បិតកាបូបអេឡិចត្រូនិច</translation>
    </message>
    <message>
        <source>Close all wallets</source>
        <translation type="unfinished">បិទកាបូបអេឡិចត្រូនិចទាំងអស់</translation>
    </message>
    <message>
        <source>Are you sure you wish to close all wallets?</source>
        <translation type="unfinished">តើអ្នកច្បាស់ថាអ្នកចង់បិទកាបូបអេឡិចត្រូនិចទាំងអស់?</translation>
    </message>
</context>
<context>
    <name>CreateWalletDialog</name>
    <message>
        <source>Create Wallet</source>
        <translation type="unfinished">បង្កើតកាបូប</translation>
    </message>
    <message>
        <source>Wallet Name</source>
        <translation type="unfinished">ឈ្មោះកាបូប</translation>
    </message>
    <message>
        <source>Wallet</source>
        <translation type="unfinished">កាបូប</translation>
    </message>
    <message>
        <source>Encrypt the wallet. The wallet will be encrypted with a passphrase of your choice.</source>
        <translation type="unfinished">បំលែងកាបូបអេឡិចត្រូនិចជាកូដ។ កាបំលែងនេះ រួមជាមួយនឹងឃ្លាសម្ងាត់ដែលអ្នកអាចជ្រើសរើសបាន។</translation>
    </message>
    <message>
        <source>Encrypt Wallet</source>
        <translation type="unfinished">បំលែងកាបូបអេឡិចត្រនិចទៅជាកូដ</translation>
    </message>
    <message>
        <source>Advanced Options</source>
        <translation type="unfinished">ជម្រើសមានមុខងារច្រើន</translation>
    </message>
    <message>
        <source>Make Blank Wallet</source>
        <translation type="unfinished">ធ្វើឲ្យកាបូបអេឡិចត្រូនិចទទេ</translation>
    </message>
    <message>
        <source>Use an external signing device such as a hardware wallet. Configure the external signer script in wallet preferences first.</source>
        <translation type="unfinished">ប្រើឧបករណ៍ចុះហត្ថលេខាខាងក្រៅ ដូចជាកាបូបផ្នែករឹង។ កំណត់រចនាសម្ព័ន្ធស្គ្រីបអ្នកចុះហត្ថលេខាខាងក្រៅនៅក្នុងចំណូលចិត្តកាបូបជាមុនសិន។</translation>
    </message>
    <message>
        <source>External signer</source>
        <translation type="unfinished">អ្នកចុះហត្ថលេខាខាងក្រៅ</translation>
    </message>
    <message>
        <source>Create</source>
        <translation type="unfinished">បង្កើត</translation>
    </message>
    <message>
        <source>Compiled without external signing support (required for external signing)</source>
        <extracomment>"External signing" means using devices such as hardware wallets.</extracomment>
        <translation type="unfinished">ចងក្រងដោយមិនមានការគាំទ្រការចុះហត្ថលេខាខាងក្រៅ (ទាមទារសម្រាប់ការចុះហត្ថលេខាខាងក្រៅ)</translation>
    </message>
</context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation type="unfinished">កែសម្រួលអាសយដ្ឋាន</translation>
    </message>
    <message>
        <source>&amp;Label</source>
        <translation type="unfinished">&amp;ស្លាកសញ្ញា</translation>
    </message>
    <message>
        <source>The label associated with this address list entry</source>
        <translation type="unfinished">ស្លាកសញ្ញានេះជាប់ទាក់ទងទៅនឹងការបញ្ចូលបញ្ចីរអាសយដ្ឋាន</translation>
    </message>
    <message>
        <source>&amp;Address</source>
        <translation type="unfinished">&amp;អាសយដ្ឋានបញ្ចូនថ្មី</translation>
    </message>
    <message>
        <source>New sending address</source>
        <translation type="unfinished">អាសយដ្ឋានបញ្ចូនថ្មី</translation>
    </message>
    <message>
        <source>Edit receiving address</source>
        <translation type="unfinished">កែប្រែអាសយដ្ឋានទទួល</translation>
    </message>
    <message>
        <source>Edit sending address</source>
        <translation type="unfinished">កែប្រែអាសយដ្ឋានបញ្ចូន</translation>
    </message>
    <message>
        <source>Could not unlock wallet.</source>
        <translation type="unfinished">មិនអាចបើកសោរ កាបូបអេឡិចត្រូនិចបាន។</translation>
    </message>
    <message>
        <source>New key generation failed.</source>
        <translation type="unfinished">បង្កើតលេខសំម្ងាត់ថ្មីមិនជោគជ័យ។</translation>
    </message>
</context>
<context>
    <name>FreespaceChecker</name>
    <message>
        <source>A new data directory will be created.</source>
        <translation type="unfinished">ទីតាំងផ្ទុកទិន្នន័យថ្មីមួយនឹងត្រូវបានបង្កើត។</translation>
    </message>
    <message>
        <source>name</source>
        <translation type="unfinished">ឈ្មោះ</translation>
    </message>
    <message>
        <source>Path already exists, and is not a directory.</source>
        <translation type="unfinished">ផ្លូវទៅកាន់ទិន្នន័យមានរួចរាល់​ និង​ មិនមែនជាទីតាំង។</translation>
    </message>
    <message>
        <source>Cannot create data directory here.</source>
        <translation type="unfinished">មិនអាចបង្កើតទីតាំងផ្ទុកទិន្នន័យនៅទីនេះ។</translation>
    </message>
</context>
<context>
    <name>Intro</name>
    <message>
        <source>Kawra</source>
        <translation type="unfinished">ប៊ីតខញ</translation>
    </message>
    <message numerus="yes">
        <source>%n GB of space available</source>
        <translation type="unfinished">
            <numerusform>%nGB នៃកន្លែងទំនេរ</numerusform>
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>(of %n GB needed)</source>
        <translation type="unfinished">
            <numerusform>(នៃ%n GB ដែលត្រូវការ)</numerusform>
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>(%n GB needed for full chain)</source>
        <translation type="unfinished">
            <numerusform>(%n GB ត្រូវការសម្រាប់ខ្សែសង្វាក់ពេញលេញ)</numerusform>
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>(sufficient to restore backups %n day(s) old)</source>
        <extracomment>Explanatory text on the capability of the current prune target.</extracomment>
        <translation type="unfinished">
            <numerusform>(គ្រប់គ្រាន់ដើម្បីស្ដារការបម្រុងទុក%nថ្ងៃចាស់)</numerusform>
            <numerusform />
        </translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">បញ្ហា</translation>
    </message>
    <message>
        <source>Welcome</source>
        <translation type="unfinished">សូមស្វាគមន៏</translation>
    </message>
    <message>
        <source>Limit block chain storage to</source>
        <translation type="unfinished">កំណត់ការផ្ទុកខ្សែសង្វាក់ប្លុកទៅ</translation>
    </message>
    <message>
        <source> GB</source>
        <translation type="unfinished">GB</translation>
    </message>
    <message>
        <source>When you click OK, %1 will begin to download and process the full %4 block chain (%2 GB) starting with the earliest transactions in %3 when %4 initially launched.</source>
        <translation type="unfinished">នៅពេលអ្នកចុចយល់ព្រម %1វានឹងចាប់ផ្តើមទាញយក និងដំណើរការខ្សែសង្វាក់ប្លុក%4ពេញលេញ (%2GB) ដោយចាប់ផ្តើមជាមួយនឹងប្រតិបត្តិការដំបូងបំផុតនៅ%3ពេល%4ចាប់ផ្តើមដំបូង។</translation>
    </message>
    <message>
        <source>Use the default data directory</source>
        <translation type="unfinished">ប្រើទីតាំងផ្ទុកទិន្នន័យដែលបានកំណត់រួច</translation>
    </message>
    <message>
        <source>Use a custom data directory:</source>
        <translation type="unfinished">ប្រើទីតាំងផ្ទុកទិន្នន័យ ដែលមានការជ្រើសរើសមួយៈ</translation>
    </message>
</context>
<context>
    <name>HelpMessageDialog</name>
    <message>
        <source>version</source>
        <translation type="unfinished">ជំនាន់</translation>
    </message>
    </context>
<context>
    <name>ShutdownWindow</name>
    <message>
        <source>%1 is shutting down…</source>
        <translation type="unfinished">%1 កំពុងបិទ...</translation>
    </message>
    <message>
        <source>Do not shut down the computer until this window disappears.</source>
        <translation type="unfinished">សូមកុំទាន់បិទកុំព្យូទ័រនេះ រហូលទាល់តែវិនដូរនេះលុបបាត់។</translation>
    </message>
</context>
<context>
    <name>ModalOverlay</name>
    <message>
        <source>Form</source>
        <translation type="unfinished">ទម្រង់</translation>
    </message>
    <message>
        <source>Recent transactions may not yet be visible, and therefore your wallet's balance might be incorrect. This information will be correct once your wallet has finished synchronizing with the kawra network, as detailed below.</source>
        <translation type="unfinished">ប្រត្តិបត្តិការថ្មីៗនេះប្រហែលជាមិនអាចមើលឃើញ ហេតុដូច្នេះសមតុល្យនៅក្នងកាបូបអេឡិចត្រូនិចរបស់អ្នកប្រហែលជាមិនត្រឹមត្រូវ។ ព័ត៌មានត្រឹមត្រូវនៅពេលដែលកាបូបអេឡិចត្រូនិចរបស់អ្នកបានធ្វើសមកាលកម្មជាមួយបណ្តាញប៊ឺតខញ  សូមពិនិត្យព័ត៌មានលំម្អិតខាងក្រោម។</translation>
    </message>
    <message>
        <source>Attempting to spend kawras that are affected by not-yet-displayed transactions will not be accepted by the network.</source>
        <translation type="unfinished">ព្យាយាមក្នុងការចំណាយប៊ីតខញដែលទទួលរងឥទ្ឋិពលពីប្រត្តិបត្តិការមិនទាន់ធ្វើការបង្ហាញ នឹងមិនត្រូវទទួលស្គាល់ពីបណ្តាញ។</translation>
    </message>
    <message>
        <source>Number of blocks left</source>
        <translation type="unfinished">ចំនួនប្លុកដែលនៅសល់</translation>
    </message>
    <message>
        <source>Unknown…</source>
        <translation type="unfinished">មិនស្គាល់…</translation>
    </message>
    <message>
        <source>calculating…</source>
        <translation type="unfinished">កំពុងគណនា…</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation type="unfinished">ពេវេលាប្លុកជុងក្រោយ</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation type="unfinished">កំពុងដំណើរការ</translation>
    </message>
    <message>
        <source>Progress increase per hour</source>
        <translation type="unfinished">ដំណើរការកើនឡើងក្នុងមួយម៉ោង</translation>
    </message>
    <message>
        <source>Estimated time left until synced</source>
        <translation type="unfinished">ពេលវេលាដែលរំពឹងទុកនៅសល់រហូតដល់បានធ្វើសមកាលកម្ម</translation>
    </message>
    <message>
        <source>Hide</source>
        <translation type="unfinished">លាក់</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation type="unfinished">ចាកចេញ</translation>
    </message>
    <message>
        <source>Unknown. Syncing Headers (%1, %2%)…</source>
        <translation type="unfinished">មិនស្គាល់។ Syncing Headers (%1, %2%)…</translation>
    </message>
    <message>
        <source>Unknown. Pre-syncing Headers (%1, %2%)…</source>
        <translation type="unfinished">មិនស្គាល់។ Pre-syncing Headers (%1, %2%)…</translation>
    </message>
</context>
<context>
    <name>OpenURIDialog</name>
    <message>
        <source>Open kawra URI</source>
        <translation type="unfinished">បើកប៊ីតខញ​URl</translation>
    </message>
    <message>
        <source>URI:</source>
        <translation type="unfinished">URl:</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <extracomment>Tooltip text for button that allows you to paste an address that is in your clipboard.</extracomment>
        <translation type="unfinished">ថតចម្លងអាសយដ្ឋាណពីក្ដារតម្រៀប</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation type="unfinished">ជម្រើស</translation>
    </message>
    <message>
        <source>&amp;Main</source>
        <translation type="unfinished">&amp;សំខាន់</translation>
    </message>
    <message>
        <source>Automatically start %1 after logging in to the system.</source>
        <translation type="unfinished">ចាប់ផ្តើម %1 ដោយស្វ័យប្រវត្តិបន្ទាប់ពីបានចូលក្នុងប្រព័ន្ធ។</translation>
    </message>
    <message>
        <source>&amp;Start %1 on system login</source>
        <translation type="unfinished">ចាប់ផ្តើម %1 ទៅលើការចូលប្រព័ន្ធ(&amp;S)</translation>
    </message>
    <message>
        <source>Enabling pruning significantly reduces the disk space required to store transactions. All blocks are still fully validated. Reverting this setting requires re-downloading the entire blockchain.</source>
        <translation type="unfinished">ការបើកដំណើរការកាត់ចេញយ៉ាងសំខាន់កាត់បន្ថយទំហំថាសដែលត្រូវការដើម្បីរក្សាទុកប្រតិបត្តិការ។ ប្លុកទាំងអស់នៅតែផ្ទៀងផ្ទាត់ពេញលេញ។ ការត្រឡប់ការកំណត់នេះទាមទារការទាញយក blockchain ទាំងស្រុងឡើងវិញ។</translation>
    </message>
    <message>
        <source>Size of &amp;database cache</source>
        <translation type="unfinished">ទំហំ​&amp;ឃ្លាំង​ផ្ទុក​ទិន្នន័យ</translation>
    </message>
    <message>
        <source>Number of script &amp;verification threads</source>
        <translation type="unfinished">ចំនួនscript &amp; threadsផ្ទៀងផ្ទាត់</translation>
    </message>
    <message>
        <source>Full path to a %1 compatible script (e.g. C:\Downloads\hwi.exe or /Users/you/Downloads/hwi.py). Beware: malware can steal your coins!</source>
        <translation type="unfinished">ផ្លូវពេញទៅកាន់%1ស្គ្រីបដែលត្រូវគ្នា (ឧ. C:\Downloads\hwi.exe ឬ /Users/you/Downloads/hwi.py)។ ប្រយ័ត្ន៖ មេរោគអាចលួចកាក់របស់អ្នក!</translation>
    </message>
    <message>
        <source>Options set in this dialog are overridden by the command line:</source>
        <translation type="unfinished">ជម្រើសដែលបានកំណត់ក្នុងប្រអប់នេះត្រូវបានបដិសេធដោយពាក្យបញ្ជា៖</translation>
    </message>
    <message>
        <source>&amp;Reset Options</source>
        <translation type="unfinished">&amp;ជម្រើសការកែសម្រួលឡើងវិញ</translation>
    </message>
    <message>
        <source>GB</source>
        <translation type="unfinished">ជីហ្គាប៊ៃ </translation>
    </message>
    <message>
        <source>Maximum database cache size. A larger cache can contribute to faster sync, after which the benefit is less pronounced for most use cases. Lowering the cache size will reduce memory usage. Unused mempool memory is shared for this cache.</source>
        <extracomment>Tooltip text for Options window setting that sets the size of the database cache. Explains the corresponding effects of increasing/decreasing this value.</extracomment>
        <translation type="unfinished">ទំហំឃ្លាំងទិន្នន័យអតិបរមា។ ឃ្លាំងសម្ងាត់ធំជាងអាចរួមចំណែកដល់ការធ្វើសមកាលកម្មលឿនជាងមុន បន្ទាប់ពីនោះអត្ថប្រយោជន៍គឺមិនសូវច្បាស់សម្រាប់ករណីប្រើប្រាស់ភាគច្រើន។ ការបន្ថយទំហំឃ្លាំងសម្ងាត់នឹងកាត់បន្ថយការប្រើប្រាស់អង្គចងចាំ។ អង្គចងចាំ mempool ដែលមិនប្រើត្រូវបានចែករំលែកសម្រាប់ឃ្លាំងសម្ងាត់នេះ។</translation>
    </message>
    <message>
        <source>Set the number of script verification threads. Negative values correspond to the number of cores you want to leave free to the system.</source>
        <extracomment>Tooltip text for Options window setting that sets the number of script verification threads. Explains that negative values mean to leave these many cores free to the system.</extracomment>
        <translation type="unfinished">កំណត់ចំនួនខ្សែស្រឡាយផ្ទៀងផ្ទាត់script ។ តម្លៃអវិជ្ជមានត្រូវគ្នាទៅនឹងចំនួនស្នូលដែលអ្នកចង់ចាកចេញពីប្រព័ន្ធដោយឥតគិតថ្លៃ។</translation>
    </message>
    <message>
        <source>This allows you or a third party tool to communicate with the node through command-line and JSON-RPC commands.</source>
        <extracomment>Tooltip text for Options window setting that enables the RPC server.</extracomment>
        <translation type="unfinished">នេះអនុញ្ញាតឱ្យអ្នក ឬឧបករណ៍ភាគីទីបីទាក់ទងជាមួយណូដតាមរយៈបន្ទាត់ពាក្យបញ្ជា និងពាក្យបញ្ជា JSON-RPC ។</translation>
    </message>
    <message>
        <source>Enable R&amp;PC server</source>
        <extracomment>An Options window setting to enable the RPC server.</extracomment>
        <translation type="unfinished">បើកម៉ាស៊ីនមេ R&amp;PC</translation>
    </message>
    <message>
        <source>W&amp;allet</source>
        <translation type="unfinished">កា&amp;បូបអេឡិចត្រូនិច</translation>
    </message>
    <message>
        <source>Whether to set subtract fee from amount as default or not.</source>
        <extracomment>Tooltip text for Options window setting that sets subtracting the fee from a sending amount as default.</extracomment>
        <translation type="unfinished">ថាតើត្រូវកំណត់ថ្លៃដកពីចំនួនទឹកប្រាក់តាមលំនាំដើមឬអត់។</translation>
    </message>
    <message>
        <source>Subtract &amp;fee from amount by default</source>
        <extracomment>An Options window setting to set subtracting the fee from a sending amount as default.</extracomment>
        <translation type="unfinished">ដក &amp; ថ្លៃសេវាពីចំនួនតាមលំនាំដើម</translation>
    </message>
    <message>
        <source>Expert</source>
        <translation type="unfinished">អ្នកជំនាញ</translation>
    </message>
    <message>
        <source>Enable &amp;PSBT controls</source>
        <extracomment>An options window setting to enable PSBT controls.</extracomment>
        <translation type="unfinished">បើកដំណើរការការត្រួតពិនិត្យ PSBT</translation>
    </message>
    <message>
        <source>Whether to show PSBT controls.</source>
        <extracomment>Tooltip text for options window setting that enables PSBT controls.</extracomment>
        <translation type="unfinished">ថាតើត្រូវបង្ហាញការគ្រប់គ្រង PSBT ។</translation>
    </message>
    <message>
        <source>External Signer (e.g. hardware wallet)</source>
        <translation type="unfinished">អ្នកចុះហត្ថលេខាខាងក្រៅ (ឧ. កាបូបផ្នែករឹង)</translation>
    </message>
    <message>
        <source>&amp;External signer script path</source>
        <translation type="unfinished">(&amp;E)script អ្នកចុះហត្ថលេខាខាងក្រៅ</translation>
    </message>
    <message>
        <source>Automatically open the Kawra client port on the router. This only works when your router supports NAT-PMP and it is enabled. The external port could be random.</source>
        <translation type="unfinished">បើកច្រកម៉ាស៊ីនភ្ញៀវ Kawra ដោយស្វ័យប្រវត្តិនៅលើរ៉ោតទ័រ។ វាដំណើរការតែនៅពេលដែលរ៉ោតទ័ររបស់អ្នកគាំទ្រ NAT-PMP ហើយវាត្រូវបានបើក។ ច្រកខាងក្រៅអាចជាចៃដន្យ។</translation>
    </message>
    <message>
        <source>Accept connections from outside.</source>
        <translation type="unfinished">ទទួលការតភ្ជាប់ពីខាងក្រៅ។</translation>
    </message>
    <message>
        <source>Allow incomin&amp;g connections</source>
        <translation type="unfinished">អនុញ្ញាតឲ្យមានការតភ្ជាប់ដែលចូលមក</translation>
    </message>
    <message>
        <source>Connect to the Kawra network through a SOCKS5 proxy.</source>
        <translation type="unfinished">ភ្ជាប់ទៅកាន់បណ្តាញប៊ឺតខញតាមរយៈ​ SOCKS5 proxy។</translation>
    </message>
    <message>
        <source>&amp;Port:</source>
        <translation type="unfinished">&amp;រុនដោត</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation type="unfinished">វិនដូ(&amp;W)</translation>
    </message>
    <message>
        <source>&amp;Display</source>
        <translation type="unfinished">&amp;បង្ហាញ</translation>
    </message>
    <message>
        <source>Third-party URLs (e.g. a block explorer) that appear in the transactions tab as context menu items. %s in the URL is replaced by transaction hash. Multiple URLs are separated by vertical bar |.</source>
        <translation type="unfinished">URL ភាគីទីបី (ឧ. ប្លុករុករក) ដែលបង្ហាញក្នុងផ្ទាំងប្រតិបត្តិការជាធាតុម៉ឺនុយបរិបទ។ %sនៅក្នុង URL ត្រូវបានជំនួសដោយhashប្រតិបត្តិការ។ URLs ច្រើនត្រូវបានបំបែកដោយរបារបញ្ឈរ |។</translation>
    </message>
    <message>
        <source>&amp;Third-party transaction URLs</source>
        <translation type="unfinished">URLs ប្រតិបត្តិការភាគីទីបី(&amp;T)</translation>
    </message>
    <message>
        <source>Compiled without external signing support (required for external signing)</source>
        <extracomment>"External signing" means using devices such as hardware wallets.</extracomment>
        <translation type="unfinished">ចងក្រងដោយមិនមានការគាំទ្រការចុះហត្ថលេខាខាងក្រៅ (ទាមទារសម្រាប់ការចុះហត្ថលេខាខាងក្រៅ)</translation>
    </message>
    <message>
        <source>Confirm options reset</source>
        <extracomment>Window title text of pop-up window shown when the user has chosen to reset options.</extracomment>
        <translation type="unfinished">បញ្ចាក់ជម្រើសការកែសម្រួលឡើងវិញ</translation>
    </message>
    <message>
        <source>Client will be shut down. Do you want to proceed?</source>
        <extracomment>Text asking the user to confirm if they would like to proceed with a client shutdown.</extracomment>
        <translation type="unfinished">ផ្ទាំងអតិថិជននិងត្រូវបិទ។ តើអ្នកចង់បន្តទៀតឫទេ?</translation>
    </message>
    <message>
        <source>Configuration options</source>
        <extracomment>Window title text of pop-up box that allows opening up of configuration file.</extracomment>
        <translation type="unfinished">ជម្រើសក្នុងការរៀបចំរចនាសម្ព័ន្ធ</translation>
    </message>
    <message>
        <source>The configuration file is used to specify advanced user options which override GUI settings. Additionally, any command-line options will override this configuration file.</source>
        <extracomment>Explanatory text about the priority order of instructions considered by client. The order from high to low being: command-line, configuration file, GUI settings.</extracomment>
        <translation type="unfinished">ការរៀបចំរចនាសម្ពន្ធ័ឯកសារ ត្រូវបានប្រើសម្រាប់អ្នកដែលមានបទពិសោធន៏ ក្នុងរៀបចំកែប្រែផ្នែកក្រាហ្វិកខាងមុននៃសុសវែ។ បន្ថែ​មលើនេះទៀត  កាសរសេរបន្ថែមកូដ វានឹងធ្វើឲ្យមានការកែប្រែឯការសារនេះ។</translation>
    </message>
    <message>
        <source>Continue</source>
        <translation type="unfinished">បន្ត</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished">ចាកចេញ</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">បញ្ហា</translation>
    </message>
    <message>
        <source>This change would require a client restart.</source>
        <translation type="unfinished">ការផ្លាស់ប្តូរនេះនឹងត្រូវការចាប់ផ្តើមម៉ាស៊ីនកុំព្យូទ័រឡើងវិញ។​</translation>
    </message>
    </context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Form</source>
        <translation type="unfinished">ទម្រង់</translation>
    </message>
    <message>
        <source>The displayed information may be out of date. Your wallet automatically synchronizes with the Kawra network after a connection is established, but this process has not completed yet.</source>
        <translation type="unfinished">ព័ត៏មានបានបង្ហាញអាចហួសសពុលភាព។ កាបូបអេឡិចត្រូនិចរបស់អ្នកធ្វើសមកាលកម្មជាមួយនឹងបណ្តាញប៊ីតខញដោយស្វ័យប្រវត្ត បន្ទាប់ពីមានការតភ្ជាប់ ប៉ុន្តែដំណើរការនេះមិនទាន់បានបញ្ចប់នៅឡើយ។</translation>
    </message>
    <message>
        <source>Watch-only:</source>
        <translation type="unfinished">សម្រាប់តែមើលៈ</translation>
    </message>
    <message>
        <source>Available:</source>
        <translation type="unfinished">មានៈ</translation>
    </message>
    <message>
        <source>Your current spendable balance</source>
        <translation type="unfinished">សមតុល្យបច្ចុប្បន្នដែលអាចចាយបាន</translation>
    </message>
    <message>
        <source>Pending:</source>
        <translation type="unfinished">រងចាំៈ</translation>
    </message>
    <message>
        <source>Total of transactions that have yet to be confirmed, and do not yet count toward the spendable balance</source>
        <translation type="unfinished">សរុបប្រត្តឹបត្តិការដែលមិនទាន់បានបញ្ចាក់ និង រាប់ចំពោះសមតុល្យដែលមានទឹកប្រាក់សម្រាប់សំណាយ</translation>
    </message>
    <message>
        <source>Immature:</source>
        <translation type="unfinished">មិនទាន់មានលក្ខណៈគ្រប់គ្រាន់ៈ</translation>
    </message>
    <message>
        <source>Mined balance that has not yet matured</source>
        <translation type="unfinished">សមតុល្យរ៉ែដែលបានជីកមិនទាន់មានលក្ខណៈគ្រប់គ្រាន់</translation>
    </message>
    <message>
        <source>Balances</source>
        <translation type="unfinished">សមតុល្យច្រើន</translation>
    </message>
    <message>
        <source>Total:</source>
        <translation type="unfinished">សរុប</translation>
    </message>
    <message>
        <source>Your current total balance</source>
        <translation type="unfinished">សរុបបច្ចុប្បន្នភាពសមតុល្យរបស់អ្នក</translation>
    </message>
    <message>
        <source>Your current balance in watch-only addresses</source>
        <translation type="unfinished">បច្ចុប្បន្នភាពសមតុល្យរបស់អ្នកនៅក្នុងអាសយដ្ឋានសម្រាប់តែមើល</translation>
    </message>
    <message>
        <source>Spendable:</source>
        <translation type="unfinished">អាចចំណាយបានៈ</translation>
    </message>
    <message>
        <source>Recent transactions</source>
        <translation type="unfinished">ព្រឹត្តិបត្តិការថ្មីៗ</translation>
    </message>
    <message>
        <source>Unconfirmed transactions to watch-only addresses</source>
        <translation type="unfinished">ប្រឹត្តិបត្តិការមិនទាន់បញ្ចាក់ច្បាស់ ទៅកាន់ អាសយដ្ឋានសម្រាប់តែមើល</translation>
    </message>
    </context>
<context>
    <name>PSBTOperationsDialog</name>
    <message>
        <source>Copy to Clipboard</source>
        <translation type="unfinished">ថតចម្លងទៅកាន់ក្ដារតម្រៀប</translation>
    </message>
    <message>
        <source>Save…</source>
        <translation type="unfinished">រក្សាទុក…</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished">បិទ</translation>
    </message>
    <message>
        <source>Cannot sign inputs while wallet is locked.</source>
        <translation type="unfinished">មិនអាចចុះហត្ថលេខាលើធាតុចូលបានទេ ខណៈពេលដែលកាបូបត្រូវបានចាក់សោ។</translation>
    </message>
    <message>
        <source>Could not sign any more inputs.</source>
        <translation type="unfinished">មិនអាចចុះហត្ថលេខាលើធាតុចូលទៀតទេ</translation>
    </message>
    <message>
        <source>Signed %1 inputs, but more signatures are still required.</source>
        <translation type="unfinished">បានចុះហត្ថលេខា%1ធាតុចូល ប៉ុន្តែហត្ថលេខាបន្ថែមទៀតនៅតែត្រូវបានទាមទារ។</translation>
    </message>
    <message>
        <source>Signed transaction successfully. Transaction is ready to broadcast.</source>
        <translation type="unfinished">ប្រត្តិបត្តិការបានចុះហត្ថលេខាដោយជោគជ័យ។​ ប្រត្តិបត្តិការគឺរួចរាល់ក្នុងការផ្សព្វផ្សាយ។</translation>
    </message>
    <message>
        <source>Unknown error processing transaction.</source>
        <translation type="unfinished"> ពុំស្គាល់ប្រត្តិបត្តិការកំពុងដំណើរការជួបបញ្ហា។</translation>
    </message>
    <message>
        <source>PSBT copied to clipboard.</source>
        <translation type="unfinished">PSBT ត្រូវបានថតចម្លងទៅកាន់ក្ដារតម្រៀប។</translation>
    </message>
    <message>
        <source>Save Transaction Data</source>
        <translation type="unfinished">រក្សាទិន្នន័យប្រត្តិបត្តិការ</translation>
    </message>
    <message>
        <source>Partially Signed Transaction (Binary)</source>
        <extracomment>Expanded name of the binary PSBT file format. See: BIP 174.</extracomment>
        <translation type="unfinished">ប្រតិបត្តិការដែលបានចុះហត្ថលេខាដោយផ្នែក (ប្រព័ន្ធគោលពីរ)</translation>
    </message>
    <message>
        <source>PSBT saved to disk.</source>
        <translation type="unfinished">PSBT បានរក្សាទុកក្នុងឌីស។</translation>
    </message>
    <message>
        <source>Unable to calculate transaction fee or total transaction amount.</source>
        <translation type="unfinished">មិនអាចគណនាកម្រៃប្រត្តិបត្តិការ ឬ ចំនួនប្រត្តិបត្តិការសរុប។</translation>
    </message>
    <message>
        <source>Pays transaction fee: </source>
        <translation type="unfinished">បង់កម្រៃប្រត្តិបត្តិការ</translation>
    </message>
    <message>
        <source>Total Amount</source>
        <translation type="unfinished">ចំនួនសរុប</translation>
    </message>
    <message>
        <source>or</source>
        <translation type="unfinished">ឬ</translation>
    </message>
    <message>
        <source>Transaction has %1 unsigned inputs.</source>
        <translation type="unfinished">ប្រត្តិបត្តិការ​មាននៅសល់ %1 នៅពុំទាន់បានហត្ថលេខាធាតុចូល។</translation>
    </message>
    <message>
        <source>Transaction is missing some information about inputs.</source>
        <translation type="unfinished">ប្រត្តិបត្តិការមានព័ត៍មានពុំគ្រប់គ្រាន់អំពីការបញ្ចូល។</translation>
    </message>
    <message>
        <source>Transaction still needs signature(s).</source>
        <translation type="unfinished">ប្រត្តិបត្តិការត្រូវការហត្ថលេខាមួយ (ឬ​ ច្រើន)។</translation>
    </message>
    <message>
        <source>(But no wallet is loaded.)</source>
        <translation type="unfinished">(ប៉ុន្តែគ្មានកាបូបត្រូវបានទាញទេ។ )</translation>
    </message>
    <message>
        <source>(But this wallet cannot sign transactions.)</source>
        <translation type="unfinished">(ប៉ុន្តែកាបូបអេឡិចត្រូនិចនេះមិនអាច ចុះហត្ថលេខាលើប្រត្តិបត្តិការ។)</translation>
    </message>
    <message>
        <source>(But this wallet does not have the right keys.)</source>
        <translation type="unfinished">(ប៉ុន្តែកាបូបអេឡិចត្រូនិចនេះមិនមានលេខសម្ងាត់ត្រឹមត្រូវ)</translation>
    </message>
    <message>
        <source>Transaction is fully signed and ready for broadcast.</source>
        <translation type="unfinished">ប្រត្តិបត្តិការ​បានចុះហត្ថលេខាពេញលេញ និង រួចរាល់សម្រាប់ផ្សព្វផ្សាយជាដំណឹង។</translation>
    </message>
    <message>
        <source>Transaction status is unknown.</source>
        <translation type="unfinished">ស្ថានភាពប្រត្តិបត្តិការមិនត្រូវបានស្គាល់។</translation>
    </message>
</context>
<context>
    <name>PaymentServer</name>
    <message>
        <source>Payment request error</source>
        <translation type="unfinished">ការស្នើរសុំទូរទាត់ប្រាក់ជួបបញ្ហា</translation>
    </message>
    <message>
        <source>Cannot process payment request because BIP70 is not supported.
Due to widespread security flaws in BIP70 it's strongly recommended that any merchant instructions to switch wallets be ignored.
If you are receiving this error you should request the merchant provide a BIP21 compatible URI.</source>
        <translation type="unfinished">មិនអាចដំណើរការសំណើបង់ប្រាក់បានទេព្រោះ BIP70 មិនត្រូវបានគាំទ្រ។
ដោយសារបញ្ហាសុវត្ថិភាពរីករាលដាលនៅក្នុង BIP70 វាត្រូវបានណែនាំយ៉ាងខ្លាំងថាការណែនាំរបស់ពាណិជ្ជករណាមួយដើម្បីប្តូរកាបូបមិនត្រូវបានអើពើ។
ប្រសិនបើអ្នកកំពុងទទួលបានកំហុសនេះ អ្នកគួរតែស្នើសុំពាណិជ្ជករផ្តល់ URI ដែលត្រូវគ្នា BIP21។</translation>
    </message>
    </context>
<context>
    <name>PeerTableModel</name>
    <message>
        <source>Age</source>
        <extracomment>Title of Peers Table column which indicates the duration (length of time) since the peer connection started.</extracomment>
        <translation type="unfinished">អាយុ</translation>
    </message>
    <message>
        <source>Direction</source>
        <extracomment>Title of Peers Table column which indicates the direction the peer connection was initiated from.</extracomment>
        <translation type="unfinished">ទិសដៅ</translation>
    </message>
    <message>
        <source>Sent</source>
        <extracomment>Title of Peers Table column which indicates the total amount of network information we have sent to the peer.</extracomment>
        <translation type="unfinished">បានបញ្ចូន</translation>
    </message>
    <message>
        <source>Received</source>
        <extracomment>Title of Peers Table column which indicates the total amount of network information we have received from the peer.</extracomment>
        <translation type="unfinished">បានទទួល</translation>
    </message>
    <message>
        <source>Address</source>
        <extracomment>Title of Peers Table column which contains the IP/Onion/I2P address of the connected peer.</extracomment>
        <translation type="unfinished">អាសយដ្ឋាន</translation>
    </message>
    <message>
        <source>Type</source>
        <extracomment>Title of Peers Table column which describes the type of peer connection. The "type" describes why the connection exists.</extracomment>
        <translation type="unfinished">ប្រភេទ</translation>
    </message>
    <message>
        <source>Network</source>
        <extracomment>Title of Peers Table column which states the network the peer connected through.</extracomment>
        <translation type="unfinished">បណ្តាញ</translation>
    </message>
    </context>
<context>
    <name>QRImageWidget</name>
    <message>
        <source>&amp;Save Image…</source>
        <translation type="unfinished">រក្សាទុក​រូបភាព(&amp;S)…</translation>
    </message>
    <message>
        <source>&amp;Copy Image</source>
        <translation type="unfinished">&amp;ថតចម្លង រូបភាព</translation>
    </message>
    <message>
        <source>Resulting URI too long, try to reduce the text for label / message.</source>
        <translation type="unfinished">លទ្ធផល URI វែងពែក សូមព្យាយមកាត់បន្ថយអក្សរសម្រាប់ ស្លាកសញ្ញា ឫ សារ។</translation>
    </message>
    <message>
        <source>Error encoding URI into QR Code.</source>
        <translation type="unfinished">បញ្ហាក្នុងការបំលែង​URl ទៅជា QR កូដ។</translation>
    </message>
    <message>
        <source>QR code support not available.</source>
        <translation type="unfinished">ការគាំទ្រ QR កូដមិនមាន។</translation>
    </message>
    <message>
        <source>Save QR Code</source>
        <translation type="unfinished">រក្សាទុក QR កូដ</translation>
    </message>
    <message>
        <source>PNG Image</source>
        <extracomment>Expanded name of the PNG file format. See: https://en.wikipedia.org/wiki/Portable_Network_Graphics.</extracomment>
        <translation type="unfinished">រូបភាព PNG</translation>
    </message>
</context>
<context>
    <name>RPCConsole</name>
    <message>
        <source>&amp;Information</source>
        <translation type="unfinished">ព័ត៍មាន</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="unfinished">ទូទៅ</translation>
    </message>
    <message>
        <source>Startup time</source>
        <translation type="unfinished">ពេលវេលាចាប់ផ្តើម</translation>
    </message>
    <message>
        <source>Network</source>
        <translation type="unfinished">បណ្តាញ</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished">ឈ្មោះ</translation>
    </message>
    <message>
        <source>Number of connections</source>
        <translation type="unfinished">ចំនួនតភ្ជាប់</translation>
    </message>
    <message>
        <source>Current number of transactions</source>
        <translation type="unfinished">បច្ចុប្បន្នភាពចំនួនប្រត្តិបត្តិការ</translation>
    </message>
    <message>
        <source>Memory usage</source>
        <translation type="unfinished">ការប្រើប្រាស់អង្គចងចាំ</translation>
    </message>
    <message>
        <source>Wallet: </source>
        <translation type="unfinished">កាបូបអេឡិចត្រូនិចៈ</translation>
    </message>
    <message>
        <source>(none)</source>
        <translation type="unfinished">(មិនមាន)</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation type="unfinished">&amp;កែសម្រួលឡើងវិញ</translation>
    </message>
    <message>
        <source>Received</source>
        <translation type="unfinished">បានទទួល</translation>
    </message>
    <message>
        <source>Sent</source>
        <translation type="unfinished">បានបញ្ចូន</translation>
    </message>
    <message>
        <source>&amp;Peers</source>
        <translation type="unfinished">&amp;មិត្តភក្រ្ត័</translation>
    </message>
    <message>
        <source>Banned peers</source>
        <translation type="unfinished">មិត្តភក្រ្ត័ត្រូវបានហាមឃាត់</translation>
    </message>
    <message>
        <source>Select a peer to view detailed information.</source>
        <translation type="unfinished">ជ្រើសរើសមិត្តភក្រ្ត័ម្នាក់ដើម្បីមើលពត័មានលំម្អិត។</translation>
    </message>
    <message>
        <source>Version</source>
        <translation type="unfinished">ជំនាន់</translation>
    </message>
    <message>
        <source>Whether we relay transactions to this peer.</source>
        <translation type="unfinished">ថាតើយើងបញ្ជូនតប្រតិបត្តិការទៅpeerនេះឬអត់។</translation>
    </message>
    <message>
        <source>Transaction Relay</source>
        <translation type="unfinished">ការបញ្ជូនតប្រតិបត្តិការ</translation>
    </message>
    <message>
        <source>Starting Block</source>
        <translation type="unfinished">កំពុងចាប់ផ្តើមប៊្លុក</translation>
    </message>
    <message>
        <source>Last Transaction</source>
        <translation type="unfinished">ប្រតិបត្តិការចុងក្រោយ</translation>
    </message>
    <message>
        <source>Whether we relay addresses to this peer.</source>
        <extracomment>Tooltip text for the Address Relay field in the peer details area, which displays whether we relay addresses to this peer (Yes/No).</extracomment>
        <translation type="unfinished">ថាតើយើងបញ្ជូនអាសយដ្ឋានទៅpeerនេះឬអត់។</translation>
    </message>
    <message>
        <source>Address Relay</source>
        <extracomment>Text title for the Address Relay field in the peer details area, which displays whether we relay addresses to this peer (Yes/No).</extracomment>
        <translation type="unfinished">អាសយដ្ឋានបញ្ជូនបន្ត</translation>
    </message>
    <message>
        <source>Addresses Processed</source>
        <extracomment>Text title for the Addresses Processed field in the peer details area, which displays the total number of addresses received from this peer that were processed (excludes addresses that were dropped due to rate-limiting).</extracomment>
        <translation type="unfinished">អាសយដ្ឋានត្រូវបានដំណើរការ</translation>
    </message>
    <message>
        <source>Decrease font size</source>
        <translation type="unfinished">បន្ថយទំហំអក្សរ</translation>
    </message>
    <message>
        <source>Increase font size</source>
        <translation type="unfinished">បង្កើនទំហំអក្សរ</translation>
    </message>
    <message>
        <source>Permissions</source>
        <translation type="unfinished">ការអនុញ្ញាត</translation>
    </message>
    <message>
        <source>Direction/Type</source>
        <translation type="unfinished">ទិសដៅ/ប្រភេទ</translation>
    </message>
    <message>
        <source>Services</source>
        <translation type="unfinished">សេវាកម្ម</translation>
    </message>
    <message>
        <source>High Bandwidth</source>
        <translation type="unfinished">កម្រិតបញ្ជូនខ្ពស់</translation>
    </message>
    <message>
        <source>Connection Time</source>
        <translation type="unfinished">ពេលវាលាតភ្ជាប់</translation>
    </message>
    <message>
        <source>Last Block</source>
        <translation type="unfinished">ប្លុកចុងក្រោយ</translation>
    </message>
    <message>
        <source>Last Send</source>
        <translation type="unfinished">បញ្ចូនចុងក្រោយ</translation>
    </message>
    <message>
        <source>Last Receive</source>
        <translation type="unfinished">ទទួលចុងក្រោយ</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation type="unfinished">ពេលវេលាប្លុកចុងក្រោយ</translation>
    </message>
    <message>
        <source>&amp;Network Traffic</source>
        <translation type="unfinished">&amp;ចរាចរណ៍បណ្តាញ</translation>
    </message>
    <message>
        <source>Totals</source>
        <translation type="unfinished">សរុប</translation>
    </message>
    <message>
        <source>In:</source>
        <translation type="unfinished">ចូលៈ</translation>
    </message>
    <message>
        <source>Out:</source>
        <translation type="unfinished">ចេញៈ</translation>
    </message>
    <message>
        <source>no high bandwidth relay selected</source>
        <translation type="unfinished">មិន​បាន​ជ្រើស​បញ្ជូន​បន្ត​កម្រិត​បញ្ជូន​ខ្ពស់​</translation>
    </message>
    <message>
        <source>&amp;Copy address</source>
        <extracomment>Context menu action to copy the address of a peer.</extracomment>
        <translation type="unfinished">ចម្លងអាសយដ្ឋាន(&amp;C)</translation>
    </message>
    <message>
        <source>1 d&amp;ay</source>
        <translation type="unfinished">1 ថ្ងៃ(&amp;a)</translation>
    </message>
    <message>
        <source>&amp;Copy IP/Netmask</source>
        <extracomment>Context menu action to copy the IP/Netmask of a banned peer. IP/Netmask is the combination of a peer's IP address and its Netmask. For IP address, see: https://en.wikipedia.org/wiki/IP_address.</extracomment>
        <translation type="unfinished">ចម្លង IP/Netmask (&amp;C)</translation>
    </message>
    <message>
        <source>Network activity disabled</source>
        <translation type="unfinished">សកម្មភាពបណ្តាញ ត្រូវបានដាក់អោយប្រើការលែងបាន។</translation>
    </message>
    <message>
        <source>Executing command without any wallet</source>
        <translation type="unfinished">ប្រត្តិបត្តិបញ្ជារដោយគ្មានកាបូបអេឡិចត្រូនិច។</translation>
    </message>
    <message>
        <source>Ctrl+N</source>
        <translation type="unfinished">Ctrl+T</translation>
    </message>
    <message>
        <source>Executing…</source>
        <extracomment>A console message indicating an entered command is currently being executed.</extracomment>
        <translation type="unfinished">កំពុង​ប្រតិបត្តិ…</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="unfinished">បាទ ឬ ចាស</translation>
    </message>
    <message>
        <source>No</source>
        <translation type="unfinished">ទេ</translation>
    </message>
    <message>
        <source>To</source>
        <translation type="unfinished">ទៅកាន់</translation>
    </message>
    <message>
        <source>From</source>
        <translation type="unfinished">ពី</translation>
    </message>
    <message>
        <source>Never</source>
        <translation type="unfinished">មិនដែល</translation>
    </message>
    </context>
<context>
    <name>ReceiveCoinsDialog</name>
    <message>
        <source>&amp;Amount:</source>
        <translation type="unfinished">&amp;ចំនួន</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation type="unfinished">&amp;ស្លាក​សញ្ញា:</translation>
    </message>
    <message>
        <source>&amp;Message:</source>
        <translation type="unfinished">&amp;សារ</translation>
    </message>
    <message>
        <source>An optional message to attach to the payment request, which will be displayed when the request is opened. Note: The message will not be sent with the payment over the Kawra network.</source>
        <translation type="unfinished">សារជាជម្រើសមួយក្នុងការភ្ជាប់ទៅនឹងសំណើរទូរទាត់ប្រាក់ ដែលនឹងត្រូវបង្ហាញនៅពេលដែលសំណើរត្រូវបានបើក។ កំណត់ចំណាំៈ សារនេះនឹងមិនត្រូវបានបញ្ចូនជាមួយការទូរទាត់ប្រាក់នៅលើបណ្តាញប៊ីតខញ។</translation>
    </message>
    <message>
        <source>An optional label to associate with the new receiving address.</source>
        <translation type="unfinished">ស្លាកសញ្ញាជាជម្រើសមួយ ទាក់ទងជាមួយនឹងអាសយដ្ឋានទទួលថ្មី។</translation>
    </message>
    <message>
        <source>Use this form to request payments. All fields are &lt;b&gt;optional&lt;/b&gt;.</source>
        <translation type="unfinished">ប្រើប្រាស់ទម្រង់នេះដើម្បីធ្វើការសំណូមពរទូរទាត់ប្រាក់។ រាល់ការបំពេញក្នុងប្រអប់ទាំងអស់​គឺ&lt;b&gt;ជាជម្រើស&lt;/b&gt;។</translation>
    </message>
    <message>
        <source>An optional amount to request. Leave this empty or zero to not request a specific amount.</source>
        <translation type="unfinished">ចំនួនជម្រើសមួយ សម្រាប់សំណើរ។ សូមទុកសូន្យ ឫ ទទេ ទៅដល់មិនសំណើរចំនួនជាក់លាក់ណាមួយ។</translation>
    </message>
    <message>
        <source>An optional label to associate with the new receiving address (used by you to identify an invoice).  It is also attached to the payment request.</source>
        <translation type="unfinished">ស្លាកសញ្ញាជាជម្រើសមួយ ទាក់ទងជាមួយនឹងអាសយដ្ឋានទទួលថ្មី( ដែលអ្នកបានប្រើប្រាស់ ដើម្បីសម្គាល់វិក័យបត្រមួយ)។ វាក៏ត្រូវបានភ្ជាប់ជាមួយនឹងសំណើរទូរទាត់ប្រាក់។</translation>
    </message>
    <message>
        <source>An optional message that is attached to the payment request and may be displayed to the sender.</source>
        <translation type="unfinished">សារជាជម្រើសមួយដែលភ្ជាប់ជាមួយសំណើរទូរទាត់ប្រាក់ និង ប្រហែលជាបង្ហាញទៅកាន់អ្នកបញ្ចូន។</translation>
    </message>
    <message>
        <source>&amp;Create new receiving address</source>
        <translation type="unfinished">&amp;បង្កើតអាសយដ្ឋានទទួលថ្មី</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation type="unfinished">សម្អាតគ្រប់ប្រអប់ទាំងអស់ក្នុងទម្រង់នេះ។</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation type="unfinished">សម្អាត</translation>
    </message>
    <message>
        <source>Requested payments history</source>
        <translation type="unfinished">បានដាក់ស្នើរសុំយកប្រវត្តិការទូរទាត់ប្រាក់</translation>
    </message>
    <message>
        <source>Show the selected request (does the same as double clicking an entry)</source>
        <translation type="unfinished">ធ្វើការបង្ហាញ សំណូមពរដែលត្រូវបានជ្រើសរើស​(ធ្វើដូចគ្នា ដោយចុចពីរដងសម្រាប់ការបញ្ចូលម្តង)</translation>
    </message>
    <message>
        <source>Show</source>
        <translation type="unfinished">បង្ហាញ</translation>
    </message>
    <message>
        <source>Remove the selected entries from the list</source>
        <translation type="unfinished">លុបចេញការបញ្ចូលដែលបានជ្រើសរើស ពីក្នុងបញ្ចីរ</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished">លុបចេញ</translation>
    </message>
    <message>
        <source>Copy &amp;URI</source>
        <translation type="unfinished">ថតចម្លង &amp;RUl</translation>
    </message>
    <message>
        <source>&amp;Copy address</source>
        <translation type="unfinished">ចម្លងអាសយដ្ឋាន(&amp;C)</translation>
    </message>
    <message>
        <source>Copy &amp;label</source>
        <translation type="unfinished">ចម្លង &amp; ស្លាក</translation>
    </message>
    <message>
        <source>Copy &amp;message</source>
        <translation type="unfinished">ចម្លងសារ(&amp;m)</translation>
    </message>
    <message>
        <source>Copy &amp;amount</source>
        <translation type="unfinished">ចម្លង &amp; ចំនួនទឹកប្រាក់</translation>
    </message>
    <message>
        <source>Could not unlock wallet.</source>
        <translation type="unfinished">មិនអាចបើកសោរ កាបូបអេឡិចត្រូនិចបាន។</translation>
    </message>
    </context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>Request payment to …</source>
        <translation type="unfinished">ស្នើសុំការទូទាត់ទៅ…</translation>
    </message>
    <message>
        <source>Address:</source>
        <translation type="unfinished">អាសយដ្ឋានៈ</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation type="unfinished">ចំនួនទឹកប្រាក់៖</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation type="unfinished">ស្លាកសញ្ញាៈ</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation type="unfinished">សារៈ</translation>
    </message>
    <message>
        <source>Wallet:</source>
        <translation type="unfinished">កាបូបចល័ត៖</translation>
    </message>
    <message>
        <source>Copy &amp;URI</source>
        <translation type="unfinished">ថតចម្លង &amp;RUl</translation>
    </message>
    <message>
        <source>Copy &amp;Address</source>
        <translation type="unfinished">ថតចម្លង និង អាសយដ្ឋាន</translation>
    </message>
    <message>
        <source>&amp;Verify</source>
        <translation type="unfinished">ផ្ទៀង​ផ្ទាត់(&amp;V)</translation>
    </message>
    <message>
        <source>Verify this address on e.g. a hardware wallet screen</source>
        <translation type="unfinished">ផ្ទៀងផ្ទាត់អាសយដ្ឋាននេះនៅលើឧ. អេក្រង់កាបូបផ្នែករឹង</translation>
    </message>
    <message>
        <source>&amp;Save Image…</source>
        <translation type="unfinished">រក្សាទុក​រូបភាព(&amp;S)…</translation>
    </message>
    <message>
        <source>Payment information</source>
        <translation type="unfinished">ព័ត៏មានទូរទាត់ប្រាក់</translation>
    </message>
    </context>
<context>
    <name>RecentRequestsTableModel</name>
    <message>
        <source>Date</source>
        <translation type="unfinished">កាលបរិច្ឆេទ</translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished">ស្លាក​</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(គ្មាន​ស្លាក​)</translation>
    </message>
    <message>
        <source>(no message)</source>
        <translation type="unfinished">(មិនមានសារ)</translation>
    </message>
    <message>
        <source>(no amount requested)</source>
        <translation type="unfinished">(មិនចំនួនបានស្នើរសុំ)</translation>
    </message>
    <message>
        <source>Requested</source>
        <translation type="unfinished">បានស្នើរសុំ</translation>
    </message>
</context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Send Coins</source>
        <translation type="unfinished">បញ្ចូនកាក់</translation>
    </message>
    <message>
        <source>Coin Control Features</source>
        <translation type="unfinished">លក្ខណៈពិសេសក្នុងត្រួតពិនិត្យកាក់</translation>
    </message>
    <message>
        <source>automatically selected</source>
        <translation type="unfinished">បានជ្រើសរើសដោយស្វ័យប្រវត្តិ</translation>
    </message>
    <message>
        <source>Insufficient funds!</source>
        <translation type="unfinished">ប្រាក់មិនគ្រប់គ្រាន់!</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation type="unfinished">បរិមាណ៖</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation type="unfinished">Bytes៖</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation type="unfinished">ចំនួនទឹកប្រាក់៖</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation type="unfinished">តម្លៃសេវា៖</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation type="unfinished">បន្ទាប់ពីតម្លៃសេវា៖</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation type="unfinished">ប្តូរ៖</translation>
    </message>
    <message>
        <source>Custom change address</source>
        <translation type="unfinished">ជ្រើសរើសផ្លាស់ប្តូរអាសយដ្ឋាន</translation>
    </message>
    <message>
        <source>Transaction Fee:</source>
        <translation type="unfinished">កម្រៃប្រត្តិបត្តិការ</translation>
    </message>
    <message>
        <source>Hide</source>
        <translation type="unfinished">លាក់</translation>
    </message>
    <message>
        <source>Recommended:</source>
        <translation type="unfinished">បានណែនាំៈ</translation>
    </message>
    <message>
        <source>Send to multiple recipients at once</source>
        <translation type="unfinished">បញ្ចូនទៅកាន់អ្នកទទួលច្រើនអ្នកក្នុងពេលតែមួយ</translation>
    </message>
    <message>
        <source>Add &amp;Recipient</source>
        <translation type="unfinished">បន្ថែម &amp;អ្នកទទួល</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation type="unfinished">សម្អាតគ្រប់ប្រអប់ទាំងអស់ក្នុងទម្រង់នេះ។</translation>
    </message>
    <message>
        <source>Inputs…</source>
        <translation type="unfinished">ធាតុចូល...</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation type="unfinished">ធូលី៖</translation>
    </message>
    <message>
        <source>Choose…</source>
        <translation type="unfinished">ជ្រើសរើស…</translation>
    </message>
    <message>
        <source>Specify a custom fee per kB (1,000 bytes) of the transaction's virtual size.

Note:  Since the fee is calculated on a per-byte basis, a fee rate of "100 satoshis per kvB" for a transaction size of 500 virtual bytes (half of 1 kvB) would ultimately yield a fee of only 50 satoshis.</source>
        <translation type="unfinished">បញ្ជាក់ថ្លៃផ្ទាល់ខ្លួនក្នុងមួយkB (1,000 byte) នៃទំហំនិម្មិតរបស់ប្រតិបត្តិការ។

ចំណាំ៖ ដោយសារតម្លៃត្រូវបានគណនាលើមូលដ្ឋានក្នុងមួយបៃ អត្រាថ្លៃសេវា "100 satoshis ក្នុងមួយ kvB" សម្រាប់ទំហំប្រតិបត្តិការ 500  byteនិម្មិត (ពាក់កណ្តាលនៃ 1 kvB) ទីបំផុតនឹងផ្តល់ថ្លៃសេវាត្រឹមតែ 50 satoshis ប៉ុណ្ណោះ។</translation>
    </message>
    <message>
        <source>A too low fee might result in a never confirming transaction (read the tooltip)</source>
        <translation type="unfinished">កម្រៃទាបពេកមិនអាចធ្វើឲ្យបញ្ចាក់ពីប្រត្តិបត្តិការ​(សូមអាន ប្រអប់សារ)</translation>
    </message>
    <message>
        <source>(Smart fee not initialized yet. This usually takes a few blocks…)</source>
        <translation type="unfinished">(ថ្លៃសេវាឆ្លាតវៃមិនទាន់ត្រូវបានចាប់ផ្តើមនៅឡើយទេ។ ជាធម្មតាវាចំណាយពេលពីរបីប្លុក...)</translation>
    </message>
    <message>
        <source>Confirmation time target:</source>
        <translation type="unfinished">ការបញ្ចាក់ទិសដៅពេលវេលាៈ</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation type="unfinished">សម្អាត &amp;ទាំងអស់</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation type="unfinished">សមតុល្យៈ</translation>
    </message>
    <message>
        <source>Confirm the send action</source>
        <translation type="unfinished">បញ្ចាក់សកម្មភាពបញ្ចូន</translation>
    </message>
    <message>
        <source>S&amp;end</source>
        <translation type="unfinished">ប&amp;ញ្ជូន</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation type="unfinished">ចម្លងបរិមាណ</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation type="unfinished">ចម្លងចំនួនទឹកប្រាក់</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation type="unfinished">ចម្លងតម្លៃ</translation>
    </message>
    <message>
        <source>Copy dust</source>
        <translation type="unfinished">ចម្លងធូលី</translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation type="unfinished">ចម្លងការផ្លាស់ប្តូរ</translation>
    </message>
    <message>
        <source>Sign on device</source>
        <extracomment>"device" usually means a hardware wallet.</extracomment>
        <translation type="unfinished">ចុះហត្ថលេខាលើឧបករណ៍</translation>
    </message>
    <message>
        <source>Connect your hardware wallet first.</source>
        <translation type="unfinished">ភ្ជាប់កាបូបហាដវែរបស់អ្នកជាមុនសិន។</translation>
    </message>
    <message>
        <source>Set external signer script path in Options -&gt; Wallet</source>
        <extracomment>"External signer" means using devices such as hardware wallets.</extracomment>
        <translation type="unfinished">កំណត់ទីតាំងscript អ្នកចុះហត្ថលេខាខាងក្រៅនៅក្នុងជម្រើស -&gt; កាបូប</translation>
    </message>
    <message>
        <source>To review recipient list click "Show Details…"</source>
        <translation type="unfinished">ដើម្បីពិនិត្យមើលបញ្ជីអ្នកទទួលសូមចុច "បង្ហាញព័ត៌មានលម្អិត..."</translation>
    </message>
    <message>
        <source>Sign failed</source>
        <translation type="unfinished">សញ្ញាបរាជ័យ</translation>
    </message>
    <message>
        <source>External signer not found</source>
        <extracomment>"External signer" means using devices such as hardware wallets.</extracomment>
        <translation type="unfinished">រកមិនឃើញអ្នកចុះហត្ថលេខាខាងក្រៅទេ។</translation>
    </message>
    <message>
        <source>External signer failure</source>
        <extracomment>"External signer" means using devices such as hardware wallets.</extracomment>
        <translation type="unfinished">ការបរាជ័យអ្នកចុះហត្ថលេខាខាងក្រៅ</translation>
    </message>
    <message>
        <source>Save Transaction Data</source>
        <translation type="unfinished">រក្សាទិន្នន័យប្រត្តិបត្តិការ</translation>
    </message>
    <message>
        <source>Partially Signed Transaction (Binary)</source>
        <extracomment>Expanded name of the binary PSBT file format. See: BIP 174.</extracomment>
        <translation type="unfinished">ប្រតិបត្តិការដែលបានចុះហត្ថលេខាដោយផ្នែក (ប្រព័ន្ធគោលពីរ)</translation>
    </message>
    <message>
        <source>PSBT saved</source>
        <extracomment>Popup message when a PSBT has been saved to a file</extracomment>
        <translation type="unfinished"> បានរក្សាទុកPSBT</translation>
    </message>
    <message>
        <source>External balance:</source>
        <translation type="unfinished">សមតុល្យខាងក្រៅ៖</translation>
    </message>
    <message>
        <source>or</source>
        <translation type="unfinished">ឬ</translation>
    </message>
    <message>
        <source>You can increase the fee later (signals Replace-By-Fee, BIP-125).</source>
        <translation type="unfinished">អ្នកអាចបង្កើនកម្រៃពេលក្រោយ( សញ្ញា ជំនួសដោយកម្រៃ BIP-125)។</translation>
    </message>
    <message>
        <source>Do you want to create this transaction?</source>
        <extracomment>Message displayed when attempting to create a transaction. Cautionary text to prompt the user to verify that the displayed transaction details represent the transaction the user intends to create.</extracomment>
        <translation type="unfinished">តើអ្នកចង់បង្កើតប្រតិបត្តិការនេះទេ?</translation>
    </message>
    <message>
        <source>Please, review your transaction. You can create and send this transaction or create a Partially Signed Kawra Transaction (PSBT), which you can save or copy and then sign with, e.g., an offline %1 wallet, or a PSBT-compatible hardware wallet.</source>
        <extracomment>Text to inform a user attempting to create a transaction of their current options. At this stage, a user can send their transaction or create a PSBT. This string is displayed when both private keys and PSBT controls are enabled.</extracomment>
        <translation type="unfinished">សូមពិនិត្យមើលប្រតិបត្តិការរបស់អ្នក។ អ្នកអាចបង្កើត និងផ្ញើប្រតិបត្តិការនេះ ឬបង្កើតប្រតិបត្តិការ Kawra ដែលបានចុះហត្ថលេខាដោយផ្នែក (PSBT) ដែលអ្នកអាចរក្សាទុក ឬចម្លងហើយបន្ទាប់មកចុះហត្ថលេខាជាមួយ ឧ. %1កាបូបក្រៅបណ្តាញ ឬកាបូបហាដវែដែលត្រូវគ្នាជាមួយ PSBT ។</translation>
    </message>
    <message>
        <source>Please, review your transaction.</source>
        <extracomment>Text to prompt a user to review the details of the transaction they are attempting to send.</extracomment>
        <translation type="unfinished">សូមពិនិត្យប្រត្តិបត្តិការទឹកប្រាក់របស់អ្នកសារឡើងវិញ។</translation>
    </message>
    <message>
        <source>Transaction fee</source>
        <translation type="unfinished">កម្រៃប្រត្តិបត្តិការ</translation>
    </message>
    <message>
        <source>Total Amount</source>
        <translation type="unfinished">ចំនួនសរុប</translation>
    </message>
    <message>
        <source>Confirm send coins</source>
        <translation type="unfinished">បញ្ចាក់​ ក្នុងការបញ្ចូនកាក់</translation>
    </message>
    <message>
        <source>Watch-only balance:</source>
        <translation type="unfinished">សមតុល្យសម្រាប់តែមើលៈ</translation>
    </message>
    <message>
        <source>The recipient address is not valid. Please recheck.</source>
        <translation type="unfinished">អាសយដ្ឋានអ្នកទទួលមិនត្រឹមត្រូវ។ សូមពិនិត្យម្តងទៀត។</translation>
    </message>
    <message>
        <source>The amount to pay must be larger than 0.</source>
        <translation type="unfinished">ចំនួនទឹកប្រាក់ដែលត្រូវបងត្រូវតែធំជាង ០។</translation>
    </message>
    <message>
        <source>The amount exceeds your balance.</source>
        <translation type="unfinished">ចំនួនលើសសមតុល្យរបស់អ្នក។</translation>
    </message>
    <message>
        <source>Duplicate address found: addresses should only be used once each.</source>
        <translation type="unfinished">អាសយដ្ឋានស្ទួនត្រូវបានរកឃើញៈ គ្រប់អាសយដ្ឋានគួរត្រូវបានប្រើតែម្តង</translation>
    </message>
    <message>
        <source>Transaction creation failed!</source>
        <translation type="unfinished">បង្កើតប្រត្តិបត្តិការមិនជោគជ័យ!</translation>
    </message>
    <message numerus="yes">
        <source>Estimated to begin confirmation within %n block(s).</source>
        <translation type="unfinished">
            <numerusform>ប៉ាន់ស្មានដើម្បីចាប់ផ្តើមការបញ្ជាក់នៅក្នុង%n(ច្រើន)ប្លុក។</numerusform>
            <numerusform />
        </translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(គ្មាន​ស្លាក​)</translation>
    </message>
</context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>A&amp;mount:</source>
        <translation type="unfinished">ចំ&amp;នួនៈ</translation>
    </message>
    <message>
        <source>Pay &amp;To:</source>
        <translation type="unfinished">ទូរទាត់ទៅ&amp;កាន់ៈ</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation type="unfinished">&amp;ស្លាក​សញ្ញា:</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation type="unfinished">ជ្រើសរើសអាសយដ្ឋានដែលបានប្រើពីមុន</translation>
    </message>
    <message>
        <source>The Kawra address to send the payment to</source>
        <translation type="unfinished">អាសយដ្ឋានប៊ីតខញក្នុងការបញ្ចូនការទូរទាត់ប្រាក់ទៅកាន់</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation type="unfinished">ថតចម្លងអាសយដ្ឋាណពីក្ដារតម្រៀប</translation>
    </message>
    <message>
        <source>Remove this entry</source>
        <translation type="unfinished">លុបការបញ្ចូលនេះ</translation>
    </message>
    <message>
        <source>Use available balance</source>
        <translation type="unfinished">ប្រើប្រាស់សមតុល្យដែលមានសាច់ប្រាក់</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation type="unfinished">សារៈ</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to the list of used addresses</source>
        <translation type="unfinished">បញ្ចូលស្លាក​សញ្ញាមួយ សម្រាប់អាសយដ្ឋាននេះ ដើម្បីបញ្ចូលវាទៅក្នងបញ្ចីរអាសយដ្ឋានដែលបានប្រើប្រាស់</translation>
    </message>
    </context>
<context>
    <name>SendConfirmationDialog</name>
    <message>
        <source>Send</source>
        <translation type="unfinished">បញ្ចូន</translation>
    </message>
    </context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>Signatures - Sign / Verify a Message</source>
        <translation type="unfinished">ហត្ថលេខា ចុះហត្ថលេខា ឬ ផ្ទៀងផ្ទាត់សារមួយ</translation>
    </message>
    <message>
        <source>&amp;Sign Message</source>
        <translation type="unfinished">&amp;ចុះហត្ថលេខា សារ</translation>
    </message>
    <message>
        <source>The Kawra address to sign the message with</source>
        <translation type="unfinished">អាសយដ្ឋានប៊ីតខញនេះ ចុះហត្ថលេខានៅលើសារ</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation type="unfinished">ជ្រើសរើសអាសយដ្ឋានដែលបានប្រើពីមុន</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation type="unfinished">ថតចម្លងអាសយដ្ឋាណពីក្ដារតម្រៀប</translation>
    </message>
    <message>
        <source>Enter the message you want to sign here</source>
        <translation type="unfinished">សូមបញ្ចូលពាក្យដែលអ្នកចង់បញ្ចូលនៅទីនេះ</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation type="unfinished">ហត្ថលេខា</translation>
    </message>
    <message>
        <source>Copy the current signature to the system clipboard</source>
        <translation type="unfinished">ចម្លងហត្ថលេខដែលមានបច្ចុប្បន្នទៅកាន់ប្រព័ន្ធក្តារតមៀប</translation>
    </message>
    <message>
        <source>Sign the message to prove you own this Kawra address</source>
        <translation type="unfinished">ចុះហត្ថលេខាលើសារនេះដើម្បីបង្ហាញថាលោកអ្នកជាម្ចាស់អាសយដ្ឋានប៊ីតខញ</translation>
    </message>
    <message>
        <source>Sign &amp;Message</source>
        <translation type="unfinished">ហត្ថលេខា &amp; សារ</translation>
    </message>
    <message>
        <source>Reset all sign message fields</source>
        <translation type="unfinished">កែសម្រួលឡើងវិញគ្រប់សារហត្ថលេខាទាំងអស់ឡើងវិញ</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation type="unfinished">សម្អាត &amp;ទាំងអស់</translation>
    </message>
    <message>
        <source>&amp;Verify Message</source>
        <translation type="unfinished">&amp;ផ្ទៀងផ្ទាត់សារ</translation>
    </message>
    <message>
        <source>The signed message to verify</source>
        <translation type="unfinished">សារដែលបានចុះហត្ថលេខា ដើម្បីបញ្ចាក់</translation>
    </message>
    <message>
        <source>The signature given when the message was signed</source>
        <translation type="unfinished">ហត្ថលេខាត្រូវបានផ្តល់នៅពេលដែលសារត្រូវបានចុះហត្ថលេខា</translation>
    </message>
    <message>
        <source>Verify the message to ensure it was signed with the specified Kawra address</source>
        <translation type="unfinished">ផ្ទៀងផ្ទាត់សារដើម្បីធានាថាវាត្រូវបានចុះហត្ថលេខាជាមួយនឹងអាសយដ្ឋានប៊ីតខញជាក់លាក់។</translation>
    </message>
    <message>
        <source>Verify &amp;Message</source>
        <translation type="unfinished">ផ្ទៀងផ្ទាត់&amp;សារ</translation>
    </message>
    <message>
        <source>Reset all verify message fields</source>
        <translation type="unfinished">កែសម្រួលឡើងវិញគ្រប់សារផ្ទៀងផ្ទាត់ទាំងអស់</translation>
    </message>
    <message>
        <source>Click "Sign Message" to generate signature</source>
        <translation type="unfinished">ចុច ៉ហត្ថលេខា​ លើសារ​ ​ ៉​ដើម្បីបង្កើតហត្ថលេខា</translation>
    </message>
    <message>
        <source>The entered address is invalid.</source>
        <translation type="unfinished">អាសយដ្ឋានដែលបានបញ្ចូល មិនត្រឹមត្រូវ។</translation>
    </message>
    <message>
        <source>Please check the address and try again.</source>
        <translation type="unfinished">សូមពិនិត្យអាសយដ្ឋាននេះឡើងវិញ រួចហើយព្យាយាមម្តងទៀត។</translation>
    </message>
    <message>
        <source>Wallet unlock was cancelled.</source>
        <translation type="unfinished">បោះបង់ចោល ការដោះសោរកាបូបអេឡិចត្រូនិច។</translation>
    </message>
    <message>
        <source>No error</source>
        <translation type="unfinished">មិនមានបញ្ហា</translation>
    </message>
    <message>
        <source>Message signing failed.</source>
        <translation type="unfinished">ការចុះហត្ថលេខាលើសារមិនជោគជ័យ។</translation>
    </message>
    <message>
        <source>Message signed.</source>
        <translation type="unfinished">សារបានចុះហត្ថលេខា។</translation>
    </message>
    <message>
        <source>The signature could not be decoded.</source>
        <translation type="unfinished">ការចុះហត្ថលេខានេះមិនគួរត្រូវបានបម្លែងទៅជាភាសាកុំព្យូទ័រទេ។</translation>
    </message>
    <message>
        <source>Please check the signature and try again.</source>
        <translation type="unfinished">សូមពិនិត្យការចុះហត្ថលេខានេះឡើងវិញ រូចហើយព្យាយាមម្តងទៀត។</translation>
    </message>
    <message>
        <source>The signature did not match the message digest.</source>
        <translation type="unfinished">ហត្ថលេខានេះមិនត្រូវទៅនឹងសារដែលបានបំលែងរួច។</translation>
    </message>
    <message>
        <source>Message verification failed.</source>
        <translation type="unfinished">សារបញ្ចាក់ មិនត្រឹមត្រូវ។</translation>
    </message>
    <message>
        <source>Message verified.</source>
        <translation type="unfinished">សារត្រូវបានផ្ទៀងផ្ទាត់។</translation>
    </message>
</context>
<context>
    <name>SplashScreen</name>
    <message>
        <source>(press q to shutdown and continue later)</source>
        <translation type="unfinished">(ចុច q ដើម្បីបិទ ហើយបន្តពេលក្រោយ)</translation>
    </message>
    <message>
        <source>press q to shutdown</source>
        <translation type="unfinished">ចុច q ដើម្បីបិទ</translation>
    </message>
</context>
<context>
    <name>TransactionDesc</name>
    <message>
        <source>abandoned</source>
        <extracomment>Text explaining the current status of a transaction, shown in the status field of the details window for this transaction. This status represents an abandoned transaction.</extracomment>
        <translation type="unfinished">បានបោះបង់ចោល</translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished">ស្ថានភាព</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished">កាលបរិច្ឆេទ</translation>
    </message>
    <message>
        <source>Source</source>
        <translation type="unfinished">ប្រភព</translation>
    </message>
    <message>
        <source>Generated</source>
        <translation type="unfinished">បានបង្កើត</translation>
    </message>
    <message>
        <source>From</source>
        <translation type="unfinished">ពី</translation>
    </message>
    <message>
        <source>unknown</source>
        <translation type="unfinished">មិនស្គាល់</translation>
    </message>
    <message>
        <source>To</source>
        <translation type="unfinished">ទៅកាន់</translation>
    </message>
    <message>
        <source>own address</source>
        <translation type="unfinished">អាសយដ្ឋានផ្ទាល់ខ្លួន</translation>
    </message>
    <message>
        <source>watch-only</source>
        <translation type="unfinished">សម្រាប់តែមើល</translation>
    </message>
    <message>
        <source>label</source>
        <translation type="unfinished">ស្លាក​សញ្ញា</translation>
    </message>
    <message numerus="yes">
        <source>matures in %n more block(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message>
        <source>not accepted</source>
        <translation type="unfinished">មិនបានទទួល</translation>
    </message>
    <message>
        <source>Transaction fee</source>
        <translation type="unfinished">កម្រៃប្រត្តិបត្តិការ</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation type="unfinished">យោលបល់</translation>
    </message>
    <message>
        <source>Transaction ID</source>
        <translation type="unfinished">អត្តសញ្ញាណ ប្រត្តិបត្តិការ</translation>
    </message>
    <message>
        <source>Transaction total size</source>
        <translation type="unfinished">ទំហំសរុបប្រត្តិបត្តិការ</translation>
    </message>
    <message>
        <source>Transaction virtual size</source>
        <translation type="unfinished">ទំហំប្រត្តិបត្តិការជាក់ស្តែង</translation>
    </message>
    <message>
        <source>Transaction</source>
        <translation type="unfinished">ប្រត្តិបត្តិការ</translation>
    </message>
    <message>
        <source>Inputs</source>
        <translation type="unfinished">ធាតុចូល</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">ចំនួន</translation>
    </message>
    <message>
        <source>true</source>
        <translation type="unfinished">ត្រូវ</translation>
    </message>
    <message>
        <source>false</source>
        <translation type="unfinished">មិនត្រឹមត្រូវ</translation>
    </message>
</context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Date</source>
        <translation type="unfinished">កាលបរិច្ឆេទ</translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished">ប្រភេទ</translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished">ស្លាក​</translation>
    </message>
    <message>
        <source>Unconfirmed</source>
        <translation type="unfinished">មិនទាន់បានបញ្ចាក់ច្បាស់</translation>
    </message>
    <message>
        <source>Abandoned</source>
        <translation type="unfinished">បានបោះបង់</translation>
    </message>
    <message>
        <source>Conflicted</source>
        <translation type="unfinished">បានប្រឆាំងតទល់គ្នា</translation>
    </message>
    <message>
        <source>Generated but not accepted</source>
        <translation type="unfinished">បានបង្កើត ប៉ុន្តែមិនបានទទួល</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation type="unfinished">បានទទួលជាមួយនឹង</translation>
    </message>
    <message>
        <source>Received from</source>
        <translation type="unfinished">បានទទួលពី</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation type="unfinished">បានបញ្ចូនទៅកាន់</translation>
    </message>
    <message>
        <source>Payment to yourself</source>
        <translation type="unfinished">បង់ប្រាក់ទៅខ្លួនអ្នក</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation type="unfinished">បានរុករករ៉ែ</translation>
    </message>
    <message>
        <source>watch-only</source>
        <translation type="unfinished">សម្រាប់តែមើល</translation>
    </message>
    <message>
        <source>(n/a)</source>
        <translation type="unfinished">(មិនមាន)</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(គ្មាន​ស្លាក​)</translation>
    </message>
    <message>
        <source>Transaction status. Hover over this field to show number of confirmations.</source>
        <translation type="unfinished">ស្ថានភាពប្រត្តិបត្តិការ។ អូសម៉ៅដាក់លើប្រអប់នេះដើម្បីបង្ហាញចំនួននៃការបញ្ចាក់។</translation>
    </message>
    <message>
        <source>Date and time that the transaction was received.</source>
        <translation type="unfinished">ថ្ងៃ និង ពេលវេលាដែលទទួលបានប្រត្តិបត្តិការ។</translation>
    </message>
    <message>
        <source>Type of transaction.</source>
        <translation type="unfinished">ប្រភេទនៃប្រត្តិបត្តិការ</translation>
    </message>
    <message>
        <source>Amount removed from or added to balance.</source>
        <translation type="unfinished">ចំនួនទឹកប្រាក់បានដកចេញ ឬដាក់ចូលទៅក្នុងសមតុល្យ។</translation>
    </message>
</context>
<context>
    <name>TransactionView</name>
    <message>
        <source>All</source>
        <translation type="unfinished">ទាំងអស់</translation>
    </message>
    <message>
        <source>Today</source>
        <translation type="unfinished">ថ្ងៃនេះ</translation>
    </message>
    <message>
        <source>This week</source>
        <translation type="unfinished">សប្តាហ៍នេះ</translation>
    </message>
    <message>
        <source>This month</source>
        <translation type="unfinished">ខែនេះ</translation>
    </message>
    <message>
        <source>Last month</source>
        <translation type="unfinished">ខែមុន</translation>
    </message>
    <message>
        <source>This year</source>
        <translation type="unfinished">ឆ្នាំនេះ</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation type="unfinished">បានទទួលជាមួយនឹង</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation type="unfinished">បានបញ្ចូនទៅកាន់</translation>
    </message>
    <message>
        <source>To yourself</source>
        <translation type="unfinished">ទៅកាន់ខ្លូនអ្នក</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation type="unfinished">បានរុករករ៉ែ</translation>
    </message>
    <message>
        <source>Other</source>
        <translation type="unfinished">ផ្សេងទៀត</translation>
    </message>
    <message>
        <source>Enter address, transaction id, or label to search</source>
        <translation type="unfinished">បញ្ចូលអាសយដ្ឋាន អត្តសញ្ញាណប្រត្តិបត្តិការ ឫ ស្លាក​សញ្ញា ដើម្បីធ្វើការស្វែងរក</translation>
    </message>
    <message>
        <source>Min amount</source>
        <translation type="unfinished">ចំនួនតិចបំផុត</translation>
    </message>
    <message>
        <source>&amp;Copy address</source>
        <translation type="unfinished">ចម្លងអាសយដ្ឋាន(&amp;C)</translation>
    </message>
    <message>
        <source>Copy &amp;label</source>
        <translation type="unfinished">ចម្លង &amp; ស្លាក</translation>
    </message>
    <message>
        <source>Copy &amp;amount</source>
        <translation type="unfinished">ចម្លង &amp; ចំនួនទឹកប្រាក់</translation>
    </message>
    <message>
        <source>Export Transaction History</source>
        <translation type="unfinished">ប្រវត្តិនៃការនាំចេញប្រត្តិបត្តិការ</translation>
    </message>
    <message>
        <source>Comma separated file</source>
        <extracomment>Expanded name of the CSV file format. See: https://en.wikipedia.org/wiki/Comma-separated_values.</extracomment>
        <translation type="unfinished">Comma បំបែកឯកសារ</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation type="unfinished">បានបញ្ជាក់</translation>
    </message>
    <message>
        <source>Watch-only</source>
        <translation type="unfinished">សម្រាប់តែមើល</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished">កាលបរិច្ឆេទ</translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished">ប្រភេទ</translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished">ស្លាក​</translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="unfinished">អាសយដ្ឋាន</translation>
    </message>
    <message>
        <source>ID</source>
        <translation type="unfinished">អត្តសញ្ញាណ</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation type="unfinished">ការនាំចេញបានបរាជ័យ</translation>
    </message>
    <message>
        <source>Exporting Successful</source>
        <translation type="unfinished">កំពុងនាំចេញដោយជោគជ័យ</translation>
    </message>
    <message>
        <source>Range:</source>
        <translation type="unfinished">លំដាប់ពីៈ</translation>
    </message>
    <message>
        <source>to</source>
        <translation type="unfinished">ទៅកាន់</translation>
    </message>
</context>
<context>
    <name>WalletFrame</name>
    <message>
        <source>No wallet has been loaded.
Go to File &gt; Open Wallet to load a wallet.
- OR -</source>
        <translation type="unfinished">មិនមានកាបូបអេឡិចត្រូនិចបង្ហាញ។
ចូលឯកសារ‍»បើកកាបូបអេឡិចត្រូនិចដើម្បីបង្ហាញកាបូបមួយ
ឬ</translation>
    </message>
    <message>
        <source>Create a new wallet</source>
        <translation type="unfinished">បង្កើតកាបូបចល័តថ្មីមួយ</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">បញ្ហា</translation>
    </message>
    <message>
        <source>Unable to decode PSBT from clipboard (invalid base64)</source>
        <translation type="unfinished">មិនអាចបកស្រាយអក្សរសម្ងាត់​PSBT ពី​ក្ដារតម្រៀប (មូដ្ឋាន៦៤ មិនត្រឹមត្រូវ)</translation>
    </message>
    <message>
        <source>Load Transaction Data</source>
        <translation type="unfinished">ទាញយកទិន្ន័យប្រត្តិបត្តិការ</translation>
    </message>
    <message>
        <source>Partially Signed Transaction (*.psbt)</source>
        <translation type="unfinished">ប្រត្តិបត្តិការ ដែលបានចុះហត្ថលេខាដោយផ្នែក (*.psbt)</translation>
    </message>
    </context>
<context>
    <name>WalletModel</name>
    <message>
        <source>Send Coins</source>
        <translation type="unfinished">បញ្ចូនកាក់</translation>
    </message>
    <message>
        <source>Increasing transaction fee failed</source>
        <translation type="unfinished">តំឡើងកម្រៃប្រត្តិបត្តិការមិនជោគជ័យ</translation>
    </message>
    <message>
        <source>Do you want to increase the fee?</source>
        <extracomment>Asks a user if they would like to manually increase the fee of a transaction that has already been created.</extracomment>
        <translation type="unfinished">តើអ្នកចង់តំឡើងកម្រៃដែរ ឫទេ?</translation>
    </message>
    <message>
        <source>Current fee:</source>
        <translation type="unfinished">កម្រៃបច្ចុប្បន្ន</translation>
    </message>
    <message>
        <source>Warning: This may pay the additional fee by reducing change outputs or adding inputs, when necessary. It may add a new change output if one does not already exist. These changes may potentially leak privacy.</source>
        <translation type="unfinished">ការព្រមាន៖ វាអាចបង់ថ្លៃបន្ថែមដោយកាត់បន្ថយលទ្ធផលនៃការផ្លាស់ប្តូរ ឬបន្ថែមធាតុចូល នៅពេលចាំបាច់។ វាអាចបន្ថែមលទ្ធផលនៃការផ្លាស់ប្តូរថ្មី ប្រសិនបើវាមិនទាន់មាន។ ការផ្លាស់ប្តូរទាំងនេះអាចនឹងលេចធ្លាយភាពឯកជន។</translation>
    </message>
    <message>
        <source>Can't sign transaction.</source>
        <translation type="unfinished">មិនអាចចុះហត្ថលេខាលើប្រត្តិបត្តិការ។</translation>
    </message>
    <message>
        <source>Could not commit transaction</source>
        <translation type="unfinished">មិនបានធ្វើប្រត្តិបត្តិការ</translation>
    </message>
    </context>
<context>
    <name>WalletView</name>
    <message>
        <source>&amp;Export</source>
        <translation type="unfinished">នាំចេញ(&amp;E)</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation type="unfinished">នាំចេញទិន្នន័យនៃផ្ទាំងបច្ចុប្បន្នទៅជាឯកសារមួយ</translation>
    </message>
    <message>
        <source>Wallet Data</source>
        <extracomment>Name of the wallet data file format.</extracomment>
        <translation type="unfinished">ទិន្នន័យកាបូប</translation>
    </message>
    <message>
        <source>Backup Failed</source>
        <translation type="unfinished">ថតចម្លងទុកមិនទទួលបានជោគជ័យ</translation>
    </message>
    <message>
        <source>Backup Successful</source>
        <translation type="unfinished">ចំម្លងទុកដោយជោគជ័យ</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished">ចាកចេញ</translation>
    </message>
</context>
<context>
    <name>kawra-core</name>
    <message>
        <source>The transaction amount is too small to send after the fee has been deducted</source>
        <translation type="unfinished">ចំនួនប្រត្តិបត្តិការមានទឹកប្រាក់ទំហំតិចតួច ក្នុងការផ្ញើរចេញទៅ  បន្ទាប់ពីកំរៃត្រូវបានកាត់រួចរាល់</translation>
    </message>
    <message>
        <source>This is the maximum transaction fee you pay (in addition to the normal fee) to prioritize partial spend avoidance over regular coin selection.</source>
        <translation type="unfinished">នេះជាកម្រៃប្រត្តិបត្តិការតូចបំផុត ដែលអ្នកទូរទាត់ (បន្ថែមទៅលើកម្រៃធម្មតា)​​  ដើម្បីផ្តល់អាទិភាពលើការជៀសវៀងការចំណាយដោយផ្នែក សម្រាប់ការជ្រើសរើសកាក់ដោយទៀងទាត់។</translation>
    </message>
    <message>
        <source>This is the transaction fee you may pay when fee estimates are not available.</source>
        <translation type="unfinished"> អ្នកនឹងទូរទាត់ កម្រៃប្រត្តិបត្តិការនេះ នៅពេលណាដែល ទឹកប្រាក់នៃការប៉ាន់ស្មាន មិនទាន់មាន។</translation>
    </message>
    <message>
        <source>Total length of network version string (%i) exceeds maximum length (%i). Reduce the number or size of uacomments.</source>
        <translation type="unfinished">ប្រវែងខ្សែបណ្តាញសរុប(%i) លើសប្រវែងខ្សែដែលវែងបំផុត (%i)។ កាត់បន្ថយចំនួន ​ឬទំហំនៃ uacomments ។</translation>
    </message>
    <message>
        <source>Warning: Private keys detected in wallet {%s} with disabled private keys</source>
        <translation type="unfinished">សេចក្តីប្រកាសអាសន្នៈ​ លេខសំម្ងាត់ត្រូវបានស្វែងរកឃើញនៅក្នុងកាបូបអេឡិចត្រូនិច​ {%s} ជាមួយនិងលេខសំម្ងាត់ត្រូវបានដាក់ឲ្យលែងប្រើលែងកើត</translation>
    </message>
    <message>
        <source>%s is set very high!</source>
        <translation type="unfinished">%s ត្រូវបានកំណត់យ៉ាងខ្ពស់</translation>
    </message>
    <message>
        <source>Cannot write to data directory '%s'; check permissions.</source>
        <translation type="unfinished">មិនអាចសរសេរទៅកាន់ កន្លែងផ្ទុកទិន្នន័យ​ '%s'; ពិនិត្យមើលការអនុញ្ញាត។</translation>
    </message>
    <message>
        <source>The inputs size exceeds the maximum weight. Please try sending a smaller amount or manually consolidating your wallet's UTXOs</source>
        <translation type="unfinished">ទំហំបញ្ចូលលើសពីទម្ងន់អតិបរមា។ សូមព្យាយាមផ្ញើចំនួនតូចជាងនេះ ឬបង្រួបបង្រួម UTXO នៃកាបូបរបស់អ្នកដោយដៃ</translation>
    </message>
    <message>
        <source>The preselected coins total amount does not cover the transaction target. Please allow other inputs to be automatically selected or include more coins manually</source>
        <translation type="unfinished">ចំនួនសរុបនៃកាក់ដែលបានជ្រើសរើសជាមុនមិនគ្របដណ្តប់លើគោលដៅប្រតិបត្តិការទេ។ សូមអនុញ្ញាតឱ្យធាតុបញ្ចូលផ្សេងទៀតត្រូវបានជ្រើសរើសដោយស្វ័យប្រវត្តិ ឬបញ្ចូលកាក់បន្ថែមទៀតដោយហត្ថកម្</translation>
    </message>
    <message>
        <source>Disk space is too low!</source>
        <translation type="unfinished">ទំហំឌីស មានកំរិតទាប</translation>
    </message>
    <message>
        <source>Done loading</source>
        <translation type="unfinished">បានធ្វើរួចរាល់ហើយ កំពុងបង្ហាញ</translation>
    </message>
    <message>
        <source>Error reading from database, shutting down.</source>
        <translation type="unfinished">បញ្ហា​ក្នុងការទទួលបានទិន្ន័យ​ ពីមូលដ្ឋានទិន្ន័យ ដូច្នេះកំពុងតែបិទ។</translation>
    </message>
    <message>
        <source>Failed to verify database</source>
        <translation type="unfinished">មិនបានជោគជ័យក្នុងការបញ្ចាក់ មូលដ្ឋានទិន្នន័យ</translation>
    </message>
    <message>
        <source>Insufficient funds</source>
        <translation type="unfinished">មូលនិធិមិនគ្រប់គ្រាន់</translation>
    </message>
    <message>
        <source>Invalid P2P permission: '%s'</source>
        <translation type="unfinished">ការអនុញ្ញាត P2P មិនត្រឹមត្រូវៈ​ '%s'</translation>
    </message>
    <message>
        <source>Invalid amount for -%s=&lt;amount&gt;: '%s'</source>
        <translation type="unfinished">ចំនួនមិនត្រឹមត្រូវសម្រាប់  -%s=&lt;amount&gt;: '%s'</translation>
    </message>
    <message>
        <source>Signing transaction failed</source>
        <translation type="unfinished">ប្រត្តិបត្តការចូល មិនជោគជ័យ</translation>
    </message>
    <message>
        <source>The transaction amount is too small to pay the fee</source>
        <translation type="unfinished">ចំនួនប្រត្តិបត្តិការមានទឹកប្រាក់ទំហំតូចពេក សម្រាប់បង់ប្រាក់</translation>
    </message>
    <message>
        <source>The wallet will avoid paying less than the minimum relay fee.</source>
        <translation type="unfinished">ប្រត្តិបត្តិការមានខ្សែចង្វាក់រងចាំដើម្បីធ្វើការផ្ទៀងផ្ទាត់វែង</translation>
    </message>
    <message>
        <source>This is the minimum transaction fee you pay on every transaction.</source>
        <translation type="unfinished">នេះជាកម្រៃប្រត្តិបត្តិការតិចបំផុត អ្នកបង់រាល់ពេលធ្វើប្រត្តិបត្តិការម្តងៗ។</translation>
    </message>
    <message>
        <source>This is the transaction fee you will pay if you send a transaction.</source>
        <translation type="unfinished">នេះជាកម្រៃប្រត្តិបត្តិការ អ្នកនឹងបង់ប្រសិនបើអ្នកធ្វើប្រត្តិបត្តិការម្តង។</translation>
    </message>
    <message>
        <source>Transaction amount too small</source>
        <translation type="unfinished">ចំនួនប្រត្តិបត្តិការមានទឹកប្រាក់ទំហំតូច</translation>
    </message>
    <message>
        <source>Transaction amounts must not be negative</source>
        <translation type="unfinished">ចំនួនប្រត្តិបត្តិការ មិនអាចអវិជ្ជមានបានទេ</translation>
    </message>
    <message>
        <source>Transaction has too long of a mempool chain</source>
        <translation type="unfinished">ប្រត្តិបត្តិការមានខ្សែចង្វាក់រងចាំដើម្បីធ្វើការផ្ទៀងផ្ទាត់វែង</translation>
    </message>
    <message>
        <source>Transaction must have at least one recipient</source>
        <translation type="unfinished">ប្រត្តិបត្តិការត្រូវមានអ្នកទទួលម្នាក់យ៉ាងតិចបំផុត</translation>
    </message>
    <message>
        <source>Transaction too large</source>
        <translation type="unfinished">ប្រត្តិបត្តការទឹកប្រាក់ មានទំហំធំ</translation>
    </message>
    <message>
        <source>Settings file could not be read</source>
        <translation type="unfinished">ការកំណត់ឯកសារមិនអាចអានបានទេ។</translation>
    </message>
    <message>
        <source>Settings file could not be written</source>
        <translation type="unfinished">ការកំណត់ឯកសារមិនអាចសរសេរបានទេ។</translation>
    </message>
</context>
</TS>