<TS version="2.1" language="uz">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Right-click to edit address or label</source>
        <translation type="unfinished">Manzil yoki yorliqni o'zgartirish uchun o'ng tugmani bosing</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation type="unfinished">Yangi manzil yarating</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation type="unfinished">&amp;Yangi</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation type="unfinished">Tanlangan manzilni tizim vaqtinchalik hotirasida saqlash</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation type="unfinished">&amp;Nusxalash</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation type="unfinished">Y&amp;opish</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation type="unfinished">Tanlangan manzilni ro'yhatdan o'chiring</translation>
    </message>
    <message>
        <source>Enter address or label to search</source>
        <translation type="unfinished">Qidirish uchun manzil yoki yorliqni kiriting</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation type="unfinished">Joriy ichki oynaning ichidagi malumotlarni faylga yuklab olish</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation type="unfinished">o'chirish</translation>
    </message>
    <message>
        <source>Choose the address to send coins to</source>
        <translation type="unfinished">Tangalarni jo'natish uchun addressni tanlash</translation>
    </message>
    <message>
        <source>Choose the address to receive coins with</source>
        <translation type="unfinished">Tangalarni qabul qilib olish uchun manzilni tanlang</translation>
    </message>
    <message>
        <source>C&amp;hoose</source>
        <translation type="unfinished">tanlamoq</translation>
    </message>
    <message>
        <source>Sending addresses</source>
        <translation type="unfinished">Yuboriladigan manzillar</translation>
    </message>
    <message>
        <source>Receiving addresses</source>
        <translation type="unfinished">Qabul qilinadigan manzillar</translation>
    </message>
    <message>
        <source>These are your Kawra addresses for sending payments. Always check the amount and the receiving address before sending coins.</source>
        <translation type="unfinished">Quyidagilar to'lovlarni yuborish uchun Kawra manzillaringizdir. Har doim yuborishdan oldin yuborilayotgan tangalar sonini va qabul qiluvchi manzilni tekshirib ko'ring.</translation>
    </message>
    <message>
        <source>These are your Kawra addresses for receiving payments. Use the 'Create new receiving address' button in the receive tab to create new addresses.
Signing is only possible with addresses of the type 'legacy'.</source>
        <translation type="unfinished">Bular to'lovlarni qabul qilishingiz uchun sizning Kawra manzillaringizdir. Yangi qabul qiluvchi manzil yaratish uchun qabul qilish varag'idagi ''Yangi qabul qilish manzilini yaratish'' ustiga bosing. Faqat 'legacy' turdagi manzillar bilan xisobga kirish mumkin.</translation>
    </message>
    <message>
        <source>&amp;Copy Address</source>
        <translation type="unfinished">&amp;manzildan nusxa olish</translation>
    </message>
    <message>
        <source>Copy &amp;Label</source>
        <translation type="unfinished">Yorliqni ko'chirish</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation type="unfinished">O'zgartirmoq</translation>
    </message>
    <message>
        <source>Export Address List</source>
        <translation type="unfinished">Manzil ro'yhatini yuklab olish</translation>
    </message>
    <message>
        <source>Comma separated file</source>
        <extracomment>Expanded name of the CSV file format. See: https://en.wikipedia.org/wiki/Comma-separated_values.</extracomment>
        <translation type="unfinished">Vergul bilan ajratilgan fayl</translation>
    </message>
    <message>
        <source>There was an error trying to save the address list to %1. Please try again.</source>
        <extracomment>An error message. %1 is a stand-in argument for the name of the file we attempted to save to.</extracomment>
        <translation type="unfinished">Манзил рўйхатини %1.га сақлашда хатолик юз берди. Яна уриниб кўринг.</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation type="unfinished">Экспорт қилиб бўлмади</translation>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Label</source>
        <translation type="unfinished">Yorliq</translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="unfinished">Manzil</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(Ёрлиқ мавжуд эмас)</translation>
    </message>
</context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Passphrase Dialog</source>
        <translation type="unfinished">Maxfiy so'zlar dialogi</translation>
    </message>
    <message>
        <source>Enter passphrase</source>
        <translation type="unfinished">Махфий сўзни киритинг</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation type="unfinished">Yangi maxfiy so'z</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation type="unfinished">Yangi maxfiy so'zni qaytadan kirgizing</translation>
    </message>
    <message>
        <source>Show passphrase</source>
        <translation type="unfinished">Maxfiy so'zni ko'rsatish</translation>
    </message>
    <message>
        <source>Encrypt wallet</source>
        <translation type="unfinished">Ҳамённи шифрлаш</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation type="unfinished">Bu operatsiya hamyoningizni ochish uchun mo'ljallangan maxfiy so'zni talab qiladi.</translation>
    </message>
    <message>
        <source>Unlock wallet</source>
        <translation type="unfinished">Ҳамённи қулфдан чиқариш</translation>
    </message>
    <message>
        <source>Change passphrase</source>
        <translation type="unfinished">Махфий сузни узгартириш</translation>
    </message>
    <message>
        <source>Confirm wallet encryption</source>
        <translation type="unfinished">Hamyon shifrlanishini tasdiqlang</translation>
    </message>
    <message>
        <source>Warning: If you encrypt your wallet and lose your passphrase, you will &lt;b&gt;LOSE ALL OF YOUR KAWRAS&lt;/b&gt;!</source>
        <translation type="unfinished">Диққат: Агар сиз ҳамёнингизни кодласангиз ва махфий сўзингизни унутсангиз, сиз &lt;b&gt;БАРЧА KAWRA ПУЛЛАРИНГИЗНИ ЙЎҚОТАСИЗ&lt;/b&gt;!</translation>
    </message>
    <message>
        <source>Are you sure you wish to encrypt your wallet?</source>
        <translation type="unfinished">Haqiqatan ham hamyoningizni shifrlamoqchimisiz?</translation>
    </message>
    <message>
        <source>Wallet encrypted</source>
        <translation type="unfinished">Ҳамён шифрланган</translation>
    </message>
    <message>
        <source>Enter the new passphrase for the wallet.&lt;br/&gt;Please use a passphrase of &lt;b&gt;ten or more random characters&lt;/b&gt;, or &lt;b&gt;eight or more words&lt;/b&gt;.</source>
        <translation type="unfinished">Hamyon uchun yangi maxfiy so'zni kiriting. &lt;br/&gt;Iltimos, &lt;b&gt;10 va undan ortiq istalgan&lt;/b&gt; yoki &lt;b&gt;8 va undan ortiq so'zlardan&lt;/b&gt; iborat maxfiy so'zdan foydalaning.</translation>
    </message>
    <message>
        <source>Enter the old passphrase and new passphrase for the wallet.</source>
        <translation type="unfinished">Hamyonning oldingi va yangi maxfiy so'zlarini kiriting</translation>
    </message>
    <message>
        <source>Remember that encrypting your wallet cannot fully protect your kawras from being stolen by malware infecting your computer.</source>
        <translation type="unfinished">Shuni yodda tutingki, hamyonni shifrlash kompyuterdagi virus yoki zararli dasturlar sizning kawralaringizni o'g'irlashidan to'liq himoyalay olmaydi.</translation>
    </message>
    <message>
        <source>Wallet to be encrypted</source>
        <translation type="unfinished">Шифрланадиган ҳамён</translation>
    </message>
    <message>
        <source>Your wallet is about to be encrypted. </source>
        <translation type="unfinished">Ҳамёнингиз шифрланиш арафасида.</translation>
    </message>
    <message>
        <source>Your wallet is now encrypted. </source>
        <translation type="unfinished">Hamyoningiz shifrlangan</translation>
    </message>
    <message>
        <source>IMPORTANT: Any previous backups you have made of your wallet file should be replaced with the newly generated, encrypted wallet file. For security reasons, previous backups of the unencrypted wallet file will become useless as soon as you start using the new, encrypted wallet.</source>
        <translation type="unfinished">ESLATMA: Siz eski hamyoningiz joylashgan fayldan yaratgan kopiyalaringizni yangi shifrlangan hamyon fayliga almashtirishingiz lozim. Maxfiylik siyosati tufayli, yangi shifrlangan hamyondan foydalanishni boshlashingiz bilanoq eski nusxalar foydalanishga yaroqsiz holga keltiriladi.</translation>
    </message>
    <message>
        <source>Wallet encryption failed</source>
        <translation type="unfinished">Hamyon shifrlanishi muvaffaqiyatsiz amalga oshdi</translation>
    </message>
    <message>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation type="unfinished">Ichki xatolik tufayli hamyon shifrlanishi amalga oshmadi.</translation>
    </message>
    <message>
        <source>The supplied passphrases do not match.</source>
        <translation type="unfinished">Киритилган пароллар мос келмади.</translation>
    </message>
    <message>
        <source>Wallet unlock failed</source>
        <translation type="unfinished">Ҳамённи қулфдан чиқариш амалга ошмади</translation>
    </message>
    <message>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation type="unfinished">Noto'g'ri maxfiy so'z kiritildi</translation>
    </message>
    <message>
        <source>Wallet passphrase was successfully changed.</source>
        <translation type="unfinished">Ҳамён пароли муваффақиятли алмаштирилди.</translation>
    </message>
    <message>
        <source>Warning: The Caps Lock key is on!</source>
        <translation type="unfinished">Eslatma: Caps Lock tugmasi yoniq!</translation>
    </message>
</context>
<context>
    <name>BanTableModel</name>
    <message>
        <source>Banned Until</source>
        <translation type="unfinished">gacha kirish taqiqlanadi</translation>
    </message>
</context>
<context>
    <name>KawraApplication</name>
    <message>
        <source>Runaway exception</source>
        <translation type="unfinished">qo'shimcha istisno</translation>
    </message>
    <message>
        <source>A fatal error occurred. %1 can no longer continue safely and will quit.</source>
        <translation type="unfinished">Fatal xatolik yuz berdi. %1 xavfsiz ravishda davom eta olmaydi va tizimni tark etadi. </translation>
    </message>
    <message>
        <source>Internal error</source>
        <translation type="unfinished">Ichki xatolik</translation>
    </message>
    <message>
        <source>An internal error occurred. %1 will attempt to continue safely. This is an unexpected bug which can be reported as described below.</source>
        <translation type="unfinished">Ichki xatolik yuzaga keldi. %1 xavfsiz protsessni davom ettirishga harakat qiladi. Bu kutilmagan xato boʻlib, uni quyida tavsiflanganidek xabar qilish mumkin.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Do you want to reset settings to default values, or to abort without making changes?</source>
        <extracomment>Explanatory text shown on startup when the settings file cannot be read. Prompts user to make a choice between resetting or aborting.</extracomment>
        <translation type="unfinished">Sozlamalarni asliga qaytarishni xohlaysizmi yoki o'zgartirishlar saqlanmasinmi?</translation>
    </message>
    <message>
        <source>A fatal error occurred. Check that settings file is writable, or try running with -nosettings.</source>
        <extracomment>Explanatory text shown on startup when the settings file could not be written. Prompts user to check that we have the ability to write to the file. Explains that the user has the option of running without a settings file.</extracomment>
        <translation type="unfinished">Fatal xatolik yuz berdi. Sozlamalar fayli tahrirlashga yaroqliligini tekshiring yoki -nosettings bilan davom etishga harakat qiling.</translation>
    </message>
    <message>
        <source>Error: %1</source>
        <translation type="unfinished">Xatolik: %1</translation>
    </message>
    <message>
        <source>%1 didn't yet exit safely…</source>
        <translation type="unfinished">%1 hali tizimni xavfsiz ravishda tark etgani yo'q...</translation>
    </message>
    <message>
        <source>unknown</source>
        <translation type="unfinished">noma'lum</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">Miqdor</translation>
    </message>
    <message>
        <source>Enter a Kawra address (e.g. %1)</source>
        <translation type="unfinished">Kawra манзилини киритинг (масалан.  %1)</translation>
    </message>
    <message>
        <source>Inbound</source>
        <extracomment>An inbound connection from a peer. An inbound connection is a connection initiated by a peer.</extracomment>
        <translation type="unfinished">Ички йўналиш</translation>
    </message>
    <message>
        <source>Outbound</source>
        <extracomment>An outbound connection to a peer. An outbound connection is a connection initiated by us.</extracomment>
        <translation type="unfinished">Ташқи йўналиш</translation>
    </message>
    <message>
        <source>%1 m</source>
        <translation type="unfinished">%1 д</translation>
    </message>
    <message>
        <source>%1 s</source>
        <translation type="unfinished">%1 с</translation>
    </message>
    <message>
        <source>None</source>
        <translation type="unfinished">Йўқ</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation type="unfinished">Тўғри келмайди</translation>
    </message>
    <message>
        <source>%1 ms</source>
        <translation type="unfinished">%1 мс</translation>
    </message>
    <message numerus="yes">
        <source>%n second(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n minute(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n hour(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n day(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n week(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message>
        <source>%1 and %2</source>
        <translation type="unfinished">%1 ва %2</translation>
    </message>
    <message numerus="yes">
        <source>%n year(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message>
        <source>%1 B</source>
        <translation type="unfinished">%1 Б</translation>
    </message>
    <message>
        <source>%1 MB</source>
        <translation type="unfinished">%1 МБ</translation>
    </message>
    <message>
        <source>%1 GB</source>
        <translation type="unfinished">%1 ГБ</translation>
    </message>
</context>
<context>
    <name>KawraGUI</name>
    <message>
        <source>&amp;Overview</source>
        <translation type="unfinished">&amp;Umumiy ko'rinish</translation>
    </message>
    <message>
        <source>Show general overview of wallet</source>
        <translation type="unfinished">Hamyonning umumiy ko'rinishini ko'rsatish</translation>
    </message>
    <message>
        <source>&amp;Transactions</source>
        <translation type="unfinished">&amp;Tranzaksiyalar</translation>
    </message>
    <message>
        <source>Browse transaction history</source>
        <translation type="unfinished">Tranzaksiyalar tarixini ko'rib chiqish</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation type="unfinished">Chi&amp;qish</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation type="unfinished">Dasturni tark etish</translation>
    </message>
    <message>
        <source>&amp;About %1</source>
        <translation type="unfinished">&amp;%1 haqida</translation>
    </message>
    <message>
        <source>Show information about %1</source>
        <translation type="unfinished">%1 haqida axborotni ko'rsatish</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation type="unfinished">&amp;Qt haqida</translation>
    </message>
    <message>
        <source>Show information about Qt</source>
        <translation type="unfinished">&amp;Qt haqidagi axborotni ko'rsatish</translation>
    </message>
    <message>
        <source>Modify configuration options for %1</source>
        <translation type="unfinished">%1 konfiguratsiya sozlamalarini o'zgartirish</translation>
    </message>
    <message>
        <source>Create a new wallet</source>
        <translation type="unfinished">Yangi hamyon yaratish</translation>
    </message>
    <message>
        <source>&amp;Minimize</source>
        <translation type="unfinished">&amp;Kichraytirish</translation>
    </message>
    <message>
        <source>Wallet:</source>
        <translation type="unfinished">Hamyon</translation>
    </message>
    <message>
        <source>Network activity disabled.</source>
        <extracomment>A substring of the tooltip.</extracomment>
        <translation type="unfinished">Mobil tarmoq faoliyati o'chirilgan</translation>
    </message>
    <message>
        <source>Proxy is &lt;b&gt;enabled&lt;/b&gt;: %1</source>
        <translation type="unfinished">Proksi &lt;b&gt;yoqildi&lt;/b&gt;: %1</translation>
    </message>
    <message>
        <source>Send coins to a Kawra address</source>
        <translation type="unfinished">Bitkoin manziliga coinlarni yuborish</translation>
    </message>
    <message>
        <source>Backup wallet to another location</source>
        <translation type="unfinished">Hamyon nusxasini boshqa joyga</translation>
    </message>
    <message>
        <source>Change the passphrase used for wallet encryption</source>
        <translation type="unfinished">Hamyon shifrlanishi uchun ishlatilgan maxfiy so'zni almashtirish</translation>
    </message>
    <message>
        <source>&amp;Send</source>
        <translation type="unfinished">&amp;Yuborish</translation>
    </message>
    <message>
        <source>&amp;Receive</source>
        <translation type="unfinished">&amp;Qabul qilish</translation>
    </message>
    <message>
        <source>&amp;Options…</source>
        <translation type="unfinished">&amp;Sozlamalar...</translation>
    </message>
    <message>
        <source>&amp;Encrypt Wallet…</source>
        <translation type="unfinished">&amp;Hamyonni shifrlash...</translation>
    </message>
    <message>
        <source>Encrypt the private keys that belong to your wallet</source>
        <translation type="unfinished">Hamyonga tegishli bo'lgan maxfiy so'zlarni shifrlash</translation>
    </message>
    <message>
        <source>&amp;Backup Wallet…</source>
        <translation type="unfinished">&amp;Hamyon nusxasi...</translation>
    </message>
    <message>
        <source>&amp;Change Passphrase…</source>
        <translation type="unfinished">&amp;Maxfiy so'zni o'zgartirish...</translation>
    </message>
    <message>
        <source>Sign &amp;message…</source>
        <translation type="unfinished">Xabarni &amp;signlash...</translation>
    </message>
    <message>
        <source>Sign messages with your Kawra addresses to prove you own them</source>
        <translation type="unfinished">Bitkoin manzillarga ega ekaningizni tasdiqlash uchun xabarni signlang</translation>
    </message>
    <message>
        <source>&amp;Verify message…</source>
        <translation type="unfinished">&amp;Xabarni tasdiqlash...</translation>
    </message>
    <message>
        <source>Verify messages to ensure they were signed with specified Kawra addresses</source>
        <translation type="unfinished">Xabar belgilangan Bitkoin manzillari bilan imzolanganligiga ishonch hosil qilish uchun ularni tasdiqlang</translation>
    </message>
    <message>
        <source>&amp;Load PSBT from file…</source>
        <translation type="unfinished">&amp;PSBT ni fayldan yuklash...</translation>
    </message>
    <message>
        <source>Open &amp;URI…</source>
        <translation type="unfinished">&amp;URL manzilni ochish</translation>
    </message>
    <message>
        <source>Close Wallet…</source>
        <translation type="unfinished">Hamyonni yopish</translation>
    </message>
    <message>
        <source>Create Wallet…</source>
        <translation type="unfinished">Hamyonni yaratish...</translation>
    </message>
    <message>
        <source>Close All Wallets…</source>
        <translation type="unfinished">Barcha hamyonlarni yopish...</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation type="unfinished">&amp;Fayl</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation type="unfinished">&amp;Sozlamalar</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation type="unfinished">&amp;Yordam</translation>
    </message>
    <message>
        <source>Tabs toolbar</source>
        <translation type="unfinished">Yorliqlar menyusi</translation>
    </message>
    <message>
        <source>Syncing Headers (%1%)…</source>
        <translation type="unfinished">Sarlavhalar sinxronlashtirilmoqda (%1%)...</translation>
    </message>
    <message>
        <source>Synchronizing with network…</source>
        <translation type="unfinished">Internet bilan sinxronlash...</translation>
    </message>
    <message>
        <source>Indexing blocks on disk…</source>
        <translation type="unfinished">Diskdagi bloklarni indekslash...</translation>
    </message>
    <message>
        <source>Processing blocks on disk…</source>
        <translation type="unfinished">Diskdagi bloklarni protsesslash...</translation>
    </message>
    <message>
        <source>Connecting to peers…</source>
        <translation type="unfinished">Pirlarga ulanish...</translation>
    </message>
    <message>
        <source>Request payments (generates QR codes and kawra: URIs)</source>
        <translation type="unfinished">Тўловлар (QR кодлари ва kawra ёрдамида яратишлар: URI’лар) сўраш</translation>
    </message>
    <message>
        <source>Show the list of used sending addresses and labels</source>
        <translation type="unfinished">Фойдаланилган жўнатилган манзиллар ва ёрлиқлар рўйхатини кўрсатиш</translation>
    </message>
    <message>
        <source>Show the list of used receiving addresses and labels</source>
        <translation type="unfinished">Фойдаланилган қабул қилинган манзиллар ва ёрлиқлар рўйхатини кўрсатиш</translation>
    </message>
    <message>
        <source>&amp;Command-line options</source>
        <translation type="unfinished">&amp;Буйруқлар сатри мосламалари</translation>
    </message>
    <message numerus="yes">
        <source>Processed %n block(s) of transaction history.</source>
        <translation type="unfinished">
            <numerusform>Tranzaksiya tarixining %n blok(lar)i qayta ishlandi.</numerusform>
            <numerusform />
        </translation>
    </message>
    <message>
        <source>%1 behind</source>
        <translation type="unfinished">%1 орқада</translation>
    </message>
    <message>
        <source>Catching up…</source>
        <translation type="unfinished">Yetkazilmoqda...</translation>
    </message>
    <message>
        <source>Last received block was generated %1 ago.</source>
        <translation type="unfinished">Сўнги қабул қилинган блок %1 олдин яратилган.</translation>
    </message>
    <message>
        <source>Transactions after this will not yet be visible.</source>
        <translation type="unfinished">Бундан кейинги пул ўтказмалари кўринмайдиган бўлади.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">Хатолик</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation type="unfinished">Диққат</translation>
    </message>
    <message>
        <source>Information</source>
        <translation type="unfinished">Маълумот</translation>
    </message>
    <message>
        <source>Up to date</source>
        <translation type="unfinished">Янгиланган</translation>
    </message>
    <message>
        <source>Load Partially Signed Kawra Transaction</source>
        <translation type="unfinished">Qisman signlangan Bitkoin tranzaksiyasini yuklash</translation>
    </message>
    <message>
        <source>Load PSBT from &amp;clipboard…</source>
        <translation type="unfinished">&amp;Nusxalanganlar dan PSBT ni yuklash</translation>
    </message>
    <message>
        <source>Load Partially Signed Kawra Transaction from clipboard</source>
        <translation type="unfinished">Nusxalanganlar qisman signlangan Bitkoin tranzaksiyalarini yuklash</translation>
    </message>
    <message>
        <source>Node window</source>
        <translation type="unfinished">Node oynasi</translation>
    </message>
    <message>
        <source>Open node debugging and diagnostic console</source>
        <translation type="unfinished">Node debuglash va tahlil konsolini ochish</translation>
    </message>
    <message>
        <source>&amp;Sending addresses</source>
        <translation type="unfinished">&amp;Yuborish manzillari</translation>
    </message>
    <message>
        <source>&amp;Receiving addresses</source>
        <translation type="unfinished">&amp;Qabul qilish manzillari</translation>
    </message>
    <message>
        <source>Open a kawra: URI</source>
        <translation type="unfinished">Bitkoinni ochish: URI</translation>
    </message>
    <message>
        <source>Open Wallet</source>
        <translation type="unfinished">Ochiq hamyon</translation>
    </message>
    <message>
        <source>Open a wallet</source>
        <translation type="unfinished">Hamyonni ochish</translation>
    </message>
    <message>
        <source>Close wallet</source>
        <translation type="unfinished">Hamyonni yopish</translation>
    </message>
    <message>
        <source>Close all wallets</source>
        <translation type="unfinished">Barcha hamyonlarni yopish</translation>
    </message>
    <message>
        <source>Show the %1 help message to get a list with possible Kawra command-line options</source>
        <translation type="unfinished">Yozilishi mumkin bo'lgan command-line sozlamalar ro'yxatini olish uchun %1 yordam xabarini ko'rsatish</translation>
    </message>
    <message>
        <source>Mask the values in the Overview tab</source>
        <translation type="unfinished">Umumiy ko'rinish menyusidagi qiymatlarni maskirovka qilish</translation>
    </message>
    <message>
        <source>default wallet</source>
        <translation type="unfinished">standart hamyon</translation>
    </message>
    <message>
        <source>No wallets available</source>
        <translation type="unfinished">Hamyonlar mavjud emas</translation>
    </message>
    <message>
        <source>Wallet Name</source>
        <extracomment>Label of the input field where the name of the wallet is entered.</extracomment>
        <translation type="unfinished">Hamyon nomi</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation type="unfinished">&amp;Oyna</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation type="unfinished">Kattalashtirish</translation>
    </message>
    <message>
        <source>Main Window</source>
        <translation type="unfinished">Asosiy Oyna</translation>
    </message>
    <message>
        <source>%1 client</source>
        <translation type="unfinished">%1 mijoz </translation>
    </message>
    <message>
        <source>&amp;Hide</source>
        <translation type="unfinished">&amp;Yashirish</translation>
    </message>
    <message>
        <source>S&amp;how</source>
        <translation type="unfinished">Ko'&amp;rsatish</translation>
    </message>
    <message numerus="yes">
        <source>%n active connection(s) to Kawra network.</source>
        <extracomment>A substring of the tooltip.</extracomment>
        <translation type="unfinished">
            <numerusform>Bitkoin tarmog'iga %n aktiv ulanishlar.</numerusform>
            <numerusform />
        </translation>
    </message>
    <message>
        <source>Click for more actions.</source>
        <extracomment>A substring of the tooltip. "More actions" are available via the context menu.</extracomment>
        <translation type="unfinished">Ko'proq sozlamalar uchun bosing.</translation>
    </message>
    <message>
        <source>Show Peers tab</source>
        <extracomment>A context menu item. The "Peers tab" is an element of the "Node window".</extracomment>
        <translation type="unfinished">Pirlar oynasini ko'rsatish</translation>
    </message>
    <message>
        <source>Disable network activity</source>
        <extracomment>A context menu item.</extracomment>
        <translation type="unfinished">Ijtimoiy tarmoq faoliyatini cheklash</translation>
    </message>
    <message>
        <source>Enable network activity</source>
        <extracomment>A context menu item. The network activity was disabled previously.</extracomment>
        <translation type="unfinished">Ijtimoiy tarmoq faoliyatini yoqish</translation>
    </message>
    <message>
        <source>Error: %1</source>
        <translation type="unfinished">Xatolik: %1</translation>
    </message>
    <message>
        <source>Warning: %1</source>
        <translation type="unfinished">Ogohlantirish: %1</translation>
    </message>
    <message>
        <source>Date: %1
</source>
        <translation type="unfinished">Sana: %1</translation>
    </message>
    <message>
        <source>Amount: %1
</source>
        <translation type="unfinished">Miqdor: %1
</translation>
    </message>
    <message>
        <source>Wallet: %1
</source>
        <translation type="unfinished">Hamyon: %1
</translation>
    </message>
    <message>
        <source>Type: %1
</source>
        <translation type="unfinished">Tip: %1
</translation>
    </message>
    <message>
        <source>Label: %1
</source>
        <translation type="unfinished">Yorliq: %1
</translation>
    </message>
    <message>
        <source>Address: %1
</source>
        <translation type="unfinished">Manzil: %1
</translation>
    </message>
    <message>
        <source>Sent transaction</source>
        <translation type="unfinished">Yuborilgan tranzaksiya</translation>
    </message>
    <message>
        <source>Incoming transaction</source>
        <translation type="unfinished">Kelayotgan tranzaksiya</translation>
    </message>
    <message>
        <source>HD key generation is &lt;b&gt;enabled&lt;/b&gt;</source>
        <translation type="unfinished">HD kalit yaratish &lt;b&gt;imkonsiz&lt;/b&gt;</translation>
    </message>
    <message>
        <source>HD key generation is &lt;b&gt;disabled&lt;/b&gt;</source>
        <translation type="unfinished">HD kalit yaratish &lt;b&gt;imkonsiz&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Private key &lt;b&gt;disabled&lt;/b&gt;</source>
        <translation type="unfinished">Maxfiy kalit &lt;b&gt;o'chiq&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation type="unfinished">Hamyon &lt;b&gt;shifrlangan&lt;/b&gt; va hozircha &lt;b&gt;ochiq&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation type="unfinished">Hamyon &lt;b&gt;shifrlangan&lt;/b&gt; va hozirda&lt;b&gt;qulflangan&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Original message:</source>
        <translation type="unfinished">Asl xabar:</translation>
    </message>
</context>
<context>
    <name>UnitDisplayStatusBarControl</name>
    <message>
        <source>Unit to show amounts in. Click to select another unit.</source>
        <translation type="unfinished">Miqdorlarni ko'rsatish birligi. Boshqa birlik tanlash uchun bosing.</translation>
    </message>
</context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Coin Selection</source>
        <translation type="unfinished">Coin tanlash</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation type="unfinished">Miqdor:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation type="unfinished">Baytlar:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation type="unfinished">Miqdor:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation type="unfinished">Солиқ:</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation type="unfinished">Ахлат қутиси:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation type="unfinished">To'lovdan keyin:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation type="unfinished">O'zgartirish:</translation>
    </message>
    <message>
        <source>(un)select all</source>
        <translation type="unfinished">hammasini(hech qaysini) tanlash</translation>
    </message>
    <message>
        <source>Tree mode</source>
        <translation type="unfinished">Daraxt rejimi</translation>
    </message>
    <message>
        <source>List mode</source>
        <translation type="unfinished">Ro'yxat rejimi</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">Miqdor</translation>
    </message>
    <message>
        <source>Received with label</source>
        <translation type="unfinished">Yorliq orqali qabul qilingan</translation>
    </message>
    <message>
        <source>Received with address</source>
        <translation type="unfinished">Manzil orqali qabul qilingan</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished">Сана</translation>
    </message>
    <message>
        <source>Confirmations</source>
        <translation type="unfinished">Tasdiqlar</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation type="unfinished">Tasdiqlangan</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation type="unfinished">Qiymatni nusxalash</translation>
    </message>
    <message>
        <source>&amp;Copy address</source>
        <translation type="unfinished">&amp;Manzilni nusxalash</translation>
    </message>
    <message>
        <source>Copy &amp;label</source>
        <translation type="unfinished">&amp;Yorliqni nusxalash</translation>
    </message>
    <message>
        <source>Copy &amp;amount</source>
        <translation type="unfinished">&amp;Miqdorni nusxalash</translation>
    </message>
    <message>
        <source>Copy transaction &amp;ID and output index</source>
        <translation type="unfinished">Tranzaksiya &amp;IDsi ni va chiquvchi indeksni nusxalash</translation>
    </message>
    <message>
        <source>L&amp;ock unspent</source>
        <translation type="unfinished">Sarflanmagan miqdorlarni q&amp;ulflash</translation>
    </message>
    <message>
        <source>&amp;Unlock unspent</source>
        <translation type="unfinished">Sarflanmaqan tranzaksiyalarni &amp;qulfdan chiqarish</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation type="unfinished">Нусха сони</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation type="unfinished">Narxni nusxalash</translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation type="unfinished">Нусха солиқдан сўнг</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation type="unfinished">Нусха байти</translation>
    </message>
    <message>
        <source>Copy dust</source>
        <translation type="unfinished">'Dust' larni nusxalash</translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation type="unfinished">Нусха қайтими</translation>
    </message>
    <message>
        <source>(%1 locked)</source>
        <translation type="unfinished">(%1 qulflangan)</translation>
    </message>
    <message>
        <source>yes</source>
        <translation type="unfinished">ha</translation>
    </message>
    <message>
        <source>no</source>
        <translation type="unfinished">yo'q</translation>
    </message>
    <message>
        <source>This label turns red if any recipient receives an amount smaller than the current dust threshold.</source>
        <translation type="unfinished">Agar qabul qiluvchi joriy 'dust' chegarasidan kichikroq miqdor olsa, bu yorliq qizil rangga aylanadi</translation>
    </message>
    <message>
        <source>Can vary +/- %1 satoshi(s) per input.</source>
        <translation type="unfinished">Har bir kiruvchi +/- %1  satoshiga farq qilishi mumkin.</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(Yorliqlar mavjud emas)</translation>
    </message>
    <message>
        <source>change from %1 (%2)</source>
        <translation type="unfinished">%1(%2) dan o'zgartirish</translation>
    </message>
    <message>
        <source>(change)</source>
        <translation type="unfinished">(o'zgartirish)</translation>
    </message>
</context>
<context>
    <name>CreateWalletActivity</name>
    <message>
        <source>Create Wallet</source>
        <extracomment>Title of window indicating the progress of creation of a new wallet.</extracomment>
        <translation type="unfinished">Hamyon yaratish</translation>
    </message>
    <message>
        <source>Creating Wallet &lt;b&gt;%1&lt;/b&gt;…</source>
        <extracomment>Descriptive text of the create wallet progress window which indicates to the user which wallet is currently being created.</extracomment>
        <translation type="unfinished">Hamyon yaratilmoqda &lt;b&gt;%1&lt;/b&gt;...</translation>
    </message>
    <message>
        <source>Create wallet failed</source>
        <translation type="unfinished">Hamyon yaratilishi amalga oshmadi</translation>
    </message>
    <message>
        <source>Create wallet warning</source>
        <translation type="unfinished">Hamyon yaratish ogohlantirishi</translation>
    </message>
    <message>
        <source>Can't list signers</source>
        <translation type="unfinished">Signerlarni ro'yxat shakliga keltirib bo'lmaydi</translation>
    </message>
    </context>
<context>
    <name>LoadWalletsActivity</name>
    <message>
        <source>Load Wallets</source>
        <extracomment>Title of progress window which is displayed when wallets are being loaded.</extracomment>
        <translation type="unfinished">Hamyonni yuklash</translation>
    </message>
    <message>
        <source>Loading wallets…</source>
        <extracomment>Descriptive text of the load wallets progress window which indicates to the user that wallets are currently being loaded.</extracomment>
        <translation type="unfinished">Hamyonlar yuklanmoqda...</translation>
    </message>
</context>
<context>
    <name>OpenWalletActivity</name>
    <message>
        <source>Open wallet failed</source>
        <translation type="unfinished">Hamyonni ochib bo'lmaydi</translation>
    </message>
    <message>
        <source>Open wallet warning</source>
        <translation type="unfinished">Hamyonni ochish ogohlantirishi</translation>
    </message>
    <message>
        <source>default wallet</source>
        <translation type="unfinished">standart hamyon</translation>
    </message>
    <message>
        <source>Open Wallet</source>
        <extracomment>Title of window indicating the progress of opening of a wallet.</extracomment>
        <translation type="unfinished">Hamyonni ochish</translation>
    </message>
    <message>
        <source>Opening Wallet &lt;b&gt;%1&lt;/b&gt;…</source>
        <extracomment>Descriptive text of the open wallet progress window which indicates to the user which wallet is currently being opened.</extracomment>
        <translation type="unfinished">Hamyonni ochish &lt;b&gt;%1&lt;/b&gt;...</translation>
    </message>
</context>
<context>
    <name>WalletController</name>
    <message>
        <source>Close wallet</source>
        <translation type="unfinished">Hamyonni yopish</translation>
    </message>
    <message>
        <source>Are you sure you wish to close the wallet &lt;i&gt;%1&lt;/i&gt;?</source>
        <translation type="unfinished">Ushbu hamyonni&lt;i&gt;%1&lt;/i&gt; yopmoqchi ekaningizga ishonchingiz komilmi?</translation>
    </message>
    <message>
        <source>Closing the wallet for too long can result in having to resync the entire chain if pruning is enabled.</source>
        <translation type="unfinished">Agar 'pruning' funksiyasi o'chirilgan bo'lsa, hamyondan uzoq vaqt foydalanmaslik butun zanjirnni qayta sinxronlashga olib kelishi mumkin.</translation>
    </message>
    <message>
        <source>Close all wallets</source>
        <translation type="unfinished">Barcha hamyonlarni yopish</translation>
    </message>
    <message>
        <source>Are you sure you wish to close all wallets?</source>
        <translation type="unfinished">Hamma hamyonlarni yopmoqchimisiz?</translation>
    </message>
</context>
<context>
    <name>CreateWalletDialog</name>
    <message>
        <source>Create Wallet</source>
        <translation type="unfinished">Hamyon yaratish</translation>
    </message>
    <message>
        <source>Wallet Name</source>
        <translation type="unfinished">Hamyon nomi</translation>
    </message>
    <message>
        <source>Wallet</source>
        <translation type="unfinished">Ҳамён</translation>
    </message>
    <message>
        <source>Encrypt the wallet. The wallet will be encrypted with a passphrase of your choice.</source>
        <translation type="unfinished">Hamyonni shifrlash. Hamyon siz tanlagan maxfiy so'z bilan shifrlanadi</translation>
    </message>
    <message>
        <source>Encrypt Wallet</source>
        <translation type="unfinished">Hamyonni shifrlash</translation>
    </message>
    <message>
        <source>Advanced Options</source>
        <translation type="unfinished">Qo'shimcha sozlamalar</translation>
    </message>
    <message>
        <source>Disable private keys for this wallet. Wallets with private keys disabled will have no private keys and cannot have an HD seed or imported private keys. This is ideal for watch-only wallets.</source>
        <translation type="unfinished">Ushbu hamyon uchun maxfiy kalitlarni o'chirish. Maxfiy kalitsiz hamyonlar maxfiy kalitlar yoki import qilingan maxfiy kalitlar, shuningdek, HD seedlarga ega bo'la olmaydi.</translation>
    </message>
    <message>
        <source>Disable Private Keys</source>
        <translation type="unfinished">Maxfiy kalitlarni faolsizlantirish</translation>
    </message>
    <message>
        <source>Make a blank wallet. Blank wallets do not initially have private keys or scripts. Private keys and addresses can be imported, or an HD seed can be set, at a later time.</source>
        <translation type="unfinished">Bo'sh hamyon yaratish. Bo'sh hamyonlarga keyinchalik maxfiy kalitlar yoki manzillar import qilinishi mumkin, yana HD seedlar ham o'rnatilishi mumkin.</translation>
    </message>
    <message>
        <source>Make Blank Wallet</source>
        <translation type="unfinished">Bo'sh hamyon yaratish</translation>
    </message>
    <message>
        <source>Use descriptors for scriptPubKey management</source>
        <translation type="unfinished">scriptPubKey yaratishda izohlovchidan foydalanish</translation>
    </message>
    <message>
        <source>Descriptor Wallet</source>
        <translation type="unfinished">Izohlovchi hamyon</translation>
    </message>
    <message>
        <source>Use an external signing device such as a hardware wallet. Configure the external signer script in wallet preferences first.</source>
        <translation type="unfinished">Uskuna hamyoni kabi tashqi signing qurilmasidan foydalaning. Avval hamyon sozlamalarida tashqi signer skriptini sozlang.</translation>
    </message>
    <message>
        <source>External signer</source>
        <translation type="unfinished">Tashqi signer</translation>
    </message>
    <message>
        <source>Create</source>
        <translation type="unfinished">Yaratmoq</translation>
    </message>
    <message>
        <source>Compiled without sqlite support (required for descriptor wallets)</source>
        <translation type="unfinished">Sqlite yordamisiz tuzilgan (deskriptor hamyonlari uchun talab qilinadi)</translation>
    </message>
    <message>
        <source>Compiled without external signing support (required for external signing)</source>
        <extracomment>"External signing" means using devices such as hardware wallets.</extracomment>
        <translation type="unfinished">Tashqi signing yordamisiz tuzilgan (tashqi signing uchun zarur)</translation>
    </message>
</context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation type="unfinished">Манзилларни таҳрирлаш</translation>
    </message>
    <message>
        <source>&amp;Label</source>
        <translation type="unfinished">&amp;Ёрлик</translation>
    </message>
    <message>
        <source>The label associated with this address list entry</source>
        <translation type="unfinished">Ёрлиқ ушбу манзилар рўйхати ёзуви билан боғланган</translation>
    </message>
    <message>
        <source>The address associated with this address list entry. This can only be modified for sending addresses.</source>
        <translation type="unfinished">Манзил ушбу манзиллар рўйхати ёзуви билан боғланган. Уни фақат жўнатиладиган манзиллар учун ўзгартирса бўлади.</translation>
    </message>
    <message>
        <source>&amp;Address</source>
        <translation type="unfinished">&amp;Манзил</translation>
    </message>
    <message>
        <source>New sending address</source>
        <translation type="unfinished">Янги жунатилувчи манзил</translation>
    </message>
    <message>
        <source>Edit receiving address</source>
        <translation type="unfinished">Кабул килувчи манзилни тахрирлаш</translation>
    </message>
    <message>
        <source>Edit sending address</source>
        <translation type="unfinished">Жунатилувчи манзилни тахрирлаш</translation>
    </message>
    <message>
        <source>The entered address "%1" is not a valid Kawra address.</source>
        <translation type="unfinished">Киритилган "%1" манзили тўғри Kawra манзили эмас.</translation>
    </message>
    <message>
        <source>Address "%1" already exists as a receiving address with label "%2" and so cannot be added as a sending address.</source>
        <translation type="unfinished">Yuboruvchi(%1manzil) va  qabul qiluvchi(%2manzil) bir xil bo'lishi mumkin emas</translation>
    </message>
    <message>
        <source>The entered address "%1" is already in the address book with label "%2".</source>
        <translation type="unfinished">Kiritilgan %1manzil allaqachon %2yorlig'i bilan manzillar kitobida</translation>
    </message>
    <message>
        <source>Could not unlock wallet.</source>
        <translation type="unfinished">Ҳамён қулфдан чиқмади.</translation>
    </message>
    <message>
        <source>New key generation failed.</source>
        <translation type="unfinished">Янги калит яратиш амалга ошмади.</translation>
    </message>
</context>
<context>
    <name>FreespaceChecker</name>
    <message>
        <source>A new data directory will be created.</source>
        <translation type="unfinished">Янги маълумотлар директорияси яратилади.</translation>
    </message>
    <message>
        <source>name</source>
        <translation type="unfinished">номи</translation>
    </message>
    <message>
        <source>Directory already exists. Add %1 if you intend to create a new directory here.</source>
        <translation type="unfinished">Директория аллақачон мавжуд. Агар бу ерда янги директория яратмоқчи бўлсангиз, %1 қўшинг.</translation>
    </message>
    <message>
        <source>Path already exists, and is not a directory.</source>
        <translation type="unfinished">Йўл аллақачон мавжуд. У директория эмас.</translation>
    </message>
    <message>
        <source>Cannot create data directory here.</source>
        <translation type="unfinished">Маълумотлар директориясини бу ерда яратиб бўлмайди..</translation>
    </message>
</context>
<context>
    <name>Intro</name>
    <message numerus="yes">
        <source>%n GB of space available</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>(of %n GB needed)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>(%n GB needed for full chain)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message>
        <source>At least %1 GB of data will be stored in this directory, and it will grow over time.</source>
        <translation type="unfinished">Kamida %1 GB ma'lumot bu yerda saqlanadi va vaqtlar davomida o'sib boradi</translation>
    </message>
    <message>
        <source>Approximately %1 GB of data will be stored in this directory.</source>
        <translation type="unfinished">Bu katalogda %1  GB ma'lumot saqlanadi</translation>
    </message>
    <message numerus="yes">
        <source>(sufficient to restore backups %n day(s) old)</source>
        <extracomment>Explanatory text on the capability of the current prune target.</extracomment>
        <translation type="unfinished">
            <numerusform>(%n kun oldingi zaxira nusxalarini tiklash uchun etarli)</numerusform>
            <numerusform />
        </translation>
    </message>
    <message>
        <source>%1 will download and store a copy of the Kawra block chain.</source>
        <translation type="unfinished"> Kawra blok zanjirining%1 nusxasini yuklab oladi va saqlaydi</translation>
    </message>
    <message>
        <source>The wallet will also be stored in this directory.</source>
        <translation type="unfinished">Hamyon ham ushbu katalogda saqlanadi.</translation>
    </message>
    <message>
        <source>Error: Specified data directory "%1" cannot be created.</source>
        <translation type="unfinished">Хато: кўрсатилган "%1" маълумотлар директориясини яратиб бўлмайди.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">Хатолик</translation>
    </message>
    <message>
        <source>Welcome</source>
        <translation type="unfinished">Хуш келибсиз</translation>
    </message>
    <message>
        <source>Welcome to %1.</source>
        <translation type="unfinished">%1 ga xush kelibsiz</translation>
    </message>
    <message>
        <source>As this is the first time the program is launched, you can choose where %1 will store its data.</source>
        <translation type="unfinished">Birinchi marta dastur ishga tushirilganda, siz %1 o'z ma'lumotlarini qayerda saqlashini tanlashingiz mumkin</translation>
    </message>
    <message>
        <source>Limit block chain storage to</source>
        <translation type="unfinished">Blok zanjiri xotirasini bungacha cheklash:</translation>
    </message>
    <message>
        <source>Reverting this setting requires re-downloading the entire blockchain. It is faster to download the full chain first and prune it later. Disables some advanced features.</source>
        <translation type="unfinished">Bu sozlamani qaytarish butun blok zanjirini qayta yuklab olishni talab qiladi. Avval to'liq zanjirni yuklab olish va keyinroq kesish kamroq vaqt oladi. Ba'zi qo'shimcha funksiyalarni cheklaydi.</translation>
    </message>
    <message>
        <source> GB</source>
        <translation type="unfinished">GB</translation>
    </message>
    <message>
        <source>This initial synchronisation is very demanding, and may expose hardware problems with your computer that had previously gone unnoticed. Each time you run %1, it will continue downloading where it left off.</source>
        <translation type="unfinished">Ushbu dastlabki sinxronlash juda qiyin va kompyuteringiz bilan ilgari sezilmagan apparat muammolarini yuzaga keltirishi mumkin. Har safar %1 ni ishga tushirganingizda, u yuklab olish jarayonini qayerda to'xtatgan bo'lsa, o'sha yerdan boshlab davom ettiradi.</translation>
    </message>
    <message>
        <source>If you have chosen to limit block chain storage (pruning), the historical data must still be downloaded and processed, but will be deleted afterward to keep your disk usage low.</source>
        <translation type="unfinished">Agar siz blok zanjirini saqlashni cheklashni tanlagan bo'lsangiz (pruning), eski ma'lumotlar hali ham yuklab olinishi va qayta ishlanishi kerak, ammo diskdan kamroq foydalanish uchun keyin o'chiriladi.</translation>
    </message>
    <message>
        <source>Use the default data directory</source>
        <translation type="unfinished">Стандарт маълумотлар директориясидан фойдаланиш</translation>
    </message>
    <message>
        <source>Use a custom data directory:</source>
        <translation type="unfinished">Бошқа маълумотлар директориясида фойдаланинг:</translation>
    </message>
</context>
<context>
    <name>HelpMessageDialog</name>
    <message>
        <source>version</source>
        <translation type="unfinished">версияси</translation>
    </message>
    <message>
        <source>About %1</source>
        <translation type="unfinished">%1 haqida</translation>
    </message>
    <message>
        <source>Command-line options</source>
        <translation type="unfinished">Буйруқлар сатри мосламалари</translation>
    </message>
</context>
<context>
    <name>ShutdownWindow</name>
    <message>
        <source>%1 is shutting down…</source>
        <translation type="unfinished">%1 yopilmoqda...</translation>
    </message>
    <message>
        <source>Do not shut down the computer until this window disappears.</source>
        <translation type="unfinished">Bu oyna paydo bo'lmagunicha kompyuterni o'chirmang.</translation>
    </message>
</context>
<context>
    <name>ModalOverlay</name>
    <message>
        <source>Form</source>
        <translation type="unfinished">Шакл</translation>
    </message>
    <message>
        <source>Recent transactions may not yet be visible, and therefore your wallet's balance might be incorrect. This information will be correct once your wallet has finished synchronizing with the kawra network, as detailed below.</source>
        <translation type="unfinished">So'nggi tranzaksiyalar hali ko'rinmasligi mumkin, shuning uchun hamyoningiz balansi noto'g'ri ko'rinishi mumkin. Sizning hamyoningiz bitkoin tarmog'i bilan sinxronlashni tugatgandan so'ng, quyida batafsil tavsiflanganidek, bu ma'lumot to'g'rilanadi.</translation>
    </message>
    <message>
        <source>Attempting to spend kawras that are affected by not-yet-displayed transactions will not be accepted by the network.</source>
        <translation type="unfinished">Hali ko'rsatilmagan tranzaksiyalarga bitkoinlarni sarflashga urinish tarmoq tomonidan qabul qilinmaydi.</translation>
    </message>
    <message>
        <source>Number of blocks left</source>
        <translation type="unfinished">qolgan bloklar soni</translation>
    </message>
    <message>
        <source>Unknown…</source>
        <translation type="unfinished">Noma'lum...</translation>
    </message>
    <message>
        <source>calculating…</source>
        <translation type="unfinished">hisoblanmoqda...</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation type="unfinished">Сўнгги блок вақти</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation type="unfinished">O'sish</translation>
    </message>
    <message>
        <source>Progress increase per hour</source>
        <translation type="unfinished">Harakatning soatiga o'sishi</translation>
    </message>
    <message>
        <source>Estimated time left until synced</source>
        <translation type="unfinished">Sinxronizatsiya yakunlanishiga taxminan qolgan vaqt</translation>
    </message>
    <message>
        <source>Hide</source>
        <translation type="unfinished">Yashirmoq</translation>
    </message>
    <message>
        <source>%1 is currently syncing.  It will download headers and blocks from peers and validate them until reaching the tip of the block chain.</source>
        <translation type="unfinished">%1 sinxronlanmoqda. U pirlardan sarlavhalar va bloklarni yuklab oladi va ularni blok zanjirining uchiga yetguncha tasdiqlaydi.</translation>
    </message>
    <message>
        <source>Unknown. Syncing Headers (%1, %2%)…</source>
        <translation type="unfinished">Noma'lum. Sarlavhalarni sinxronlash(%1, %2%)...</translation>
    </message>
    </context>
<context>
    <name>OpenURIDialog</name>
    <message>
        <source>Open kawra URI</source>
        <translation type="unfinished">Bitkoin URI sini ochish</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <extracomment>Tooltip text for button that allows you to paste an address that is in your clipboard.</extracomment>
        <translation type="unfinished">Manzilni qo'shib qo'yish</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation type="unfinished">Sozlamalar</translation>
    </message>
    <message>
        <source>&amp;Main</source>
        <translation type="unfinished">&amp;Asosiy</translation>
    </message>
    <message>
        <source>Automatically start %1 after logging in to the system.</source>
        <translation type="unfinished">%1 ni sistemaga kirilishi bilanoq avtomatik ishga tushirish.</translation>
    </message>
    <message>
        <source>&amp;Start %1 on system login</source>
        <translation type="unfinished">%1 ni sistemaga kirish paytida &amp;ishga tushirish</translation>
    </message>
    <message>
        <source>Enabling pruning significantly reduces the disk space required to store transactions. All blocks are still fully validated. Reverting this setting requires re-downloading the entire blockchain.</source>
        <translation type="unfinished">Do'kon tranzaksiyalari katta xotira talab qilgani tufayli pruning ni yoqish sezilarli darajada xotirada joy kamayishiga olib keladi. Barcha bloklar hali ham to'liq tasdiqlangan. Bu sozlamani qaytarish butun blok zanjirini qayta yuklab olishni talab qiladi.</translation>
    </message>
    <message>
        <source>Size of &amp;database cache</source>
        <translation type="unfinished">&amp;Ma'lumotlar bazasi hajmi</translation>
    </message>
    <message>
        <source>Number of script &amp;verification threads</source>
        <translation type="unfinished">Skriptni &amp;tekshirish thread lari soni</translation>
    </message>
    <message>
        <source>IP address of the proxy (e.g. IPv4: 127.0.0.1 / IPv6: ::1)</source>
        <translation type="unfinished">Proksi IP manzili (masalan: IPv4: 127.0.0.1 / IPv6: ::1)</translation>
    </message>
    <message>
        <source>Shows if the supplied default SOCKS5 proxy is used to reach peers via this network type.</source>
        <translation type="unfinished">Taqdim etilgan standart SOCKS5 proksi-serveridan ushbu tarmoq turi orqali pirlar bilan bog‘lanish uchun foydalanilganini ko'rsatadi.</translation>
    </message>
    <message>
        <source>Minimize instead of exit the application when the window is closed. When this option is enabled, the application will be closed only after selecting Exit in the menu.</source>
        <translation type="unfinished">Oyna yopilganda dasturdan chiqish o'rniga minimallashtirish. Ushbu parametr yoqilganda, dastur faqat menyuda Chiqish ni tanlagandan keyin yopiladi.</translation>
    </message>
    <message>
        <source>Open the %1 configuration file from the working directory.</source>
        <translation type="unfinished">%1 konfiguratsion faylini ishlash katalogidan ochish.</translation>
    </message>
    <message>
        <source>Open Configuration File</source>
        <translation type="unfinished">Konfiguratsion faylni ochish</translation>
    </message>
    <message>
        <source>Reset all client options to default.</source>
        <translation type="unfinished">Barcha mijoz sozlamalarini asl holiga qaytarish.</translation>
    </message>
    <message>
        <source>&amp;Reset Options</source>
        <translation type="unfinished">Sozlamalarni &amp;qayta o'rnatish</translation>
    </message>
    <message>
        <source>&amp;Network</source>
        <translation type="unfinished">&amp;Internet tarmog'i</translation>
    </message>
    <message>
        <source>Prune &amp;block storage to</source>
        <translation type="unfinished">&amp;Blok xotirasini bunga kesish:</translation>
    </message>
    <message>
        <source>Reverting this setting requires re-downloading the entire blockchain.</source>
        <translation type="unfinished">Bu sozlamani qaytarish butun blok zanjirini qayta yuklab olishni talab qiladi.</translation>
    </message>
    <message>
        <source>Maximum database cache size. A larger cache can contribute to faster sync, after which the benefit is less pronounced for most use cases. Lowering the cache size will reduce memory usage. Unused mempool memory is shared for this cache.</source>
        <extracomment>Tooltip text for Options window setting that sets the size of the database cache. Explains the corresponding effects of increasing/decreasing this value.</extracomment>
        <translation type="unfinished">Ma'lumotlar bazasi keshining maksimal hajmi. Kattaroq kesh tezroq sinxronlashtirishga hissa qo'shishi mumkin, ya'ni foyda kamroq sezilishi mumkin.</translation>
    </message>
    <message>
        <source>Set the number of script verification threads. Negative values correspond to the number of cores you want to leave free to the system.</source>
        <extracomment>Tooltip text for Options window setting that sets the number of script verification threads. Explains that negative values mean to leave these many cores free to the system.</extracomment>
        <translation type="unfinished">Skriptni tekshirish ip lari sonini belgilang. </translation>
    </message>
    <message>
        <source>(0 = auto, &lt;0 = leave that many cores free)</source>
        <translation type="unfinished">(0 = avtomatik, &lt;0 = bu yadrolarni bo'sh qoldirish)</translation>
    </message>
    <message>
        <source>This allows you or a third party tool to communicate with the node through command-line and JSON-RPC commands.</source>
        <extracomment>Tooltip text for Options window setting that enables the RPC server.</extracomment>
        <translation type="unfinished">Bu sizga yoki uchinchi tomon vositasiga command-line va JSON-RPC buyruqlari orqali node bilan bog'lanish imkonini beradi.</translation>
    </message>
    <message>
        <source>Enable R&amp;PC server</source>
        <extracomment>An Options window setting to enable the RPC server.</extracomment>
        <translation type="unfinished">R&amp;PC serverni yoqish</translation>
    </message>
    <message>
        <source>W&amp;allet</source>
        <translation type="unfinished">H&amp;amyon</translation>
    </message>
    <message>
        <source>Whether to set subtract fee from amount as default or not.</source>
        <extracomment>Tooltip text for Options window setting that sets subtracting the fee from a sending amount as default.</extracomment>
        <translation type="unfinished">Chegirma to'lovini standart qilib belgilash kerakmi yoki yo'qmi?</translation>
    </message>
    <message>
        <source>Subtract &amp;fee from amount by default</source>
        <extracomment>An Options window setting to set subtracting the fee from a sending amount as default.</extracomment>
        <translation type="unfinished">Standart bo'yicha chegirma belgilash</translation>
    </message>
    <message>
        <source>Expert</source>
        <translation type="unfinished">Ekspert</translation>
    </message>
    <message>
        <source>Enable coin &amp;control features</source>
        <translation type="unfinished">Tangalarni &amp;nazorat qilish funksiyasini yoqish</translation>
    </message>
    <message>
        <source>Enable &amp;PSBT controls</source>
        <extracomment>An options window setting to enable PSBT controls.</extracomment>
        <translation type="unfinished">&amp;PSBT nazoratini yoqish</translation>
    </message>
    <message>
        <source>Whether to show PSBT controls.</source>
        <extracomment>Tooltip text for options window setting that enables PSBT controls.</extracomment>
        <translation type="unfinished">PSBT boshqaruvlarini ko'rsatish kerakmi?</translation>
    </message>
    <message>
        <source>External Signer (e.g. hardware wallet)</source>
        <translation type="unfinished">Tashqi Signer(masalan: hamyon apparati)</translation>
    </message>
    <message>
        <source>&amp;External signer script path</source>
        <translation type="unfinished">&amp;Tashqi signer skripti yo'li</translation>
    </message>
    <message>
        <source>Proxy &amp;IP:</source>
        <translation type="unfinished">Прокси &amp;IP рақами:</translation>
    </message>
    <message>
        <source>&amp;Port:</source>
        <translation type="unfinished">&amp;Порт:</translation>
    </message>
    <message>
        <source>Port of the proxy (e.g. 9050)</source>
        <translation type="unfinished">Прокси порти (e.g. 9050)</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation type="unfinished">&amp;Oyna</translation>
    </message>
    <message>
        <source>Show only a tray icon after minimizing the window.</source>
        <translation type="unfinished">Ойна йиғилгандан сўнг фақат трэй нишончаси кўрсатилсин.</translation>
    </message>
    <message>
        <source>&amp;Minimize to the tray instead of the taskbar</source>
        <translation type="unfinished">Манзиллар панели ўрнига трэйни &amp;йиғиш</translation>
    </message>
    <message>
        <source>M&amp;inimize on close</source>
        <translation type="unfinished">Ёпишда й&amp;иғиш</translation>
    </message>
    <message>
        <source>&amp;Display</source>
        <translation type="unfinished">&amp;Кўрсатиш</translation>
    </message>
    <message>
        <source>User Interface &amp;language:</source>
        <translation type="unfinished">Фойдаланувчи интерфейси &amp;тили:</translation>
    </message>
    <message>
        <source>&amp;Unit to show amounts in:</source>
        <translation type="unfinished">Миқдорларни кўрсатиш учун &amp;қисм:</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="unfinished">&amp;Бекор қилиш</translation>
    </message>
    <message>
        <source>Compiled without external signing support (required for external signing)</source>
        <extracomment>"External signing" means using devices such as hardware wallets.</extracomment>
        <translation type="unfinished">Tashqi signing yordamisiz tuzilgan (tashqi signing uchun zarur)</translation>
    </message>
    <message>
        <source>default</source>
        <translation type="unfinished">стандарт</translation>
    </message>
    <message>
        <source>none</source>
        <translation type="unfinished">йўқ</translation>
    </message>
    <message>
        <source>Confirm options reset</source>
        <extracomment>Window title text of pop-up window shown when the user has chosen to reset options.</extracomment>
        <translation type="unfinished">Тасдиқлаш танловларини рад қилиш</translation>
    </message>
    <message>
        <source>Client restart required to activate changes.</source>
        <extracomment>Text explaining that the settings changed will not come into effect until the client is restarted.</extracomment>
        <translation type="unfinished">Ўзгаришлар амалга ошиши учун мижозни қайта ишга тушириш талаб қилинади.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">Xatolik</translation>
    </message>
    <message>
        <source>This change would require a client restart.</source>
        <translation type="unfinished">Ушбу ўзгариш мижозни қайтадан ишга туширишни талаб қилади.</translation>
    </message>
    <message>
        <source>The supplied proxy address is invalid.</source>
        <translation type="unfinished">Келтирилган прокси манзили ишламайди.</translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Form</source>
        <translation type="unfinished">Шакл</translation>
    </message>
    <message>
        <source>The displayed information may be out of date. Your wallet automatically synchronizes with the Kawra network after a connection is established, but this process has not completed yet.</source>
        <translation type="unfinished">Кўрсатилган маълумот эскирган бўлиши мумкин. Ҳамёнингиз алоқа ўрнатилгандан сўнг Kawra тармоқ билан автоматик тарзда синхронланади, аммо жараён ҳалигача тугалланмади.</translation>
    </message>
    <message>
        <source>Watch-only:</source>
        <translation type="unfinished">Фақат кўришга</translation>
    </message>
    <message>
        <source>Available:</source>
        <translation type="unfinished">Мавжуд:</translation>
    </message>
    <message>
        <source>Your current spendable balance</source>
        <translation type="unfinished">Жорий сарфланадиган балансингиз</translation>
    </message>
    <message>
        <source>Pending:</source>
        <translation type="unfinished">Кутилмоқда:</translation>
    </message>
    <message>
        <source>Total of transactions that have yet to be confirmed, and do not yet count toward the spendable balance</source>
        <translation type="unfinished">Жами ўтказмалар ҳозиргача тасдиқланган ва сафланадиган баланс томонга ҳали ҳам ҳисобланмади</translation>
    </message>
    <message>
        <source>Immature:</source>
        <translation type="unfinished">Тайёр эмас:</translation>
    </message>
    <message>
        <source>Mined balance that has not yet matured</source>
        <translation type="unfinished">Миналаштирилган баланс ҳалигача тайёр эмас</translation>
    </message>
    <message>
        <source>Balances</source>
        <translation type="unfinished">Баланслар</translation>
    </message>
    <message>
        <source>Total:</source>
        <translation type="unfinished">Жами:</translation>
    </message>
    <message>
        <source>Your current total balance</source>
        <translation type="unfinished">Жорий умумий балансингиз</translation>
    </message>
    <message>
        <source>Your current balance in watch-only addresses</source>
        <translation type="unfinished">Жорий балансингиз фақат кўринадиган манзилларда</translation>
    </message>
    <message>
        <source>Spendable:</source>
        <translation type="unfinished">Сарфланадиган:</translation>
    </message>
    <message>
        <source>Recent transactions</source>
        <translation type="unfinished">Сўнгги пул ўтказмалари</translation>
    </message>
    <message>
        <source>Unconfirmed transactions to watch-only addresses</source>
        <translation type="unfinished">Тасдиқланмаган ўтказмалар-фақат манзилларини кўриш</translation>
    </message>
    <message>
        <source>Current total balance in watch-only addresses</source>
        <translation type="unfinished">Жорий умумий баланс фақат кўринадиган манзилларда</translation>
    </message>
    </context>
<context>
    <name>PSBTOperationsDialog</name>
    <message>
        <source>or</source>
        <translation type="unfinished">ёки</translation>
    </message>
    </context>
<context>
    <name>PaymentServer</name>
    <message>
        <source>Payment request error</source>
        <translation type="unfinished">Тўлов сўрови хато</translation>
    </message>
    <message>
        <source>URI handling</source>
        <translation type="unfinished">URI осилиб қолмоқда</translation>
    </message>
    </context>
<context>
    <name>PeerTableModel</name>
    <message>
        <source>User Agent</source>
        <extracomment>Title of Peers Table column which contains the peer's User Agent string.</extracomment>
        <translation type="unfinished">Фойдаланувчи вакил</translation>
    </message>
    <message>
        <source>Direction</source>
        <extracomment>Title of Peers Table column which indicates the direction the peer connection was initiated from.</extracomment>
        <translation type="unfinished">Йўналиш</translation>
    </message>
    <message>
        <source>Address</source>
        <extracomment>Title of Peers Table column which contains the IP/Onion/I2P address of the connected peer.</extracomment>
        <translation type="unfinished">Manzil</translation>
    </message>
    <message>
        <source>Type</source>
        <extracomment>Title of Peers Table column which describes the type of peer connection. The "type" describes why the connection exists.</extracomment>
        <translation type="unfinished">Тури</translation>
    </message>
    <message>
        <source>Network</source>
        <extracomment>Title of Peers Table column which states the network the peer connected through.</extracomment>
        <translation type="unfinished">Тармоқ</translation>
    </message>
    <message>
        <source>Inbound</source>
        <extracomment>An Inbound Connection from a Peer.</extracomment>
        <translation type="unfinished">Ички йўналиш</translation>
    </message>
    <message>
        <source>Outbound</source>
        <extracomment>An Outbound Connection to a Peer.</extracomment>
        <translation type="unfinished">Ташқи йўналиш</translation>
    </message>
</context>
<context>
    <name>QRImageWidget</name>
    <message>
        <source>&amp;Copy Image</source>
        <translation type="unfinished">Расмдан &amp;нусха олиш</translation>
    </message>
    <message>
        <source>Save QR Code</source>
        <translation type="unfinished">QR кодни сақлаш</translation>
    </message>
    </context>
<context>
    <name>RPCConsole</name>
    <message>
        <source>N/A</source>
        <translation type="unfinished">Тўғри келмайди</translation>
    </message>
    <message>
        <source>Client version</source>
        <translation type="unfinished">Мижоз номи</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation type="unfinished">&amp;Маълумот</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="unfinished">Асосий</translation>
    </message>
    <message>
        <source>Startup time</source>
        <translation type="unfinished">Бошланиш вақти</translation>
    </message>
    <message>
        <source>Network</source>
        <translation type="unfinished">Тармоқ</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished">Ном</translation>
    </message>
    <message>
        <source>&amp;Peers</source>
        <translation type="unfinished">&amp;Уламлар</translation>
    </message>
    <message>
        <source>Select a peer to view detailed information.</source>
        <translation type="unfinished">Батафсил маълумотларни кўриш учун уламни танланг.</translation>
    </message>
    <message>
        <source>Version</source>
        <translation type="unfinished">Версия</translation>
    </message>
    <message>
        <source>User Agent</source>
        <translation type="unfinished">Фойдаланувчи вакил</translation>
    </message>
    <message>
        <source>Node window</source>
        <translation type="unfinished">Node oynasi</translation>
    </message>
    <message>
        <source>Services</source>
        <translation type="unfinished">Хизматлар</translation>
    </message>
    <message>
        <source>Connection Time</source>
        <translation type="unfinished">Уланиш вақти</translation>
    </message>
    <message>
        <source>Last Send</source>
        <translation type="unfinished">Сўнгги жўнатилган</translation>
    </message>
    <message>
        <source>Last Receive</source>
        <translation type="unfinished">Сўнгги қабул қилинган</translation>
    </message>
    <message>
        <source>Ping Time</source>
        <translation type="unfinished">Ping вақти</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation type="unfinished">Oxirgi bloklash vaqti</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation type="unfinished">&amp;Очиш</translation>
    </message>
    <message>
        <source>&amp;Console</source>
        <translation type="unfinished">&amp;Терминал</translation>
    </message>
    <message>
        <source>&amp;Network Traffic</source>
        <translation type="unfinished">&amp;Тармоқ трафиги</translation>
    </message>
    <message>
        <source>Totals</source>
        <translation type="unfinished">Жами</translation>
    </message>
    <message>
        <source>Debug log file</source>
        <translation type="unfinished">Тузатиш журнали файли</translation>
    </message>
    <message>
        <source>Clear console</source>
        <translation type="unfinished">Терминални тозалаш</translation>
    </message>
    <message>
        <source>In:</source>
        <translation type="unfinished">Ичига:</translation>
    </message>
    <message>
        <source>Out:</source>
        <translation type="unfinished">Ташқарига:</translation>
    </message>
    <message>
        <source>&amp;Copy address</source>
        <extracomment>Context menu action to copy the address of a peer.</extracomment>
        <translation type="unfinished">&amp;Manzilni nusxalash</translation>
    </message>
    <message>
        <source>via %1</source>
        <translation type="unfinished">%1 орқали</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="unfinished">Ҳа</translation>
    </message>
    <message>
        <source>No</source>
        <translation type="unfinished">Йўқ</translation>
    </message>
    <message>
        <source>To</source>
        <translation type="unfinished">Га</translation>
    </message>
    <message>
        <source>From</source>
        <translation type="unfinished">Дан</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation type="unfinished">Номаълум</translation>
    </message>
</context>
<context>
    <name>ReceiveCoinsDialog</name>
    <message>
        <source>&amp;Amount:</source>
        <translation type="unfinished">&amp;Миқдор:</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation type="unfinished">&amp;Ёрлиқ:</translation>
    </message>
    <message>
        <source>&amp;Message:</source>
        <translation type="unfinished">&amp;Хабар:</translation>
    </message>
    <message>
        <source>An optional label to associate with the new receiving address.</source>
        <translation type="unfinished">Янги қабул қилинаётган манзил билан боғланган танланадиган ёрлиқ.</translation>
    </message>
    <message>
        <source>Use this form to request payments. All fields are &lt;b&gt;optional&lt;/b&gt;.</source>
        <translation type="unfinished">Ушбу сўровдан тўловларни сўраш учун фойдаланинг. Барча майдонлар &lt;b&gt;мажбурий эмас&lt;/b&gt;.</translation>
    </message>
    <message>
        <source>An optional amount to request. Leave this empty or zero to not request a specific amount.</source>
        <translation type="unfinished">Хоҳланган миқдор сўрови. Кўрсатилган миқдорни сўраш учун буни бўш ёки ноль қолдиринг.</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation type="unfinished">Шаклнинг барча майдончаларини тозалаш</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation type="unfinished">Тозалаш</translation>
    </message>
    <message>
        <source>Requested payments history</source>
        <translation type="unfinished">Сўралган тўлов тарихи</translation>
    </message>
    <message>
        <source>Show the selected request (does the same as double clicking an entry)</source>
        <translation type="unfinished">Танланган сўровни кўрсатиш (икки марта босилганда ҳам бир хил амал бажарилсин)</translation>
    </message>
    <message>
        <source>Show</source>
        <translation type="unfinished">Кўрсатиш</translation>
    </message>
    <message>
        <source>Remove the selected entries from the list</source>
        <translation type="unfinished">Танланганларни рўйхатдан ўчириш</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished">Ўчириш</translation>
    </message>
    <message>
        <source>&amp;Copy address</source>
        <translation type="unfinished">&amp;Manzilni nusxalash</translation>
    </message>
    <message>
        <source>Copy &amp;label</source>
        <translation type="unfinished">&amp;Yorliqni nusxalash</translation>
    </message>
    <message>
        <source>Copy &amp;amount</source>
        <translation type="unfinished">&amp;Miqdorni nusxalash</translation>
    </message>
    <message>
        <source>Could not unlock wallet.</source>
        <translation type="unfinished">Hamyonni ochish imkonsiz.</translation>
    </message>
    </context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>Amount:</source>
        <translation type="unfinished">Miqdor:</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation type="unfinished">Хабар</translation>
    </message>
    <message>
        <source>Wallet:</source>
        <translation type="unfinished">Hamyon</translation>
    </message>
    <message>
        <source>Copy &amp;Address</source>
        <translation type="unfinished">Нусҳалаш &amp; Манзил</translation>
    </message>
    <message>
        <source>Payment information</source>
        <translation type="unfinished">Тўлов маълумоти</translation>
    </message>
    <message>
        <source>Request payment to %1</source>
        <translation type="unfinished"> %1 дан Тўловни сўраш</translation>
    </message>
</context>
<context>
    <name>RecentRequestsTableModel</name>
    <message>
        <source>Date</source>
        <translation type="unfinished">Сана</translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished">Yorliq</translation>
    </message>
    <message>
        <source>Message</source>
        <translation type="unfinished">Хабар</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(Yorliqlar mavjud emas)</translation>
    </message>
    <message>
        <source>(no message)</source>
        <translation type="unfinished">(Хабар йўқ)</translation>
    </message>
    </context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Send Coins</source>
        <translation type="unfinished">Тангаларни жунат</translation>
    </message>
    <message>
        <source>Coin Control Features</source>
        <translation type="unfinished">Танга бошқаруви ҳусусиятлари</translation>
    </message>
    <message>
        <source>automatically selected</source>
        <translation type="unfinished">автоматик тарзда танланган</translation>
    </message>
    <message>
        <source>Insufficient funds!</source>
        <translation type="unfinished">Кам миқдор</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation type="unfinished">Miqdor:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation type="unfinished">Baytlar:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation type="unfinished">Miqdor:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation type="unfinished">Солиқ:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation type="unfinished">To'lovdan keyin:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation type="unfinished">O'zgartirish:</translation>
    </message>
    <message>
        <source>If this is activated, but the change address is empty or invalid, change will be sent to a newly generated address.</source>
        <translation type="unfinished">Агар бу фаоллаштирилса, аммо ўзгартирилган манзил бўл ёки нотўғри бўлса, ўзгариш янги яратилган манзилга жўнатилади.</translation>
    </message>
    <message>
        <source>Custom change address</source>
        <translation type="unfinished">Бошқа ўзгартирилган манзил</translation>
    </message>
    <message>
        <source>Transaction Fee:</source>
        <translation type="unfinished">Ўтказма тўлови</translation>
    </message>
    <message>
        <source>per kilobyte</source>
        <translation type="unfinished">Хар килобайтига</translation>
    </message>
    <message>
        <source>Hide</source>
        <translation type="unfinished">Yashirmoq</translation>
    </message>
    <message>
        <source>Recommended:</source>
        <translation type="unfinished">Тавсия этилган</translation>
    </message>
    <message>
        <source>Send to multiple recipients at once</source>
        <translation type="unfinished">Бирданига бир нечта қабул қилувчиларга жўнатиш</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation type="unfinished">Шаклнинг барча майдончаларини тозалаш</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation type="unfinished">Ахлат қутиси:</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation type="unfinished">Барчасини &amp; Тозалаш</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation type="unfinished">Баланс</translation>
    </message>
    <message>
        <source>Confirm the send action</source>
        <translation type="unfinished">Жўнатиш амалини тасдиқлаш</translation>
    </message>
    <message>
        <source>S&amp;end</source>
        <translation type="unfinished">Жў&amp;натиш</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation type="unfinished">Нусха сони</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation type="unfinished">Qiymatni nusxalash</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation type="unfinished">Narxni nusxalash</translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation type="unfinished">Нусха солиқдан сўнг</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation type="unfinished">Нусха байти</translation>
    </message>
    <message>
        <source>Copy dust</source>
        <translation type="unfinished">'Dust' larni nusxalash</translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation type="unfinished">Нусха қайтими</translation>
    </message>
    <message>
        <source>%1 to %2</source>
        <translation type="unfinished">%1 дан %2</translation>
    </message>
    <message>
        <source>or</source>
        <translation type="unfinished">ёки</translation>
    </message>
    <message>
        <source>Transaction fee</source>
        <translation type="unfinished">Ўтказма тўлови</translation>
    </message>
    <message>
        <source>Confirm send coins</source>
        <translation type="unfinished">Тангалар жўнаишни тасдиқлаш</translation>
    </message>
    <message>
        <source>The amount to pay must be larger than 0.</source>
        <translation type="unfinished">Тўлов миқдори 0. дан катта бўлиши керак. </translation>
    </message>
    <message numerus="yes">
        <source>Estimated to begin confirmation within %n block(s).</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message>
        <source>Warning: Invalid Kawra address</source>
        <translation type="unfinished">Диққат: Нотўғр Kawra манзили</translation>
    </message>
    <message>
        <source>Warning: Unknown change address</source>
        <translation type="unfinished">Диққат: Номаълум ўзгариш манзили</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(Yorliqlar mavjud emas)</translation>
    </message>
</context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>A&amp;mount:</source>
        <translation type="unfinished">&amp;Миқдори:</translation>
    </message>
    <message>
        <source>Pay &amp;To:</source>
        <translation type="unfinished">&amp;Тўлов олувчи:</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation type="unfinished">&amp;Ёрлиқ:</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation type="unfinished">Олдин фойдаланилган манзилни танла</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation type="unfinished">Manzilni qo'shib qo'yish</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation type="unfinished">Хабар</translation>
    </message>
    </context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>Choose previously used address</source>
        <translation type="unfinished">Олдин фойдаланилган манзилни танла</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation type="unfinished">Manzilni qo'shib qo'yish</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation type="unfinished">Имзо</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation type="unfinished">Барчасини &amp; Тозалаш</translation>
    </message>
    <message>
        <source>Message verified.</source>
        <translation type="unfinished">Хабар тасдиқланди.</translation>
    </message>
</context>
<context>
    <name>TransactionDesc</name>
    <message>
        <source>%1/unconfirmed</source>
        <extracomment>Text explaining the current status of a transaction, shown in the status field of the details window for this transaction. This status represents a transaction confirmed in at least one block, but less than 6 blocks.</extracomment>
        <translation type="unfinished">%1/тасдиқланмади</translation>
    </message>
    <message>
        <source>%1 confirmations</source>
        <extracomment>Text explaining the current status of a transaction, shown in the status field of the details window for this transaction. This status represents a transaction confirmed in 6 or more blocks.</extracomment>
        <translation type="unfinished">%1 тасдиқлашлар</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished">Сана</translation>
    </message>
    <message>
        <source>Source</source>
        <translation type="unfinished">Манба</translation>
    </message>
    <message>
        <source>Generated</source>
        <translation type="unfinished">Яратилган</translation>
    </message>
    <message>
        <source>From</source>
        <translation type="unfinished">Дан</translation>
    </message>
    <message>
        <source>unknown</source>
        <translation type="unfinished">noma'lum</translation>
    </message>
    <message>
        <source>To</source>
        <translation type="unfinished">Га</translation>
    </message>
    <message>
        <source>own address</source>
        <translation type="unfinished">ўз манзили</translation>
    </message>
    <message>
        <source>label</source>
        <translation type="unfinished">ёрлиқ</translation>
    </message>
    <message>
        <source>Credit</source>
        <translation type="unfinished">Кредит (қарз)</translation>
    </message>
    <message numerus="yes">
        <source>matures in %n more block(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message>
        <source>not accepted</source>
        <translation type="unfinished">қабул қилинмади</translation>
    </message>
    <message>
        <source>Transaction fee</source>
        <translation type="unfinished">Ўтказма тўлови</translation>
    </message>
    <message>
        <source>Net amount</source>
        <translation type="unfinished">Умумий миқдор</translation>
    </message>
    <message>
        <source>Message</source>
        <translation type="unfinished">Хабар</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation type="unfinished">Шарҳ</translation>
    </message>
    <message>
        <source>Transaction ID</source>
        <translation type="unfinished">ID</translation>
    </message>
    <message>
        <source>Merchant</source>
        <translation type="unfinished">Савдо</translation>
    </message>
    <message>
        <source>Transaction</source>
        <translation type="unfinished">Ўтказма</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">Miqdor</translation>
    </message>
    <message>
        <source>true</source>
        <translation type="unfinished">рост</translation>
    </message>
    <message>
        <source>false</source>
        <translation type="unfinished">ёлғон</translation>
    </message>
</context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <source>This pane shows a detailed description of the transaction</source>
        <translation type="unfinished">Ушбу ойна операциянинг батафсил таърифини кўрсатади</translation>
    </message>
    </context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Date</source>
        <translation type="unfinished">Сана</translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished">Тури</translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished">Yorliq</translation>
    </message>
    <message>
        <source>Unconfirmed</source>
        <translation type="unfinished">Тасдиқланмаган</translation>
    </message>
    <message>
        <source>Confirmed (%1 confirmations)</source>
        <translation type="unfinished">Тасдиқланди (%1 та тасдиқ)</translation>
    </message>
    <message>
        <source>Generated but not accepted</source>
        <translation type="unfinished">Яратилди, аммо қабул қилинмади</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation type="unfinished">Ёрдамида қабул қилиш</translation>
    </message>
    <message>
        <source>Received from</source>
        <translation type="unfinished">Дан қабул қилиш</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation type="unfinished">Жўнатиш</translation>
    </message>
    <message>
        <source>Payment to yourself</source>
        <translation type="unfinished">Ўзингизга тўлов</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation type="unfinished">Фойда</translation>
    </message>
    <message>
        <source>(n/a)</source>
        <translation type="unfinished">(қ/қ)</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(Yorliqlar mavjud emas)</translation>
    </message>
    <message>
        <source>Transaction status. Hover over this field to show number of confirmations.</source>
        <translation type="unfinished">Ўтказма ҳолати. Ушбу майдон бўйлаб тасдиқлашлар сонини кўрсатиш.</translation>
    </message>
    <message>
        <source>Date and time that the transaction was received.</source>
        <translation type="unfinished">Ўтказма қабул қилинган сана ва вақт.</translation>
    </message>
    <message>
        <source>Type of transaction.</source>
        <translation type="unfinished">Пул ўтказмаси тури</translation>
    </message>
    <message>
        <source>Amount removed from or added to balance.</source>
        <translation type="unfinished">Миқдор ўчирилган ёки балансга қўшилган.</translation>
    </message>
</context>
<context>
    <name>TransactionView</name>
    <message>
        <source>All</source>
        <translation type="unfinished">Барча</translation>
    </message>
    <message>
        <source>Today</source>
        <translation type="unfinished">Бугун</translation>
    </message>
    <message>
        <source>This week</source>
        <translation type="unfinished">Шу ҳафта</translation>
    </message>
    <message>
        <source>This month</source>
        <translation type="unfinished">Шу ой</translation>
    </message>
    <message>
        <source>Last month</source>
        <translation type="unfinished">Ўтган хафта</translation>
    </message>
    <message>
        <source>This year</source>
        <translation type="unfinished">Шу йил</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation type="unfinished">Ёрдамида қабул қилиш</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation type="unfinished">Жўнатиш</translation>
    </message>
    <message>
        <source>To yourself</source>
        <translation type="unfinished">Ўзингизга</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation type="unfinished">Фойда</translation>
    </message>
    <message>
        <source>Other</source>
        <translation type="unfinished">Бошка</translation>
    </message>
    <message>
        <source>Min amount</source>
        <translation type="unfinished">Мин қиймат</translation>
    </message>
    <message>
        <source>&amp;Copy address</source>
        <translation type="unfinished">&amp;Manzilni nusxalash</translation>
    </message>
    <message>
        <source>Copy &amp;label</source>
        <translation type="unfinished">&amp;Yorliqni nusxalash</translation>
    </message>
    <message>
        <source>Copy &amp;amount</source>
        <translation type="unfinished">&amp;Miqdorni nusxalash</translation>
    </message>
    <message>
        <source>Export Transaction History</source>
        <translation type="unfinished">Ўтказмалар тарихини экспорт қилиш</translation>
    </message>
    <message>
        <source>Comma separated file</source>
        <extracomment>Expanded name of the CSV file format. See: https://en.wikipedia.org/wiki/Comma-separated_values.</extracomment>
        <translation type="unfinished">Vergul bilan ajratilgan fayl</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation type="unfinished">Tasdiqlangan</translation>
    </message>
    <message>
        <source>Watch-only</source>
        <translation type="unfinished">Фақат кўришга</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished">Сана</translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished">Тури</translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished">Yorliq</translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="unfinished">Manzil</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation type="unfinished">Eksport qilish amalga oshmadi</translation>
    </message>
    <message>
        <source>The transaction history was successfully saved to %1.</source>
        <translation type="unfinished">Ўтказмалар тарихи %1 га муваффаққиятли сақланди.</translation>
    </message>
    <message>
        <source>Range:</source>
        <translation type="unfinished">Оралиқ:</translation>
    </message>
    <message>
        <source>to</source>
        <translation type="unfinished">Кимга</translation>
    </message>
</context>
<context>
    <name>WalletFrame</name>
    <message>
        <source>Create a new wallet</source>
        <translation type="unfinished">Yangi hamyon yaratish</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">Xatolik</translation>
    </message>
    </context>
<context>
    <name>WalletModel</name>
    <message>
        <source>Send Coins</source>
        <translation type="unfinished">Тангаларни жунат</translation>
    </message>
    <message>
        <source>default wallet</source>
        <translation type="unfinished">standart hamyon</translation>
    </message>
</context>
<context>
    <name>WalletView</name>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation type="unfinished">Joriy ichki oynaning ichidagi malumotlarni faylga yuklab olish</translation>
    </message>
    </context>
<context>
    <name>kawra-core</name>
    <message>
        <source>Done loading</source>
        <translation type="unfinished">Юклаш тайёр</translation>
    </message>
    <message>
        <source>Insufficient funds</source>
        <translation type="unfinished">Кам миқдор</translation>
    </message>
    <message>
        <source>Unable to start HTTP server. See debug log for details.</source>
        <translation type="unfinished">HTTP serverni ishga tushirib bo'lmadi. Tafsilotlar uchun disk raskadrovka jurnaliga qarang.</translation>
    </message>
    <message>
        <source>Verifying blocks…</source>
        <translation type="unfinished">Bloklar tekshirilmoqda…</translation>
    </message>
    <message>
        <source>Verifying wallet(s)…</source>
        <translation type="unfinished">Hamyon(lar) tekshirilmoqda…</translation>
    </message>
    <message>
        <source>Wallet needed to be rewritten: restart %s to complete</source>
        <translation type="unfinished">Hamyonni qayta yozish kerak: bajarish uchun 1%s ni qayta ishga tushiring</translation>
    </message>
    <message>
        <source>Settings file could not be read</source>
        <translation type="unfinished">Sozlamalar fayli o'qishga yaroqsiz</translation>
    </message>
    <message>
        <source>Settings file could not be written</source>
        <translation type="unfinished">Sozlamalar fayli yaratish uchun yaroqsiz</translation>
    </message>
</context>
</TS>