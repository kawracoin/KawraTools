<TS version="2.1" language="ne">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Right-click to edit address or label</source>
        <translation type="unfinished">ठेगाना वा लेबल सम्पादन गर्न दायाँ-क्लिक गर्नुहोस्</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation type="unfinished">नयाँ ठेगाना सिर्जना गर्नुहोस्</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation type="unfinished">&amp;amp;नयाँ</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation type="unfinished">भर्खरै चयन गरेको ठेगाना प्रणाली क्लिपबोर्डमा कपी गर्नुहोस्</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation type="unfinished">&amp;amp;कपी गर्नुहोस्</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation type="unfinished">छनौट गर्नुहोस्</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation type="unfinished">भर्खरै चयन गरेको ठेगाना सूचीबाट मेटाउनुहोस्</translation>
    </message>
    <message>
        <source>Enter address or label to search</source>
        <translation type="unfinished">खोज्नको लागि ठेगाना वा लेबल दर्ता गर्नुहोस</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation type="unfinished">वर्तमान ट्याबको डाटालाई फाइलमा निर्यात गर्नुहोस्</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation type="unfinished">&amp;amp;निर्यात गर्नुहोस्</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation type="unfinished">&amp;amp;मेटाउनुहोस्</translation>
    </message>
    <message>
        <source>Choose the address to send coins to</source>
        <translation type="unfinished">सिक्काहरु पठाउने ठेगाना छान्नुहोस् </translation>
    </message>
    <message>
        <source>Choose the address to receive coins with</source>
        <translation type="unfinished">सिक्काहरु प्राप्त गर्ने ठेगाना छान्नुहोस्</translation>
    </message>
    <message>
        <source>C&amp;hoose</source>
        <translation type="unfinished">छनौट गर्नुहोस्...</translation>
    </message>
    <message>
        <source>Sending addresses</source>
        <translation type="unfinished">पठाउने ठेगानाहरू</translation>
    </message>
    <message>
        <source>Receiving addresses</source>
        <translation type="unfinished">प्राप्त गर्ने ठेगानाहरू...</translation>
    </message>
    <message>
        <source>These are your Kawra addresses for sending payments. Always check the amount and the receiving address before sending coins.</source>
        <translation type="unfinished">यी भुक्तानी गर्नका लागि तपाइका बिट्कोइन ठेगानाहरू हुन्। सिक्काहरू पठाउनुअघि रकम र प्राप्त गर्ने ठेगाना जाँच गर्नुहोस।</translation>
    </message>
    <message>
        <source>&amp;Copy Address</source>
        <translation type="unfinished">ठेगाना कपी गर्नुहोस्</translation>
    </message>
    <message>
        <source>Copy &amp;Label</source>
        <translation type="unfinished">लेबल कपी गर्नुहोस्</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation type="unfinished">सम्पादन</translation>
    </message>
    <message>
        <source>Export Address List</source>
        <translation type="unfinished">ठेगाना सुची निर्यात</translation>
    </message>
    <message>
        <source>Comma separated file</source>
        <extracomment>Expanded name of the CSV file format. See: https://en.wikipedia.org/wiki/Comma-separated_values.</extracomment>
        <translation type="unfinished">अल्पविरामले छुट्टिएको फाइल</translation>
    </message>
    <message>
        <source>There was an error trying to save the address list to %1. Please try again.</source>
        <extracomment>An error message. %1 is a stand-in argument for the name of the file we attempted to save to.</extracomment>
        <translation type="unfinished">ठेगाना सुची %1मा बचत गर्ने प्रयासमा त्रुटि भएको छ। कृपया पुनः प्रयास गर्नुहोस।</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation type="unfinished">निर्यात असफल</translation>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Label</source>
        <translation type="unfinished">लेबल</translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="unfinished">ठेगाना</translation>
    </message>
    </context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Passphrase Dialog</source>
        <translation type="unfinished">पासफ्रेज संवाद</translation>
    </message>
    <message>
        <source>Enter passphrase</source>
        <translation type="unfinished">पासफ्रेज प्रवेश गर्नुहोस्</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation type="unfinished">नयाँ पासफ्रेज</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation type="unfinished">नयाँ पासफ्रेज दोहोर्याउनुहोस्</translation>
    </message>
    <message>
        <source>Show passphrase</source>
        <translation type="unfinished">पासफ्रेज देखाउनुहोस्</translation>
    </message>
    <message>
        <source>Encrypt wallet</source>
        <translation type="unfinished">वालेट इन्क्रिप्ट गर्नुहोस् </translation>
    </message>
    <message>
        <source>Unlock wallet</source>
        <translation type="unfinished">वालेट अनलक गर्नुहोस्</translation>
    </message>
    <message>
        <source>Change passphrase</source>
        <translation type="unfinished">पासफ्रेज परिवर्तन गर्नुहोस्</translation>
    </message>
    <message>
        <source>Confirm wallet encryption</source>
        <translation type="unfinished">वालेट इन्क्रिप्सन सुनिश्चित गर्नुहोस</translation>
    </message>
    <message>
        <source>Are you sure you wish to encrypt your wallet?</source>
        <translation type="unfinished">के तपाइँ तपाइँको वालेट ईन्क्रिप्ट गर्न निश्चित हुनुहुन्छ?</translation>
    </message>
    <message>
        <source>Wallet encrypted</source>
        <translation type="unfinished">वालेट इन्क्रिप्ट भयो</translation>
    </message>
    <message>
        <source>Your wallet is now encrypted. </source>
        <translation type="unfinished">अब वालेट इन्क्रिप्ट भएको छ।</translation>
    </message>
    <message>
        <source>Wallet encryption failed</source>
        <translation type="unfinished">वालेट इन्क्रिप्सन असफल </translation>
    </message>
    <message>
        <source>Wallet unlock failed</source>
        <translation type="unfinished">वालेट अनलक असफल </translation>
    </message>
    <message>
        <source>Warning: The Caps Lock key is on!</source>
        <translation type="unfinished">चेतावनी: क्याप्स लक कीप्याड अन छ!</translation>
    </message>
</context>
<context>
    <name>BanTableModel</name>
    <message>
        <source>IP/Netmask</source>
        <translation type="unfinished">IP/नेटमास्क</translation>
    </message>
    <message>
        <source>Banned Until</source>
        <translation type="unfinished">प्रतिबन्धित समय</translation>
    </message>
</context>
<context>
    <name>KawraApplication</name>
    <message>
        <source>Runaway exception</source>
        <translation type="unfinished">रनअवे अपवाद</translation>
    </message>
    <message>
        <source>Internal error</source>
        <translation type="unfinished">आन्तरिक दोष</translation>
    </message>
    </context>
<context>
    <name>QObject</name>
    <message>
        <source>Amount</source>
        <translation type="unfinished">रकम</translation>
    </message>
    <message>
        <source>Enter a Kawra address (e.g. %1)</source>
        <translation type="unfinished">कृपया बिटकोइन ठेगाना प्रवेश गर्नुहोस् (उदाहरण %1)</translation>
    </message>
    <message numerus="yes">
        <source>%n second(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n minute(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n hour(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n day(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n week(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n year(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    </context>
<context>
    <name>KawraGUI</name>
    <message>
        <source>&amp;Overview</source>
        <translation type="unfinished">शारांश</translation>
    </message>
    <message>
        <source>Show general overview of wallet</source>
        <translation type="unfinished">वालेटको साधारण शारांश देखाउनुहोस्</translation>
    </message>
    <message>
        <source>&amp;Transactions</source>
        <translation type="unfinished">&amp;amp;कारोबार</translation>
    </message>
    <message>
        <source>Browse transaction history</source>
        <translation type="unfinished">कारोबारको इतिहास हेर्नुहोस्</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation type="unfinished">बाहिर निस्कनुहोस्</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation type="unfinished">एप्लिकेसन बन्द गर्नुहोस्</translation>
    </message>
    <message>
        <source>&amp;About %1</source>
        <translation type="unfinished">&amp;amp;बारेमा %1</translation>
    </message>
    <message>
        <source>Show information about %1</source>
        <translation type="unfinished">%1 को बारेमा सूचना देखाउनुहोस्</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation type="unfinished">&amp;amp;Qt</translation>
    </message>
    <message>
        <source>Show information about Qt</source>
        <translation type="unfinished">Qt को बारेमा सूचना देखाउनुहोस्</translation>
    </message>
    <message>
        <source>Modify configuration options for %1</source>
        <translation type="unfinished">%1 का लागि कन्फिगुरेसनको विकल्प परिमार्जन गर्नुहोस</translation>
    </message>
    <message>
        <source>Create a new wallet</source>
        <translation type="unfinished">नयाँ वालेट सिर्जना गर्नुहोस्</translation>
    </message>
    <message>
        <source>&amp;Minimize</source>
        <translation type="unfinished">&amp;घटाउनु</translation>
    </message>
    <message>
        <source>Wallet:</source>
        <translation type="unfinished">वालेट:</translation>
    </message>
    <message>
        <source>Network activity disabled.</source>
        <extracomment>A substring of the tooltip.</extracomment>
        <translation type="unfinished">नेटवर्क गतिविधि अशक्त</translation>
    </message>
    <message>
        <source>Send coins to a Kawra address</source>
        <translation type="unfinished">बिटकोइन ठेगानामा सिक्का पठाउनुहोस्</translation>
    </message>
    <message>
        <source>Backup wallet to another location</source>
        <translation type="unfinished">वालेटलाई अर्को ठेगानामा ब्याकअप गर्नुहोस्</translation>
    </message>
    <message>
        <source>Change the passphrase used for wallet encryption</source>
        <translation type="unfinished">वालेट इन्क्रिप्सनमा प्रयोग हुने इन्क्रिप्सन पासफ्रेज परिवर्तन गर्नुहोस्</translation>
    </message>
    <message>
        <source>&amp;Send</source>
        <translation type="unfinished">&amp;पठाउनु</translation>
    </message>
    <message>
        <source>&amp;Receive</source>
        <translation type="unfinished">&amp;प्राप्त गर्नुहोस्</translation>
    </message>
    <message>
        <source>&amp;Options…</source>
        <translation type="unfinished">&amp;विकल्पहरू</translation>
    </message>
    <message>
        <source>&amp;Backup Wallet…</source>
        <translation type="unfinished">सहायता वालेट</translation>
    </message>
    <message>
        <source>&amp;Change Passphrase…</source>
        <translation type="unfinished">&amp;पासफ्रेज परिवर्तन गर्नुहोस्</translation>
    </message>
    <message>
        <source>Sign &amp;message…</source>
        <translation type="unfinished">हस्ताक्षर &amp;सन्देश...</translation>
    </message>
    <message>
        <source>&amp;Verify message…</source>
        <translation type="unfinished">&amp;प्रमाणित सन्देश...</translation>
    </message>
    <message>
        <source>Close Wallet…</source>
        <translation type="unfinished">वालेट बन्द गर्नुहोस्...</translation>
    </message>
    <message>
        <source>Create Wallet…</source>
        <translation type="unfinished">वालेट सिर्जना गर्नुहोस्</translation>
    </message>
    <message>
        <source>Close All Wallets…</source>
        <translation type="unfinished">सबै वालेट बन्द गर्नुहोस्...</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation type="unfinished">&amp;फाइल</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation type="unfinished">&amp;सेटिङ</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation type="unfinished">&amp;मद्दत</translation>
    </message>
    <message numerus="yes">
        <source>Processed %n block(s) of transaction history.</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message>
        <source>%1 behind</source>
        <translation type="unfinished">%1 पछाडि</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation type="unfinished">चेतावनी</translation>
    </message>
    <message>
        <source>Information</source>
        <translation type="unfinished">जानकारी</translation>
    </message>
    <message>
        <source>Wallet Name</source>
        <extracomment>Label of the input field where the name of the wallet is entered.</extracomment>
        <translation type="unfinished">वालेट को नाम</translation>
    </message>
    <message numerus="yes">
        <source>%n active connection(s) to Kawra network.</source>
        <extracomment>A substring of the tooltip.</extracomment>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    </context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Amount</source>
        <translation type="unfinished">रकम</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished">मिति</translation>
    </message>
    <message>
        <source>Confirmations</source>
        <translation type="unfinished">पुष्टिकरणहरू</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation type="unfinished">पुष्टि भयो</translation>
    </message>
    <message>
        <source>yes</source>
        <translation type="unfinished">हो</translation>
    </message>
    <message>
        <source>no</source>
        <translation type="unfinished">होइन</translation>
    </message>
    </context>
<context>
    <name>CreateWalletDialog</name>
    <message>
        <source>Wallet Name</source>
        <translation type="unfinished">वालेट को नाम</translation>
    </message>
    <message>
        <source>Create</source>
        <translation type="unfinished">सिर्जना गर्नुहोस्</translation>
    </message>
    </context>
<context>
    <name>Intro</name>
    <message numerus="yes">
        <source>%n GB of space available</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>(of %n GB needed)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>(%n GB needed for full chain)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>(sufficient to restore backups %n day(s) old)</source>
        <extracomment>Explanatory text on the capability of the current prune target.</extracomment>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    </context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Choose the default subdivision unit to show in the interface and when sending coins.</source>
        <translation type="unfinished">इन्टरफेसमा र सिक्का पठाउँदा देखिने डिफल्ट उपविभाजन एकाइ चयन गर्नुहोस् ।</translation>
    </message>
    </context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>The displayed information may be out of date. Your wallet automatically synchronizes with the Kawra network after a connection is established, but this process has not completed yet.</source>
        <translation type="unfinished">देखाइएको सूचना पूरानो हुन सक्छ । कनेक्सन स्थापित भएपछि, तपाईंको वालेट बिटकोइन नेटवर्कमा स्वचालित रूपमा समिकरण हुन्छ , तर यो प्रक्रिया अहिले सम्म पूरा भएको छैन ।</translation>
    </message>
    <message>
        <source>Watch-only:</source>
        <translation type="unfinished">हेर्ने-मात्र:</translation>
    </message>
    <message>
        <source>Available:</source>
        <translation type="unfinished">उपलब्ध:</translation>
    </message>
    <message>
        <source>Your current spendable balance</source>
        <translation type="unfinished">तपाईंको खर्च गर्न मिल्ने ब्यालेन्स</translation>
    </message>
    <message>
        <source>Pending:</source>
        <translation type="unfinished">विचाराधिन:</translation>
    </message>
    <message>
        <source>Total of transactions that have yet to be confirmed, and do not yet count toward the spendable balance</source>
        <translation type="unfinished">अझै पुष्टि हुन बाँकी र खर्च गर्न मिल्ने ब्यालेन्समा गणना गर्न नमिल्ने जम्मा कारोबार</translation>
    </message>
    <message>
        <source>Immature:</source>
        <translation type="unfinished">अपरिपक्व:</translation>
    </message>
    <message>
        <source>Mined balance that has not yet matured</source>
        <translation type="unfinished">अझै परिपक्व नभएको खनन गरिएको ब्यालेन्स</translation>
    </message>
    <message>
        <source>Balances</source>
        <translation type="unfinished">ब्यालेन्सहरु</translation>
    </message>
    <message>
        <source>Mined balance in watch-only addresses that has not yet matured</source>
        <translation type="unfinished">अहिलेसम्म परिपक्व नभएको खनन गरिएको, हेर्ने-मात्र ठेगानामा रहेको ब्यालेन्स</translation>
    </message>
    <message>
        <source>Current total balance in watch-only addresses</source>
        <translation type="unfinished">हेर्ने-मात्र ठेगानामा रहेको हालको जम्मा ब्यालेन्स</translation>
    </message>
    </context>
<context>
    <name>PeerTableModel</name>
    <message>
        <source>User Agent</source>
        <extracomment>Title of Peers Table column which contains the peer's User Agent string.</extracomment>
        <translation type="unfinished">प्रयोगकर्ता एजेन्ट</translation>
    </message>
    <message>
        <source>Address</source>
        <extracomment>Title of Peers Table column which contains the IP/Onion/I2P address of the connected peer.</extracomment>
        <translation type="unfinished">ठेगाना</translation>
    </message>
    </context>
<context>
    <name>RPCConsole</name>
    <message>
        <source>User Agent</source>
        <translation type="unfinished">प्रयोगकर्ता एजेन्ट</translation>
    </message>
    <message>
        <source>Ping Time</source>
        <translation type="unfinished">पिङ समय</translation>
    </message>
    </context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>Wallet:</source>
        <translation type="unfinished">वालेट:</translation>
    </message>
    </context>
<context>
    <name>RecentRequestsTableModel</name>
    <message>
        <source>Date</source>
        <translation type="unfinished">मिति</translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished">लेबल</translation>
    </message>
    </context>
<context>
    <name>SendCoinsDialog</name>
    <message numerus="yes">
        <source>Estimated to begin confirmation within %n block(s).</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    </context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>Choose previously used address</source>
        <translation type="unfinished">पहिला प्रयोग गरिएको ठेगाना प्रयोग गर्नुहोस्</translation>
    </message>
    <message>
        <source>The fee will be deducted from the amount being sent. The recipient will receive less kawras than you enter in the amount field. If multiple recipients are selected, the fee is split equally.</source>
        <translation type="unfinished">पठाइँदै गरेको रकमबाट शुल्क कटौती गरिनेछ । प्राप्तकर्ताले तपाईंले रकम क्षेत्रमा प्रवेष गरेको भन्दा थोरै बिटकोइन प्राप्त गर्ने छन् । धेरै प्राप्तकर्ता चयन गरिएको छ भने समान रूपमा शुल्क विभाजित गरिनेछ ।</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to the list of used addresses</source>
        <translation type="unfinished">यो ठेगानालाई प्रयोग गरिएको ठेगानाको सूचीमा थप्न एउटा लेबल प्रविष्ट गर्नुहोस्</translation>
    </message>
    <message>
        <source>A message that was attached to the kawra: URI which will be stored with the transaction for your reference. Note: This message will not be sent over the Kawra network.</source>
        <translation type="unfinished">बिटकोइनमा संलग्न गरिएको सन्देश: तपाईंको मध्यस्थको लागि कारोबारको साथमा भण्डारण गरिने URI । नोट: यो सन्देश बिटकोइन नेटवर्क मार्फत पठाइने छैन ।</translation>
    </message>
</context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>You can sign messages/agreements with your addresses to prove you can receive kawras sent to them. Be careful not to sign anything vague or random, as phishing attacks may try to trick you into signing your identity over to them. Only sign fully-detailed statements you agree to.</source>
        <translation type="unfinished">आफ्नो ठेगानामा पठाइएको बिटकोइन प्राप्त गर्न सकिन्छ भनेर प्रमाणित गर्न तपाईंले ती ठेगानाले सन्देश/सम्झौताहरूमा हस्ताक्षर गर्न सक्नुहुन्छ । फिसिङ आक्रमणले तपाईंलाई छक्याएर अरूका लागि तपाईंको परिचयमा हस्ताक्षर गराउने प्रयास गर्न सक्ने भएकाले अस्पष्ट वा जथाभावीमा हस्ताक्षर गर्दा ध्यान दिनुहोस् । आफू सहमत भएको पूर्ण विस्तृत-कथनमा मात्र हस्ताक्षर गर्नुहोस् ।</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation type="unfinished">पहिला प्रयोग गरिएको ठेगाना प्रयोग गर्नुहोस्</translation>
    </message>
    <message>
        <source>Copy the current signature to the system clipboard</source>
        <translation type="unfinished">वर्तमान हस्ताक्षरलाई प्रणाली क्लिपबोर्डमा कपी गर्नुहोस्</translation>
    </message>
    <message>
        <source>Enter the receiver's address, message (ensure you copy line breaks, spaces, tabs, etc. exactly) and signature below to verify the message. Be careful not to read more into the signature than what is in the signed message itself, to avoid being tricked by a man-in-the-middle attack. Note that this only proves the signing party receives with the address, it cannot prove sendership of any transaction!</source>
        <translation type="unfinished">सन्देश प्रमाणित गर्न, तल दिइएको स्थानमा प्राप्तकर्ता ठेगाना, सन्देश (लाइन ब्रेक, स्पेस, ट्याब, आदि उस्तै गरी कपी गर्ने कुरा सुनिश्चित गर्नुहोस्) र हस्ताक्षर &amp;apos;s प्रविष्ट गर्नुहोस् । बीचमा-मानिसको-आक्रमणबाट बच्न हस्ताक्षर पढ्दा हस्ताक्षर गरिएको सन्देशमा जे छ त्यो भन्दा धेरै कुरामा ध्यान नदिनुहोस् । यो कार्यले हस्ताक्षर गर्ने पक्षले मात्र यो ठेगानाले प्राप्त गर्छ भन्ने कुरा प्रमाणित गर्छ, यसले कुनै पनि कारोबारको प्रेषककर्तालाई प्रमाणित गर्न सक्दैन भन्ने कुरा याद गर्नुहोस्!</translation>
    </message>
    </context>
<context>
    <name>TransactionDesc</name>
    <message>
        <source>Date</source>
        <translation type="unfinished">मिति</translation>
    </message>
    <message numerus="yes">
        <source>matures in %n more block(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">रकम</translation>
    </message>
    </context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Date</source>
        <translation type="unfinished">मिति</translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished">लेबल</translation>
    </message>
    </context>
<context>
    <name>TransactionView</name>
    <message>
        <source>Comma separated file</source>
        <extracomment>Expanded name of the CSV file format. See: https://en.wikipedia.org/wiki/Comma-separated_values.</extracomment>
        <translation type="unfinished">अल्पविरामले छुट्टिएको फाइल</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation type="unfinished">पुष्टि भयो</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished">मिति</translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished">लेबल</translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="unfinished">ठेगाना</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation type="unfinished">निर्यात असफल</translation>
    </message>
    </context>
<context>
    <name>WalletFrame</name>
    <message>
        <source>Create a new wallet</source>
        <translation type="unfinished">नयाँ वालेट सिर्जना गर्नुहोस्</translation>
    </message>
    </context>
<context>
    <name>WalletView</name>
    <message>
        <source>&amp;Export</source>
        <translation type="unfinished">&amp;amp;निर्यात गर्नुहोस्</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation type="unfinished">वर्तमान ट्याबको डाटालाई फाइलमा निर्यात गर्नुहोस्</translation>
    </message>
    </context>
<context>
    <name>kawra-core</name>
    <message>
        <source>The block database contains a block which appears to be from the future. This may be due to your computer's date and time being set incorrectly. Only rebuild the block database if you are sure that your computer's date and time are correct</source>
        <translation type="unfinished">ब्लक डाटाबेसमा भविष्यबाट आए जस्तो देखिने एउटा ब्लक हुन्छ । तपाईंको कम्प्युटरको मिति र समय गलत तरिकाले सेट गरिएकाले यस्तो हुन सक्छ । तपाईं आफ्नो कम्प्युटरको मिति र समय सही छ भनेर पक्का हुनुहुन्छ भने मात्र ब्लक डाटाबेस पुनर्निर्माण गर्नुहोस् ।</translation>
    </message>
    <message>
        <source>The transaction amount is too small to send after the fee has been deducted</source>
        <translation type="unfinished">कारोबार रकम शुल्क कटौती गरेपछि पठाउँदा धेरै नै सानो हुन्छ</translation>
    </message>
    <message>
        <source>This is a pre-release test build - use at your own risk - do not use for mining or merchant applications</source>
        <translation type="unfinished">यो जारी गर्नु पूर्वको परीक्षण संस्करण हो - आफ्नै जोखिममा प्रयोग गर्नुहोस् - खनन वा व्यापारीक प्रयोगको लागि प्रयोग नगर्नुहोस</translation>
    </message>
    <message>
        <source>Warning: We do not appear to fully agree with our peers! You may need to upgrade, or other nodes may need to upgrade.</source>
        <translation type="unfinished">चेतावनी: हामी हाम्रा सहकर्मीहरूसँग पूर्णतया सहमत छैनौं जस्तो देखिन्छ! तपाईंले अपग्रेड गर्नु पर्ने हुनसक्छ वा अरू नोडहरूले अपग्रेड गर्नु पर्ने हुनसक्छ ।</translation>
    </message>
    <message>
        <source>You need to rebuild the database using -reindex to go back to unpruned mode.  This will redownload the entire blockchain</source>
        <translation type="unfinished">तपाईंले काटछाँट नगरेको मोडमा जान पुनः सूचकांक प्रयोग गरेर डाटाबेस पुनर्निर्माण गर्नु पर्ने हुन्छ । यसले सम्पूर्ण ब्लकचेनलाई फेरि डाउनलोड गर्नेछ</translation>
    </message>
    <message>
        <source>-maxmempool must be at least %d MB</source>
        <translation type="unfinished">-maxmempool कम्तिमा %d MB को हुनुपर्छ ।</translation>
    </message>
    <message>
        <source>Cannot resolve -%s address: '%s'</source>
        <translation type="unfinished">-%s ठेगाना: &amp;apos;%s&amp;apos; निश्चय गर्न सकिँदैन</translation>
    </message>
    <message>
        <source>Copyright (C) %i-%i</source>
        <translation type="unfinished">सर्वाधिकार (C) %i-%i</translation>
    </message>
    <message>
        <source>Corrupted block database detected</source>
        <translation type="unfinished">क्षति पुगेको ब्लक डाटाबेस फेला पर</translation>
    </message>
    <message>
        <source>Do you want to rebuild the block database now?</source>
        <translation type="unfinished">तपाईं अहिले ब्लक डेटाबेस पुनर्निर्माण गर्न चाहनुहुन्छ ?</translation>
    </message>
    <message>
        <source>Unable to bind to %s on this computer. %s is probably already running.</source>
        <translation type="unfinished">यो कम्प्युटरको %s मा बाँध्न सकिएन । %s सम्भवित रूपमा पहिलैबाट चलिरहेको छ ।</translation>
    </message>
    <message>
        <source>User Agent comment (%s) contains unsafe characters.</source>
        <translation type="unfinished">प्रयोगकर्ता एजेन्टको टिप्पणी (%s) मा असुरक्षित अक्षरहरू छन् ।</translation>
    </message>
    <message>
        <source>Wallet needed to be rewritten: restart %s to complete</source>
        <translation type="unfinished">वालेट फेरि लेख्नु आवश्यक छ: पूरा गर्न %s लाई पुन: सुरु गर्नुहोस्</translation>
    </message>
    <message>
        <source>Settings file could not be read</source>
        <translation type="unfinished">सेटिङ फाइल पढ्न सकिएन</translation>
    </message>
    <message>
        <source>Settings file could not be written</source>
        <translation type="unfinished">सेटिङ फाइल लेख्न सकिएन</translation>
    </message>
</context>
</TS>