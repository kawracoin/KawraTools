<TS version="2.1" language="ml">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Right-click to edit address or label</source>
        <translation type="unfinished">വിലാസം അല്ലെങ്കിൽ ലേബൽ എഡിറ്റുചെയ്യാൻ വലത് മൌസ് ബട്ടൺ ക്ലിക്കുചെയ്യുക</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation type="unfinished">ഒരു പുതിയ വിലാസം സൃഷ്ടിക്കുക</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation type="unfinished">പുതിയത്</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation type="unfinished">നിലവിൽ തിരഞ്ഞെടുത്ത വിലാസം സിസ്റ്റം ക്ലിപ്പ്ബോർഡിലേക്ക് പകർത്തുക</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation type="unfinished">&amp;പകർത്തുക</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation type="unfinished">അടയ്ക്കുക</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation type="unfinished">പട്ടികയിൽ നിന്ന് നിലവിൽ തിരഞ്ഞെടുത്ത വിലാസം ഇല്ലാതാക്കുക</translation>
    </message>
    <message>
        <source>Enter address or label to search</source>
        <translation type="unfinished">തിരയുന്നതിന് വിലാസമോ ലേബലോ നൽകുക</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation type="unfinished">നിലവിലുള്ള  ടാബിലെ  വിവരങ്ങൾ ഒരു ഫയലിലേക്ക് എക്സ്പോർട്ട് ചെയ്യുക</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation type="unfinished">&amp; കയറ്റുമതി ചെയ്യുക</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation type="unfinished">&amp;ഇല്ലാതാക്കുക</translation>
    </message>
    <message>
        <source>Choose the address to send coins to</source>
        <translation type="unfinished">നാണയങ്ങൾ അയയ്ക്കാനുള്ള വിലാസം തിരഞ്ഞെടുക്കുക</translation>
    </message>
    <message>
        <source>Choose the address to receive coins with</source>
        <translation type="unfinished">നാണയങ്ങൾ സ്വീകരിക്കാൻ വിലാസം തിരഞ്ഞെടുക്കുക</translation>
    </message>
    <message>
        <source>C&amp;hoose</source>
        <translation type="unfinished">തി&amp;രഞ്ഞെടുക്കുക</translation>
    </message>
    <message>
        <source>Sending addresses</source>
        <translation type="unfinished">അയക്കേണ്ട വിലാസങ്ങൾ</translation>
    </message>
    <message>
        <source>Receiving addresses</source>
        <translation type="unfinished">സ്വീകരിക്കുന്ന വിലാസങ്ങൾ</translation>
    </message>
    <message>
        <source>These are your Kawra addresses for sending payments. Always check the amount and the receiving address before sending coins.</source>
        <translation type="unfinished">പൈസ അയയ്ക്കുന്നതിനുള്ള നിങ്ങളുടെ ബിറ്റ് കോയിൻ വിലാസങ്ങളാണ് ഇവ. നാണയങ്ങൾ അയയ്ക്കുന്നതിനുമുമ്പ് എല്ലായ്പ്പോഴും തുകയും സ്വീകരിക്കുന്ന വിലാസവും പരിശോധിക്കുക.</translation>
    </message>
    <message>
        <source>These are your Kawra addresses for receiving payments. Use the 'Create new receiving address' button in the receive tab to create new addresses.
Signing is only possible with addresses of the type 'legacy'.</source>
        <translation type="unfinished">ഇവയാണ് പണം  സ്വീകരിയ്ക്കുന്നതിനായുള്ള താങ്കളുടെ ബിറ്റ്കോയിൻ വിലാസങ്ങൾ. പുതിയ വിലാസങ്ങൾ കൂട്ടിച്ചേർക്കുന്നതിനായി ' പുതിയ വിലാസം സൃഷ്ടിയ്ക്കുക ' എന്ന ബട്ടൺ അമർത്തുക.
'ലെഗസി' തരത്തിന്റെ വിലാസങ്ങളിൽ മാത്രമേ സൈൻ ചെയ്യാൻ കഴിയൂ.</translation>
    </message>
    <message>
        <source>&amp;Copy Address</source>
        <translation type="unfinished">&amp;വിലാസം പകർത്തുക</translation>
    </message>
    <message>
        <source>Copy &amp;Label</source>
        <translation type="unfinished">പകർത്തുക &amp;ലേബൽ</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation type="unfinished">&amp;ചിട്ടപ്പെടുത്തുക</translation>
    </message>
    <message>
        <source>Export Address List</source>
        <translation type="unfinished">കയറ്റുമതി വിലാസങ്ങൾ </translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation type="unfinished">കയറ്റുമതി പരാജയപ്പെട്ടു</translation>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Label</source>
        <translation type="unfinished">ലേബൽ</translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="unfinished">വിലാസം</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(ലേബൽ ഇല്ല)</translation>
    </message>
</context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Passphrase Dialog</source>
        <translation type="unfinished">രഹസ്യപദ  സൂചന </translation>
    </message>
    <message>
        <source>Enter passphrase</source>
        <translation type="unfinished">രഹസ്യപദം നൽകുക</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation type="unfinished">പുതിയ രഹസ്യപദം </translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation type="unfinished">പുതിയ രഹസ്യപദം ആവർത്തിക്കുക</translation>
    </message>
    <message>
        <source>Show passphrase</source>
        <translation type="unfinished">രഹസ്യപദം  കാണിക്കുക </translation>
    </message>
    <message>
        <source>Encrypt wallet</source>
        <translation type="unfinished">വാലറ്റ് എൻക്രിപ്റ്റ് ചെയ്യുക</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation type="unfinished">നിങ്ങളുടെ വാലറ്റ് അൺലോക്കുചെയ്യാൻ ഈ പ്രവർത്തനത്തിന് നിങ്ങളുടെ വാലറ്റ് രഹസ്യപദം ആവശ്യമാണ്.</translation>
    </message>
    <message>
        <source>Unlock wallet</source>
        <translation type="unfinished">വാലറ്റ് തുറക്കുക. </translation>
    </message>
    <message>
        <source>Change passphrase</source>
        <translation type="unfinished">രഹസ്യ സൂചന തിരുത്തുക </translation>
    </message>
    <message>
        <source>Confirm wallet encryption</source>
        <translation type="unfinished">വാലറ്റ് എൻക്രിപ്ഷൻ സ്ഥിരീകരിക്കുക</translation>
    </message>
    <message>
        <source>Warning: If you encrypt your wallet and lose your passphrase, you will &lt;b&gt;LOSE ALL OF YOUR KAWRAS&lt;/b&gt;!</source>
        <translation type="unfinished">മുന്നറിയിപ്പ്: നിങ്ങളുടെ വാലറ്റ് എൻക്രിപ്റ്റ് ചെയ്ത, രഹസ്യ പദം നഷ്ടപ്പെടുകയാണെങ്കിൽ നിങ്ങളുടെ എല്ലാ ബിറ്റ് കോയിനുകളും  നഷ്ടപ്പെടും!</translation>
    </message>
    <message>
        <source>Are you sure you wish to encrypt your wallet?</source>
        <translation type="unfinished">നിങ്ങളുടെ വാലറ്റ് എൻ‌ക്രിപ്റ്റ് ചെയ്യാൻ ആഗ്രഹിക്കുന്നുവെന്ന് ഉറപ്പാണോ?</translation>
    </message>
    <message>
        <source>Wallet encrypted</source>
        <translation type="unfinished">വാലറ്റ് എന്ക്രിപ്റ് ചെയ്തു കഴിഞ്ഞു .</translation>
    </message>
    <message>
        <source>Enter the new passphrase for the wallet.&lt;br/&gt;Please use a passphrase of &lt;b&gt;ten or more random characters&lt;/b&gt;, or &lt;b&gt;eight or more words&lt;/b&gt;.</source>
        <translation type="unfinished">വാലറ്റിൽ പുതിയ രഹസ്യവാക്യം നൽകുക.  പത്തോ അതിലധികമോ അക്ഷരങ്ങൾ  അല്ലെങ്കിൽ  എട്ടോ  കൂടുതലോ വാക്കുകൾ </translation>
    </message>
    <message>
        <source>Enter the old passphrase and new passphrase for the wallet.</source>
        <translation type="unfinished">വാലെറ്റിന്റെ പഴയ രഹസ്യപദവും പുതിയ രഹസ്യപദവും നൽകുക.</translation>
    </message>
    <message>
        <source>Remember that encrypting your wallet cannot fully protect your kawras from being stolen by malware infecting your computer.</source>
        <translation type="unfinished">നിങ്ങളുടെ വാലറ്റ് എൻ‌ക്രിപ്റ്റ് ചെയ്യുന്നതിലൂടെ നിങ്ങളുടെ കമ്പ്യൂട്ടറിനെ ബാധിക്കുന്ന ക്ഷുദ്രവെയർ‌ മോഷ്ടിക്കുന്നതിൽ‌ നിന്നും നിങ്ങളുടെ ബിറ്റ്കോയിനുകളെ പൂർണ്ണമായി സംരക്ഷിക്കാൻ‌ കഴിയില്ല.</translation>
    </message>
    <message>
        <source>Wallet to be encrypted</source>
        <translation type="unfinished">വാലറ്റ് എന്ക്രിപ്റ് ചെയ്യാൻ പോകുന്നു .</translation>
    </message>
    <message>
        <source>Your wallet is about to be encrypted. </source>
        <translation type="unfinished">വാലറ്റ് എന്ക്രിപ്റ് ചെയ്യാൻ പോകുന്നു .</translation>
    </message>
    <message>
        <source>Your wallet is now encrypted. </source>
        <translation type="unfinished">വാലറ്റ് എന്ക്രിപ്റ് ചെയ്തു കഴിഞ്ഞു .</translation>
    </message>
    <message>
        <source>IMPORTANT: Any previous backups you have made of your wallet file should be replaced with the newly generated, encrypted wallet file. For security reasons, previous backups of the unencrypted wallet file will become useless as soon as you start using the new, encrypted wallet.</source>
        <translation type="unfinished">പ്രധാനം: നിങ്ങളുടെ വാലറ്റ് ഫയലിൽ മുമ്പ് നിർമ്മിച്ച ഏതെങ്കിലും ബാക്കപ്പുകൾ പുതുതായി ജനറേറ്റുചെയ്ത, എൻ‌ക്രിപ്റ്റ് ചെയ്ത വാലറ്റ് ഫയൽ ഉപയോഗിച്ച് മാറ്റിസ്ഥാപിക്കണം. സുരക്ഷാ കാരണങ്ങളാൽ, നിങ്ങൾ പുതിയ, എൻ‌ക്രിപ്റ്റ് ചെയ്ത വാലറ്റ് ഉപയോഗിക്കാൻ ആരംഭിക്കുമ്പോൾ തന്നെ എൻ‌ക്രിപ്റ്റ് ചെയ്യാത്ത വാലറ്റ് ഫയലിന്റെ മുമ്പത്തെ ബാക്കപ്പുകൾ ഉപയോഗശൂന്യമാകും.</translation>
    </message>
    <message>
        <source>Wallet encryption failed</source>
        <translation type="unfinished">വാലറ്റ് എന്ക്രിപ്റ് പരാജയപെട്ടു  .</translation>
    </message>
    <message>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation type="unfinished">ആന്തരിക പിശക് കാരണം വാലറ്റ് എൻ‌ക്രിപ്ഷൻ പരാജയപ്പെട്ടു. നിങ്ങളുടെ വാലറ്റ് എൻ‌ക്രിപ്റ്റ് ചെയ്തിട്ടില്ല.</translation>
    </message>
    <message>
        <source>The supplied passphrases do not match.</source>
        <translation type="unfinished">വിതരണം ചെയ്ത പാസ്‌ഫ്രെയ്‌സുകൾ പൊരുത്തപ്പെടുന്നില്ല.</translation>
    </message>
    <message>
        <source>Wallet unlock failed</source>
        <translation type="unfinished">വാലറ്റ് അൺലോക്ക് പരാജയപ്പെട്ടു</translation>
    </message>
    <message>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation type="unfinished">വാലറ്റ് ഡീക്രിപ്ഷനായി നൽകിയ പാസ്‌ഫ്രേസ് തെറ്റാണ്.</translation>
    </message>
    <message>
        <source>Wallet passphrase was successfully changed.</source>
        <translation type="unfinished">വാലറ്റ് പാസ്‌ഫ്രെയ്‌സ് വിജയകരമായി മാറ്റി.</translation>
    </message>
    <message>
        <source>Warning: The Caps Lock key is on!</source>
        <translation type="unfinished">മുന്നറിയിപ്പ്: ക്യാപ്‌സ് ലോക്ക് കീ ഓണാണ്!</translation>
    </message>
</context>
<context>
    <name>BanTableModel</name>
    <message>
        <source>IP/Netmask</source>
        <translation type="unfinished">IP / നെറ്റ്മാസ്ക്</translation>
    </message>
    <message>
        <source>Banned Until</source>
        <translation type="unfinished">വരെ നിരോധിച്ചു</translation>
    </message>
</context>
<context>
    <name>KawraApplication</name>
    <message>
        <source>A fatal error occurred. %1 can no longer continue safely and will quit.</source>
        <translation type="unfinished">മാരകമായ ഒരു പിശക് സംഭവിച്ചു. %1 ന് മേലിൽ സുരക്ഷിതമായി തുടരാനാകില്ല, ഒപ്പം ഉപേക്ഷിക്കുകയും ചെയ്യും.</translation>
    </message>
    <message>
        <source>Internal error</source>
        <translation type="unfinished">ആന്തരിക പിശക്
 </translation>
    </message>
    </context>
<context>
    <name>QObject</name>
    <message>
        <source>Error: %1</source>
        <translation type="unfinished">തെറ്റ് : %1 </translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">തുക </translation>
    </message>
    <message>
        <source>Enter a Kawra address (e.g. %1)</source>
        <translation type="unfinished">ഒരു ബിറ്റ്കോയിൻ വിലാസം നൽകുക(e.g. %1)</translation>
    </message>
    <message numerus="yes">
        <source>%n second(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n minute(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n hour(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n day(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n week(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n year(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    </context>
<context>
    <name>KawraGUI</name>
    <message>
        <source>&amp;Overview</source>
        <translation type="unfinished">&amp;അവലോകനം</translation>
    </message>
    <message>
        <source>Show general overview of wallet</source>
        <translation type="unfinished">വാലറ്റിന്റെ പൊതുവായ അവലോകനം കാണിക്കുക</translation>
    </message>
    <message>
        <source>&amp;Transactions</source>
        <translation type="unfinished">&amp;ഇടപാടുകൾ </translation>
    </message>
    <message>
        <source>Browse transaction history</source>
        <translation type="unfinished">ഇടപാടുകളുടെ ചരിത്രം പരിശോധിയ്ക്കുക</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation type="unfinished">പുറത്ത്</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation type="unfinished">അപ്ലിക്കേഷൻ ഉപേക്ഷിക്കുക</translation>
    </message>
    <message>
        <source>&amp;About %1</source>
        <translation type="unfinished">&amp; ഏകദേശം%1</translation>
    </message>
    <message>
        <source>Show information about %1</source>
        <translation type="unfinished">%1 നെക്കുറിച്ചുള്ള വിവരങ്ങൾ കാണിക്കുക</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation type="unfinished">ഏകദേശം&amp;Qt</translation>
    </message>
    <message>
        <source>Show information about Qt</source>
        <translation type="unfinished">Qt സംബന്ധിച്ച വിവരങ്ങൾ കാണിക്കുക</translation>
    </message>
    <message>
        <source>Modify configuration options for %1</source>
        <translation type="unfinished">%1 നായുള്ള കോൺഫിഗറേഷൻ ഓപ്ഷനുകൾ പരിഷ്‌ക്കരിക്കുക</translation>
    </message>
    <message>
        <source>Create a new wallet</source>
        <translation type="unfinished">ഒരു പുതിയ വാലറ്റ് സൃഷ്ടിക്കുക</translation>
    </message>
    <message>
        <source>Wallet:</source>
        <translation type="unfinished">വാലറ്റ്:</translation>
    </message>
    <message>
        <source>Network activity disabled.</source>
        <extracomment>A substring of the tooltip.</extracomment>
        <translation type="unfinished">നെറ്റ്‌വർക്ക് പ്രവർത്തനം പ്രവർത്തനരഹിതമാക്കി.</translation>
    </message>
    <message>
        <source>Proxy is &lt;b&gt;enabled&lt;/b&gt;: %1</source>
        <translation type="unfinished">പ്രോക്സി ആണ്&lt;b&gt;പ്രവർത്തനക്ഷമമാക്കി&lt;/b&gt;:%1</translation>
    </message>
    <message>
        <source>Send coins to a Kawra address</source>
        <translation type="unfinished">ഒരു ബിറ്റ്കോയിൻ വിലാസത്തിലേക്ക് നാണയങ്ങൾ അയയ്ക്കുക</translation>
    </message>
    <message>
        <source>Backup wallet to another location</source>
        <translation type="unfinished">മറ്റൊരു സ്ഥലത്തേക്ക് ബാക്കപ്പ് വാലറ്റ്</translation>
    </message>
    <message>
        <source>Change the passphrase used for wallet encryption</source>
        <translation type="unfinished">വാലറ്റ് എൻ‌ക്രിപ്ഷനായി ഉപയോഗിക്കുന്ന പാസ്‌ഫ്രെയ്‌സ് മാറ്റുക</translation>
    </message>
    <message>
        <source>&amp;Send</source>
        <translation type="unfinished">&amp;അയയ്‌ക്കുക</translation>
    </message>
    <message>
        <source>&amp;Receive</source>
        <translation type="unfinished">&amp;സ്വീകരിക്കുക</translation>
    </message>
    <message>
        <source>Encrypt the private keys that belong to your wallet</source>
        <translation type="unfinished">നിങ്ങളുടെ വാലറ്റിന്റെ സ്വകാര്യ കീകൾ എൻ‌ക്രിപ്റ്റ് ചെയ്യുക</translation>
    </message>
    <message>
        <source>Sign messages with your Kawra addresses to prove you own them</source>
        <translation type="unfinished">നിങ്ങളുടെ ബിറ്റ്കോയിൻ വിലാസങ്ങൾ സ്വന്തമാണെന്ന് തെളിയിക്കാൻ സന്ദേശങ്ങൾ ഒപ്പിടുക</translation>
    </message>
    <message>
        <source>Verify messages to ensure they were signed with specified Kawra addresses</source>
        <translation type="unfinished">നിർദ്ദിഷ്ട ബിറ്റ്കോയിൻ വിലാസങ്ങളിൽ സന്ദേശങ്ങൾ ഒപ്പിട്ടിട്ടുണ്ടെന്ന് ഉറപ്പാക്കാൻ സ്ഥിരീകരിക്കുക</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation type="unfinished">&amp; ഫയൽ</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation type="unfinished">&amp;ക്രമീകരണങ്ങൾ</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation type="unfinished">&amp;സഹായം</translation>
    </message>
    <message>
        <source>Tabs toolbar</source>
        <translation type="unfinished">ടാബുകളുടെ ടൂൾബാർ</translation>
    </message>
    <message>
        <source>Request payments (generates QR codes and kawra: URIs)</source>
        <translation type="unfinished">പേയ്‌മെന്റുകൾ അഭ്യർത്ഥിക്കുക (QR കോഡുകളും ബിറ്റ്കോയിനും സൃഷ്ടിക്കുന്നു: URI- കൾ)</translation>
    </message>
    <message>
        <source>Show the list of used sending addresses and labels</source>
        <translation type="unfinished">ഉപയോഗിച്ച അയച്ച വിലാസങ്ങളുടെയും ലേബലുകളുടെയും പട്ടിക കാണിക്കുക</translation>
    </message>
    <message>
        <source>Show the list of used receiving addresses and labels</source>
        <translation type="unfinished">ഉപയോഗിച്ച സ്വീകരിക്കുന്ന വിലാസങ്ങളുടെയും ലേബലുകളുടെയും പട്ടിക കാണിക്കുക</translation>
    </message>
    <message>
        <source>&amp;Command-line options</source>
        <translation type="unfinished">&amp;കമാൻഡ്-ലൈൻ ഓപ്ഷനുകൾ</translation>
    </message>
    <message numerus="yes">
        <source>Processed %n block(s) of transaction history.</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message>
        <source>Last received block was generated %1 ago.</source>
        <translation type="unfinished">അവസാനം ലഭിച്ച ബ്ലോക്ക് %1 മുമ്പ് സൃഷ്ടിച്ചു.</translation>
    </message>
    <message>
        <source>Transactions after this will not yet be visible.</source>
        <translation type="unfinished">ഇതിനുശേഷമുള്ള ഇടപാടുകൾ ഇതുവരെ ദൃശ്യമാകില്ല.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">പിശക് </translation>
    </message>
    <message>
        <source>Warning</source>
        <translation type="unfinished">മുന്നറിയിപ്പ് </translation>
    </message>
    <message>
        <source>Information</source>
        <translation type="unfinished">വിവരം </translation>
    </message>
    <message>
        <source>Up to date</source>
        <translation type="unfinished">കാലികമാണ്</translation>
    </message>
    <message>
        <source>Load Partially Signed Kawra Transaction</source>
        <translation type="unfinished">ഭാഗികമായി ഒപ്പിട്ട ബിറ്റ്കോയിൻ ഇടപാട് ലോഡുചെയ്യുക</translation>
    </message>
    <message>
        <source>Load Partially Signed Kawra Transaction from clipboard</source>
        <translation type="unfinished">ക്ലിപ്പ്ബോർഡിൽ നിന്ന് ഭാഗികമായി ഒപ്പിട്ട ബിറ്റ്കോയിൻ ഇടപാട് ലോഡുചെയ്യുക</translation>
    </message>
    <message>
        <source>Node window</source>
        <translation type="unfinished">നോഡ് വിൻഡോ</translation>
    </message>
    <message>
        <source>Open node debugging and diagnostic console</source>
        <translation type="unfinished">നോഡ് ഡീബഗ്ഗിംഗും ഡയഗ്നോസ്റ്റിക് കൺസോളും തുറക്കുക</translation>
    </message>
    <message>
        <source>&amp;Sending addresses</source>
        <translation type="unfinished">&amp;വിലാസങ്ങൾ അയയ്ക്കുന്നു</translation>
    </message>
    <message>
        <source>&amp;Receiving addresses</source>
        <translation type="unfinished">&amp;വിലാസങ്ങൾ അയയ്ക്കുന്നു</translation>
    </message>
    <message>
        <source>Open a kawra: URI</source>
        <translation type="unfinished">ഒരു ബിറ്റ്കോയിൻ തുറക്കുക: URI</translation>
    </message>
    <message>
        <source>Open Wallet</source>
        <translation type="unfinished">വാലറ്റ് തുറക്കുക </translation>
    </message>
    <message>
        <source>Open a wallet</source>
        <translation type="unfinished">ഒരു വാലറ്റ് തുറക്കുക </translation>
    </message>
    <message>
        <source>Close wallet</source>
        <translation type="unfinished">വാലറ്റ് പൂട്ടുക </translation>
    </message>
    <message>
        <source>Close all wallets</source>
        <translation type="unfinished">എല്ലാ വാലറ്റുകളും അടയ്‌ക്കുക ...</translation>
    </message>
    <message>
        <source>Show the %1 help message to get a list with possible Kawra command-line options</source>
        <translation type="unfinished">സാധ്യമായ ബിറ്റ്കോയിൻ കമാൻഡ്-ലൈൻ ഓപ്ഷനുകളുള്ള ഒരു ലിസ്റ്റ് ലഭിക്കുന്നതിന് %1 സഹായ സന്ദേശം കാണിക്കുക</translation>
    </message>
    <message>
        <source>&amp;Mask values</source>
        <translation type="unfinished">&amp;മാസ്ക് മൂല്യങ്ങൾ</translation>
    </message>
    <message>
        <source>Mask the values in the Overview tab</source>
        <translation type="unfinished">അവലോകന ടാബിൽ മൂല്യങ്ങൾ മാസ്ക് ചെയ്യുക</translation>
    </message>
    <message>
        <source>default wallet</source>
        <translation type="unfinished">സ്ഥിരം ആയ വാലറ്റ്</translation>
    </message>
    <message>
        <source>No wallets available</source>
        <translation type="unfinished">വാലറ്റ് ഒന്നും ലഭ്യം അല്ല </translation>
    </message>
    <message>
        <source>Wallet Name</source>
        <extracomment>Label of the input field where the name of the wallet is entered.</extracomment>
        <translation type="unfinished">വാലറ്റ് പേര്</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation type="unfinished">&amp;ജാലകം </translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation type="unfinished">വലുതാക്കുക </translation>
    </message>
    <message>
        <source>Main Window</source>
        <translation type="unfinished">മുഖ്യ ജാലകം </translation>
    </message>
    <message>
        <source>%1 client</source>
        <translation type="unfinished">%1 ക്ലയന്റ്</translation>
    </message>
    <message numerus="yes">
        <source>%n active connection(s) to Kawra network.</source>
        <extracomment>A substring of the tooltip.</extracomment>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message>
        <source>Error: %1</source>
        <translation type="unfinished">തെറ്റ് : %1 </translation>
    </message>
    <message>
        <source>Warning: %1</source>
        <translation type="unfinished">മുന്നറിയിപ്പ് : %1 </translation>
    </message>
    <message>
        <source>Date: %1
</source>
        <translation type="unfinished">തീയതി: %1 
</translation>
    </message>
    <message>
        <source>Amount: %1
</source>
        <translation type="unfinished">തുക : %1 
</translation>
    </message>
    <message>
        <source>Wallet: %1
</source>
        <translation type="unfinished">വാലറ്റ്: %1 
</translation>
    </message>
    <message>
        <source>Type: %1
</source>
        <translation type="unfinished">തരങ്ങൾ: %1
</translation>
    </message>
    <message>
        <source>Label: %1
</source>
        <translation type="unfinished">കുറിപ്പ് : %1 
</translation>
    </message>
    <message>
        <source>Address: %1
</source>
        <translation type="unfinished">മേൽവിലാസം : %1 
</translation>
    </message>
    <message>
        <source>Sent transaction</source>
        <translation type="unfinished">അയച്ച ഇടപാടുകൾ </translation>
    </message>
    <message>
        <source>Incoming transaction</source>
        <translation type="unfinished">വരവ്വ് വെച്ച ഇടപാടുകൾ </translation>
    </message>
    <message>
        <source>HD key generation is &lt;b&gt;enabled&lt;/b&gt;</source>
        <translation type="unfinished">എച്ച്ഡി കീ ജനറേഷൻ&lt;b&gt;പ്രവർത്തനക്ഷമമാക്കി&lt;/b&gt;</translation>
    </message>
    <message>
        <source>HD key generation is &lt;b&gt;disabled&lt;/b&gt;</source>
        <translation type="unfinished">എച്ച്ഡി കീ ജനറേഷൻ&lt;b&gt;പ്രവർത്തനരഹിതമാക്കി&lt;/b&gt;`</translation>
    </message>
    <message>
        <source>Private key &lt;b&gt;disabled&lt;/b&gt;</source>
        <translation type="unfinished">സ്വകാര്യ കീ&lt;b&gt;പ്രവർത്തനരഹിതമാക്കി&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation type="unfinished">Wallet &lt;b&gt;എൻ‌ക്രിപ്റ്റ് ചെയ്തു&lt;/b&gt;നിലവിൽ&lt;b&gt;അൺലോക്കുചെയ്‌തു&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation type="unfinished">Wallet &lt;b&gt;എൻ‌ക്രിപ്റ്റ് ചെയ്തു&lt;/b&gt;നിലവിൽ&lt;b&gt;പൂട്ടി&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Original message:</source>
        <translation type="unfinished">യഥാർത്ഥ സന്ദേശം:</translation>
    </message>
</context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Coin Selection</source>
        <translation type="unfinished">കോയിൻ തിരഞ്ഞെടുക്കൽ </translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation type="unfinished">നിര്‍ദ്ധിഷ്‌ടസംഖ്യ / അളവ് :</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation type="unfinished">ബൈറ്റ്സ്:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation type="unfinished">തുക:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation type="unfinished">ഫീസ്‌ / പ്രതിഫലം :</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation type="unfinished">പൊടി:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation type="unfinished">ഫീസ് കഴിഞ്ഞ്:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation type="unfinished">മാറ്റം</translation>
    </message>
    <message>
        <source>(un)select all</source>
        <translation type="unfinished">എല്ലാം തിരഞ്ഞു (എടുക്കുക /എടുക്കാതിരിക്കുക)</translation>
    </message>
    <message>
        <source>Tree mode</source>
        <translation type="unfinished">ട്രീ മോഡ്</translation>
    </message>
    <message>
        <source>List mode</source>
        <translation type="unfinished">പട്ടിക </translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">തുക </translation>
    </message>
    <message>
        <source>Received with label</source>
        <translation type="unfinished">അടയാളത്തോടുകൂടി ലഭിച്ചു </translation>
    </message>
    <message>
        <source>Received with address</source>
        <translation type="unfinished">മേൽവിലാസത്തോടുകൂടി ലഭിച്ചു </translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished">തീയതി </translation>
    </message>
    <message>
        <source>Confirmations</source>
        <translation type="unfinished">സ്ഥിതീകരണങ്ങൾ </translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation type="unfinished">സ്ഥിതീകരിച്ചു</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation type="unfinished">തുക പകർത്തുക</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation type="unfinished">നിര്‍ദ്ധിഷ്‌ടസംഖ്യ / അളവ് പകർത്തുക</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation type="unfinished">പകർത്തു ഫീസ്</translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation type="unfinished">ശേഷമുള്ള ഫീ പകർത്തു</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation type="unfinished">ബൈറ്റ്സ് പകർത്തു</translation>
    </message>
    <message>
        <source>Copy dust</source>
        <translation type="unfinished">ഡസ്ട് പകർത്തു</translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation type="unfinished">ചേഞ്ച് പകർത്തു</translation>
    </message>
    <message>
        <source>(%1 locked)</source>
        <translation type="unfinished">(%1 ലോക്ക് ആക്കിയിരിക്കുന്നു)</translation>
    </message>
    <message>
        <source>yes</source>
        <translation type="unfinished">അതെ / ശരി</translation>
    </message>
    <message>
        <source>no</source>
        <translation type="unfinished">ഇല്ല</translation>
    </message>
    <message>
        <source>This label turns red if any recipient receives an amount smaller than the current dust threshold.</source>
        <translation type="unfinished">ഏതെങ്കിലും സ്വീകർത്താവിന് നിലവിലെ ഡസ്ട് പരിധിയേക്കാൾ ചെറിയ തുക ലഭിക്കുകയാണെങ്കിൽ ഈ ലേബൽ ചുവപ്പായി മാറുന്നു.</translation>
    </message>
    <message>
        <source>Can vary +/- %1 satoshi(s) per input.</source>
        <translation type="unfinished">ഒരു ഇൻപുട്ടിന് +/-%1 സതോഷി(കൾ) വ്യത്യാസം ഉണ്ടാകാം.</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(ലേബൽ ഇല്ല)</translation>
    </message>
    <message>
        <source>change from %1 (%2)</source>
        <translation type="unfinished">%1 (%2) ൽ നിന്ന് മാറ്റുക</translation>
    </message>
    <message>
        <source>(change)</source>
        <translation type="unfinished">(മാറ്റം)</translation>
    </message>
</context>
<context>
    <name>CreateWalletActivity</name>
    <message>
        <source>Create Wallet</source>
        <extracomment>Title of window indicating the progress of creation of a new wallet.</extracomment>
        <translation type="unfinished">വാലറ്റ് / പണസഞ്ചി സൃഷ്ടിക്കുക :</translation>
    </message>
    <message>
        <source>Create wallet failed</source>
        <translation type="unfinished">വാലറ്റ് രൂപീകരണം പരാജയപ്പെട്ടു </translation>
    </message>
    <message>
        <source>Create wallet warning</source>
        <translation type="unfinished">വാലറ്റ് രൂപീകരണത്തിലെ മുന്നറിയിപ്പ് </translation>
    </message>
    </context>
<context>
    <name>OpenWalletActivity</name>
    <message>
        <source>default wallet</source>
        <translation type="unfinished">സ്ഥിരം ആയ വാലറ്റ്</translation>
    </message>
    <message>
        <source>Open Wallet</source>
        <extracomment>Title of window indicating the progress of opening of a wallet.</extracomment>
        <translation type="unfinished">വാലറ്റ് തുറക്കുക </translation>
    </message>
    </context>
<context>
    <name>WalletController</name>
    <message>
        <source>Close wallet</source>
        <translation type="unfinished">വാലറ്റ് പൂട്ടുക </translation>
    </message>
    <message>
        <source>Close all wallets</source>
        <translation type="unfinished">എല്ലാ വാലറ്റുകളും അടയ്‌ക്കുക ...</translation>
    </message>
    </context>
<context>
    <name>CreateWalletDialog</name>
    <message>
        <source>Create Wallet</source>
        <translation type="unfinished">വാലറ്റ് / പണസഞ്ചി സൃഷ്ടിക്കുക :</translation>
    </message>
    <message>
        <source>Wallet Name</source>
        <translation type="unfinished">വാലറ്റ് പേര്</translation>
    </message>
    <message>
        <source>Encrypt the wallet. The wallet will be encrypted with a passphrase of your choice.</source>
        <translation type="unfinished">എൻ‌ക്രിപ്റ്റ് വാലറ്റ്</translation>
    </message>
    <message>
        <source>Encrypt Wallet</source>
        <translation type="unfinished">എൻ‌ക്രിപ്റ്റ് വാലറ്റ്</translation>
    </message>
    <message>
        <source>Disable Private Keys</source>
        <translation type="unfinished"> സ്വകാര്യ കീകൾ പ്രവർത്തനരഹിതമാക്കുക </translation>
    </message>
    <message>
        <source>Make Blank Wallet</source>
        <translation type="unfinished">ശൂന്യമായ വാലറ്റ് നിർമ്മിക്കുക</translation>
    </message>
    <message>
        <source>Create</source>
        <translation type="unfinished">സൃഷ്ടിക്കുക</translation>
    </message>
    </context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation type="unfinished">വിലാസം എഡിറ്റുചെയ്യുക</translation>
    </message>
    <message>
        <source>&amp;Label</source>
        <translation type="unfinished">&amp;ലേബൽ</translation>
    </message>
    <message>
        <source>&amp;Address</source>
        <translation type="unfinished">&amp; വിലാസം</translation>
    </message>
    <message>
        <source>New sending address</source>
        <translation type="unfinished">പുതിയ അയയ്‌ക്കുന്ന വിലാസം</translation>
    </message>
    <message>
        <source>Edit receiving address</source>
        <translation type="unfinished">സ്വീകരിക്കുന്ന വിലാസം എഡിറ്റുചെയ്യുക</translation>
    </message>
    <message>
        <source>Edit sending address</source>
        <translation type="unfinished">അയയ്‌ക്കുന്ന വിലാസം എഡിറ്റുചെയ്യുക</translation>
    </message>
    <message>
        <source>Could not unlock wallet.</source>
        <translation type="unfinished">വാലറ്റ് അൺലോക്കുചെയ്യാനായില്ല.</translation>
    </message>
    <message>
        <source>New key generation failed.</source>
        <translation type="unfinished">പുതിയ കീ ജനറേഷൻ പരാജയപ്പെട്ടു</translation>
    </message>
</context>
<context>
    <name>FreespaceChecker</name>
    <message>
        <source>A new data directory will be created.</source>
        <translation type="unfinished">ഒരു പുതിയ ഡാറ്റ ഡയറക്ടറി സൃഷ്ടിക്കും.</translation>
    </message>
    <message>
        <source>name</source>
        <translation type="unfinished">നാമധേയം / പേര് </translation>
    </message>
    <message>
        <source>Path already exists, and is not a directory.</source>
        <translation type="unfinished">പാത്ത് ഇതിനകം നിലവിലുണ്ട്, അത് ഒരു ഡയറക്ടറിയല്ല.</translation>
    </message>
    <message>
        <source>Cannot create data directory here.</source>
        <translation type="unfinished">ഡാറ്റ ഡയറക്ടറി ഇവിടെ സൃഷ്ടിക്കാൻ കഴിയില്ല.</translation>
    </message>
</context>
<context>
    <name>Intro</name>
    <message>
        <source>Kawra</source>
        <translation type="unfinished">ബിറ്റ്കോയിൻ</translation>
    </message>
    <message numerus="yes">
        <source>%n GB of space available</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>(of %n GB needed)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>(%n GB needed for full chain)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>(sufficient to restore backups %n day(s) old)</source>
        <extracomment>Explanatory text on the capability of the current prune target.</extracomment>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">പിശക് </translation>
    </message>
    <message>
        <source>Welcome</source>
        <translation type="unfinished">സ്വാഗതം</translation>
    </message>
    </context>
<context>
    <name>HelpMessageDialog</name>
    <message>
        <source>version</source>
        <translation type="unfinished">പതിപ്പ്</translation>
    </message>
    <message>
        <source>Command-line options</source>
        <translation type="unfinished">കമാൻഡ്-ലൈൻ ഓപ്ഷനുകൾ</translation>
    </message>
</context>
<context>
    <name>ShutdownWindow</name>
    <message>
        <source>%1 is shutting down…</source>
        <translation type="unfinished">%1 നിർത്തുകയാണ്...</translation>
    </message>
    </context>
<context>
    <name>ModalOverlay</name>
    <message>
        <source>Form</source>
        <translation type="unfinished">ഫോം </translation>
    </message>
    <message>
        <source>Number of blocks left</source>
        <translation type="unfinished">അവശേഷിക്കുന്ന ബ്ലോക്കുകൾ </translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation type="unfinished">അവസാന ബ്ലോക്കിന്റെ സമയം </translation>
    </message>
    <message>
        <source>Progress</source>
        <translation type="unfinished">പുരോഗതി</translation>
    </message>
    </context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>&amp;Window</source>
        <translation type="unfinished">&amp;ജാലകം </translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">പിശക് </translation>
    </message>
    </context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Form</source>
        <translation type="unfinished">ഫോം </translation>
    </message>
    <message>
        <source>Available:</source>
        <translation type="unfinished">ലഭ്യമായ</translation>
    </message>
    <message>
        <source>Spendable:</source>
        <translation type="unfinished">വിനിയോഗിക്കാവുന്നത് / ചെലവാക്കാവുന്നത് </translation>
    </message>
    <message>
        <source>Recent transactions</source>
        <translation type="unfinished">സമീപ കാല ഇടപാടുകൾ</translation>
    </message>
    </context>
<context>
    <name>PSBTOperationsDialog</name>
    <message>
        <source>Signed transaction successfully. Transaction is ready to broadcast.</source>
        <translation type="unfinished">ഇടപാട് വിജയകരമായി ഒപ്പിട്ടു.  ഇടപാട് പ്രക്ഷേപണത്തിന് തയ്യാറാണ്</translation>
    </message>
    </context>
<context>
    <name>PaymentServer</name>
    <message>
        <source>URI handling</source>
        <translation type="unfinished">യു‌ആർ‌ഐ കൈകാര്യം ചെയ്യൽ</translation>
    </message>
    <message>
        <source>'kawra://' is not a valid URI. Use 'kawra:' instead.</source>
        <translation type="unfinished">'kawra://' എന്നത് ശരിയായ ഒരു URI അല്ല .പകരം 'kawra:' ഉപയോഗിക്കൂ </translation>
    </message>
    <message>
        <source>URI cannot be parsed! This can be caused by an invalid Kawra address or malformed URI parameters.</source>
        <translation type="unfinished">യു‌ആർ‌ഐ പാഴ്‌സുചെയ്യാൻ‌ കഴിയില്ല! അസാധുവായ ബിറ്റ്കോയിൻ വിലാസം അല്ലെങ്കിൽ കേടായ യു‌ആർ‌ഐ പാരാമീറ്ററുകൾ കാരണം ഇത് സംഭവിക്കാം.</translation>
    </message>
    <message>
        <source>Payment request file handling</source>
        <translation type="unfinished">പേയ്‌മെന്റ് അഭ്യർത്ഥന ഫയൽ കൈകാര്യം ചെയ്യൽ</translation>
    </message>
</context>
<context>
    <name>PeerTableModel</name>
    <message>
        <source>User Agent</source>
        <extracomment>Title of Peers Table column which contains the peer's User Agent string.</extracomment>
        <translation type="unfinished">ഉപയോക്തൃ ഏജൻറ്</translation>
    </message>
    <message>
        <source>Ping</source>
        <extracomment>Title of Peers Table column which indicates the current latency of the connection with the peer.</extracomment>
        <translation type="unfinished">പിംഗ് </translation>
    </message>
    <message>
        <source>Sent</source>
        <extracomment>Title of Peers Table column which indicates the total amount of network information we have sent to the peer.</extracomment>
        <translation type="unfinished">അയക്കുക </translation>
    </message>
    <message>
        <source>Received</source>
        <extracomment>Title of Peers Table column which indicates the total amount of network information we have received from the peer.</extracomment>
        <translation type="unfinished">ലഭിച്ചവ </translation>
    </message>
    <message>
        <source>Address</source>
        <extracomment>Title of Peers Table column which contains the IP/Onion/I2P address of the connected peer.</extracomment>
        <translation type="unfinished">വിലാസം</translation>
    </message>
    </context>
<context>
    <name>RPCConsole</name>
    <message>
        <source>Received</source>
        <translation type="unfinished">ലഭിച്ചവ </translation>
    </message>
    <message>
        <source>Sent</source>
        <translation type="unfinished">അയക്കുക </translation>
    </message>
    <message>
        <source>User Agent</source>
        <translation type="unfinished">ഉപയോക്തൃ ഏജൻറ്</translation>
    </message>
    <message>
        <source>Node window</source>
        <translation type="unfinished">നോഡ് വിൻഡോ</translation>
    </message>
    <message>
        <source>Permissions</source>
        <translation type="unfinished">അനുവാത്തംനൽകൾ</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation type="unfinished">അവസാന ബ്ലോക്കിന്റെ സമയം </translation>
    </message>
    </context>
<context>
    <name>ReceiveCoinsDialog</name>
    <message>
        <source>Could not unlock wallet.</source>
        <translation type="unfinished">വാലറ്റ് അൺലോക്കുചെയ്യാനായില്ല.</translation>
    </message>
    </context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>Amount:</source>
        <translation type="unfinished">തുക:</translation>
    </message>
    <message>
        <source>Wallet:</source>
        <translation type="unfinished">വാലറ്റ്:</translation>
    </message>
    </context>
<context>
    <name>RecentRequestsTableModel</name>
    <message>
        <source>Date</source>
        <translation type="unfinished">തീയതി </translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished">ലേബൽ</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(ലേബൽ ഇല്ല)</translation>
    </message>
    </context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Quantity:</source>
        <translation type="unfinished">നിര്‍ദ്ധിഷ്‌ടസംഖ്യ / അളവ് :</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation type="unfinished">ബൈറ്റ്സ്:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation type="unfinished">തുക:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation type="unfinished">ഫീസ്‌ / പ്രതിഫലം :</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation type="unfinished">ഫീസ് കഴിഞ്ഞ്:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation type="unfinished">മാറ്റം</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation type="unfinished">പൊടി:</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation type="unfinished">നിര്‍ദ്ധിഷ്‌ടസംഖ്യ / അളവ് പകർത്തുക</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation type="unfinished">തുക പകർത്തുക</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation type="unfinished">പകർത്തു ഫീസ്</translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation type="unfinished">ശേഷമുള്ള ഫീ പകർത്തു</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation type="unfinished">ബൈറ്റ്സ് പകർത്തു</translation>
    </message>
    <message>
        <source>Copy dust</source>
        <translation type="unfinished">ഡസ്ട് പകർത്തു</translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation type="unfinished">ചേഞ്ച് പകർത്തു</translation>
    </message>
    <message numerus="yes">
        <source>Estimated to begin confirmation within %n block(s).</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(ലേബൽ ഇല്ല)</translation>
    </message>
</context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>Choose previously used address</source>
        <translation type="unfinished">മുൻപ്‌ ഉപയോഗിച്ച അഡ്രസ് തെരഞ്ഞെടുക്കുക</translation>
    </message>
    <message>
        <source>The Kawra address to send the payment to</source>
        <translation type="unfinished">പേയ്മെന്റ് അയക്കേണ്ട ബിറ്കോയിൻ അഡ്രസ് </translation>
    </message>
    </context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>Choose previously used address</source>
        <translation type="unfinished">മുൻപ്‌ ഉപയോഗിച്ച അഡ്രസ് തെരഞ്ഞെടുക്കുക</translation>
    </message>
    </context>
<context>
    <name>TransactionDesc</name>
    <message>
        <source>%1 confirmations</source>
        <extracomment>Text explaining the current status of a transaction, shown in the status field of the details window for this transaction. This status represents a transaction confirmed in 6 or more blocks.</extracomment>
        <translation type="unfinished">%1 സ്ഥിരീകരണങ്ങൾ</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished">തീയതി </translation>
    </message>
    <message numerus="yes">
        <source>matures in %n more block(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">തുക </translation>
    </message>
    </context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Date</source>
        <translation type="unfinished">തീയതി </translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished">ലേബൽ</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(ലേബൽ ഇല്ല)</translation>
    </message>
    </context>
<context>
    <name>TransactionView</name>
    <message>
        <source>Confirmed</source>
        <translation type="unfinished">സ്ഥിതീകരിച്ചു</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished">തീയതി </translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished">ലേബൽ</translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="unfinished">വിലാസം</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation type="unfinished">കയറ്റുമതി പരാജയപ്പെട്ടു</translation>
    </message>
    </context>
<context>
    <name>WalletFrame</name>
    <message>
        <source>Create a new wallet</source>
        <translation type="unfinished">ഒരു പുതിയ വാലറ്റ് സൃഷ്ടിക്കുക</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">പിശക് </translation>
    </message>
    </context>
<context>
    <name>WalletModel</name>
    <message>
        <source>default wallet</source>
        <translation type="unfinished">സ്ഥിരം ആയ വാലറ്റ്</translation>
    </message>
</context>
<context>
    <name>WalletView</name>
    <message>
        <source>&amp;Export</source>
        <translation type="unfinished">&amp; കയറ്റുമതി ചെയ്യുക</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation type="unfinished">നിലവിലുള്ള  ടാബിലെ  വിവരങ്ങൾ ഒരു ഫയലിലേക്ക് എക്സ്പോർട്ട് ചെയ്യുക</translation>
    </message>
    </context>
<context>
    <name>kawra-core</name>
    <message>
        <source>This is the transaction fee you may pay when fee estimates are not available.</source>
        <translation type="unfinished">പ്രതിഫലം മൂല്യനിർണയം ലഭ്യമാകാത്ത പക്ഷം നിങ്ങൾ നല്കേണ്ടിവരുന്ന ഇടപാട് പ്രതിഫലം ഇതാണ്.</translation>
    </message>
    <message>
        <source>Error reading from database, shutting down.</source>
        <translation type="unfinished">ഡാറ്റാബേസിൽ നിന്നും വായിച്ചെടുക്കുന്നതിനു തടസം നേരിട്ടു, പ്രവർത്തനം അവസാനിപ്പിക്കുന്നു.</translation>
    </message>
    <message>
        <source>Error: Disk space is low for %s</source>
        <translation type="unfinished">Error: %s ൽ ഡിസ്ക് സ്പേസ് വളരെ കുറവാണ്</translation>
    </message>
    <message>
        <source>Invalid -onion address or hostname: '%s'</source>
        <translation type="unfinished">തെറ്റായ ഒണിയൻ അഡ്രസ് അല്ലെങ്കിൽ ഹോസ്റ്റ്നെയിം: '%s'</translation>
    </message>
    <message>
        <source>Invalid -proxy address or hostname: '%s'</source>
        <translation type="unfinished">തെറ്റായ -പ്രോക്സി അഡ്രസ് അല്ലെങ്കിൽ ഹോസ്റ്റ് നെയിം : '%s'</translation>
    </message>
    <message>
        <source>Invalid netmask specified in -whitelist: '%s'</source>
        <translation type="unfinished">-whitelist: '%s' ൽ രേഖപ്പെടുത്തിയിരിക്കുന്ന netmask തെറ്റാണ് </translation>
    </message>
    <message>
        <source>Need to specify a port with -whitebind: '%s'</source>
        <translation type="unfinished">-whitebind: '%s' നൊടൊപ്പം ഒരു പോർട്ട് കൂടി നിർദ്ദേശിക്കേണ്ടതുണ്ട് </translation>
    </message>
    <message>
        <source>Reducing -maxconnections from %d to %d, because of system limitations.</source>
        <translation type="unfinished">സിസ്റ്റത്തിന്റെ പരിമിധികളാൽ -maxconnections ന്റെ മൂല്യം %d ൽ  നിന്നും %d യിലേക്ക് കുറക്കുന്നു.</translation>
    </message>
    <message>
        <source>Section [%s] is not recognized.</source>
        <translation type="unfinished">Section [%s]  തിരിച്ചറിഞ്ഞില്ല.</translation>
    </message>
    <message>
        <source>Signing transaction failed</source>
        <translation type="unfinished">ഇടപാട് സൈൻ ചെയ്യുന്നത് പരാജയപ്പെട്ടു.</translation>
    </message>
    <message>
        <source>Specified -walletdir "%s" does not exist</source>
        <translation type="unfinished">നിർദേശിച്ച -walletdir "%s" നിലവിൽ ഇല്ല</translation>
    </message>
    <message>
        <source>Specified -walletdir "%s" is a relative path</source>
        <translation type="unfinished">നിർദേശിച്ച -walletdir "%s" ഒരു റിലേറ്റീവ് പാത്ത് ആണ്</translation>
    </message>
    <message>
        <source>Specified -walletdir "%s" is not a directory</source>
        <translation type="unfinished">നിർദേശിച്ച  -walletdir "%s" ഒരു ഡയറക്ടറി അല്ല </translation>
    </message>
    <message>
        <source>The transaction amount is too small to pay the fee</source>
        <translation type="unfinished">ഇടപാട് മൂല്യം തീരെ കുറവായതിനാൽ പ്രതിഫലം നൽകാൻ കഴിയില്ല.</translation>
    </message>
    <message>
        <source>This is experimental software.</source>
        <translation type="unfinished">ഇത് പരീക്ഷിച്ചുകൊണ്ടിരിക്കുന്ന ഒരു സോഫ്റ്റ്‌വെയർ ആണ്.</translation>
    </message>
    <message>
        <source>Transaction amount too small</source>
        <translation type="unfinished">ഇടപാട് മൂല്യം വളരെ കുറവാണ്</translation>
    </message>
    <message>
        <source>Transaction too large</source>
        <translation type="unfinished">ഇടപാട് വളരെ വലുതാണ് </translation>
    </message>
    <message>
        <source>Unable to bind to %s on this computer (bind returned error %s)</source>
        <translation type="unfinished">ഈ കംപ്യൂട്ടറിലെ %s ൽ ബൈൻഡ് ചെയ്യാൻ സാധിക്കുന്നില്ല ( ബൈൻഡ് തിരികെ തന്ന പിശക് %s )</translation>
    </message>
    <message>
        <source>Unable to create the PID file '%s': %s</source>
        <translation type="unfinished">PID ഫയൽ '%s': %s നിർമിക്കാൻ സാധിക്കുന്നില്ല </translation>
    </message>
    <message>
        <source>Unable to generate initial keys</source>
        <translation type="unfinished">പ്രാഥമിക കീ നിർമ്മിക്കാൻ സാധിക്കുന്നില്ല</translation>
    </message>
    <message>
        <source>Unknown -blockfilterindex value %s.</source>
        <translation type="unfinished">-blockfilterindex ന്റെ മൂല്യം %s മനസിലാക്കാൻ കഴിയുന്നില്ല.</translation>
    </message>
    </context>
</TS>