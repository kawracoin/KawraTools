<TS version="2.1" language="yo">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Right-click to edit address or label</source>
        <translation type="unfinished">Te botiini apa otun lati se atunse si adireesi tabi isaami</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation type="unfinished">si adireesi tuntun</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation type="unfinished">&amp;ati tuntun</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation type="unfinished">da adiresi tuntun ti o sayan ko si eto sileti </translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation type="unfinished">daako</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation type="unfinished">paade</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation type="unfinished">samukuro adiresi ti o sese sayan kuro ninu akojo</translation>
    </message>
    </context>
<context>
    <name>QObject</name>
    <message numerus="yes">
        <source>%n second(s)</source>
        <translation type="unfinished">
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n minute(s)</source>
        <translation type="unfinished">
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n hour(s)</source>
        <translation type="unfinished">
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n day(s)</source>
        <translation type="unfinished">
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n week(s)</source>
        <translation type="unfinished">
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n year(s)</source>
        <translation type="unfinished">
            <numerusform />
        </translation>
    </message>
    </context>
<context>
    <name>KawraGUI</name>
    <message numerus="yes">
        <source>Processed %n block(s) of transaction history.</source>
        <translation type="unfinished">
            <numerusform />
        </translation>
    </message>
    <message>
        <source>Open Wallet</source>
        <translation type="unfinished">sii apamowo</translation>
    </message>
    <message>
        <source>Open a wallet</source>
        <translation type="unfinished">sii apamowo</translation>
    </message>
    <message>
        <source>Close wallet</source>
        <translation type="unfinished">Ti Apamowo</translation>
    </message>
    <message numerus="yes">
        <source>%n active connection(s) to Kawra network.</source>
        <extracomment>A substring of the tooltip.</extracomment>
        <translation type="unfinished">
            <numerusform />
        </translation>
    </message>
    </context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Date</source>
        <translation type="unfinished">Ojo</translation>
    </message>
    </context>
<context>
    <name>OpenWalletActivity</name>
    <message>
        <source>Open Wallet</source>
        <extracomment>Title of window indicating the progress of opening of a wallet.</extracomment>
        <translation type="unfinished">sii apamowo</translation>
    </message>
    </context>
<context>
    <name>WalletController</name>
    <message>
        <source>Close wallet</source>
        <translation type="unfinished">Ti Apamowo</translation>
    </message>
    </context>
<context>
    <name>FreespaceChecker</name>
    <message>
        <source>name</source>
        <translation type="unfinished">oruko</translation>
    </message>
    </context>
<context>
    <name>Intro</name>
    <message numerus="yes">
        <source>%n GB of space available</source>
        <translation type="unfinished">
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>(of %n GB needed)</source>
        <translation type="unfinished">
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>(%n GB needed for full chain)</source>
        <translation type="unfinished">
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>(sufficient to restore backups %n day(s) old)</source>
        <extracomment>Explanatory text on the capability of the current prune target.</extracomment>
        <translation type="unfinished">
            <numerusform />
        </translation>
    </message>
    <message>
        <source>Welcome</source>
        <translation type="unfinished">Ka bo</translation>
    </message>
    </context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>&amp;OK</source>
        <translation type="unfinished">&amp;o da</translation>
    </message>
    </context>
<context>
    <name>RPCConsole</name>
    <message>
        <source>Name</source>
        <translation type="unfinished">Oruko</translation>
    </message>
    <message>
        <source>1 &amp;year</source>
        <translation type="unfinished">okan ati &amp;odun</translation>
    </message>
    </context>
<context>
    <name>RecentRequestsTableModel</name>
    <message>
        <source>Date</source>
        <translation type="unfinished">Ojo</translation>
    </message>
    </context>
<context>
    <name>SendCoinsDialog</name>
    <message numerus="yes">
        <source>Estimated to begin confirmation within %n block(s).</source>
        <translation type="unfinished">
            <numerusform />
        </translation>
    </message>
    </context>
<context>
    <name>TransactionDesc</name>
    <message>
        <source>Date</source>
        <translation type="unfinished">Ojo</translation>
    </message>
    <message>
        <source>watch-only</source>
        <translation type="unfinished">wo nikan</translation>
    </message>
    <message numerus="yes">
        <source>matures in %n more block(s)</source>
        <translation type="unfinished">
            <numerusform />
        </translation>
    </message>
    </context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Date</source>
        <translation type="unfinished">Ojo</translation>
    </message>
    <message>
        <source>watch-only</source>
        <translation type="unfinished">wo nikan</translation>
    </message>
    </context>
<context>
    <name>TransactionView</name>
    <message>
        <source>This year</source>
        <translation type="unfinished">Odun yi</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished">Ojo</translation>
    </message>
    </context>
</TS>