<TS version="2.1" language="pam">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Right-click to edit address or label</source>
        <translation type="unfinished">I-right click ban alilan ing address o libel</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation type="unfinished">Maglalang kang bayung address</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation type="unfinished">&amp;Bayu</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation type="unfinished">Kopyan me ing salukuyan at makipiling address keng system clipboard</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation type="unfinished">&amp;Kopyan</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation type="unfinished">I&amp;sara</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation type="unfinished">Ilako ya ing kasalungsungan makapiling address keng listahan</translation>
    </message>
    <message>
        <source>Enter address or label to search</source>
        <translation type="unfinished">Magpalub kang address o label para pantunan</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation type="unfinished">&amp;Ilako</translation>
    </message>
    <message>
        <source>Choose the address to send coins to</source>
        <translation type="unfinished">Pilinan ing address a magpadalang coins kang</translation>
    </message>
    <message>
        <source>Choose the address to receive coins with</source>
        <translation type="unfinished">Pilinan ing address a tumanggap coins a atin</translation>
    </message>
    <message>
        <source>C&amp;hoose</source>
        <translation type="unfinished">P&amp;ilinan</translation>
    </message>
    <message>
        <source>Sending addresses</source>
        <translation type="unfinished">Address king pamag-Send</translation>
    </message>
    <message>
        <source>Receiving addresses</source>
        <translation type="unfinished">Address king pamag-Tanggap</translation>
    </message>
    <message>
        <source>These are your Kawra addresses for sending payments. Always check the amount and the receiving address before sending coins.</source>
        <translation type="unfinished">Reni reng kekang Kawra address king pamagpadalang kabayaran. Lawan mulang masalese reng alaga ampo ing address na ning tumanggap bayu ka magpadalang barya.</translation>
    </message>
    <message>
        <source>&amp;Copy Address</source>
        <translation type="unfinished">&amp;Kopyan ing address</translation>
    </message>
    <message>
        <source>Copy &amp;Label</source>
        <translation type="unfinished">Kopyan ing &amp;Label</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation type="unfinished">&amp;Alilan</translation>
    </message>
    </context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(alang label)</translation>
    </message>
</context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Passphrase Dialog</source>
        <translation type="unfinished">Dialogo ning Passphrase</translation>
    </message>
    <message>
        <source>Enter passphrase</source>
        <translation type="unfinished">Mamalub kang passphrase</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation type="unfinished">Panibayung passphrase</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation type="unfinished">Pasibayuan ya ing bayung passphrase</translation>
    </message>
    <message>
        <source>Encrypt wallet</source>
        <translation type="unfinished">I-encrypt ye ing wallet</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation type="unfinished">Ing operasyun a ini kailangan ne ing kekayung wallet passphrase, ban a-unlock ya ing wallet</translation>
    </message>
    <message>
        <source>Unlock wallet</source>
        <translation type="unfinished">Unlock ya ing wallet</translation>
    </message>
    <message>
        <source>Change passphrase</source>
        <translation type="unfinished">Alilan ya ing passphrase</translation>
    </message>
    <message>
        <source>Confirm wallet encryption</source>
        <translation type="unfinished">Kumpirman ya ing wallet encryption</translation>
    </message>
    <message>
        <source>Warning: If you encrypt your wallet and lose your passphrase, you will &lt;b&gt;LOSE ALL OF YOUR KAWRAS&lt;/b&gt;!</source>
        <translation type="unfinished">Kapabaluan: Istung in-encrypt me ing kekang wallet at meala ya ing passphrase na, ma-&lt;b&gt;ALA NO NGAN RING KEKANG KAWRAS&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Are you sure you wish to encrypt your wallet?</source>
        <translation type="unfinished">Siguradu na kang buri meng i-encrypt ing kekang wallet?</translation>
    </message>
    <message>
        <source>Wallet encrypted</source>
        <translation type="unfinished">Me-encrypt ne ing wallet</translation>
    </message>
    <message>
        <source>IMPORTANT: Any previous backups you have made of your wallet file should be replaced with the newly generated, encrypted wallet file. For security reasons, previous backups of the unencrypted wallet file will become useless as soon as you start using the new, encrypted wallet.</source>
        <translation type="unfinished">Mayalaga: Reng milabas a backups a gewa mu gamit ing wallet file mu dapat lamung mialilan bayung gawang encrypted wallet file. Para keng seguridad , reng milabas a backups dareng ali maka encrypt a wallet file ma-ala nala istung inumpisan mu nalang gamitan reng bayu, at me encrypt a wallet. </translation>
    </message>
    <message>
        <source>Wallet encryption failed</source>
        <translation type="unfinished">Memali ya ing pamag-encrypt king wallet </translation>
    </message>
    <message>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation type="unfinished">Memali ya ing encryption uli na ning ausan dang internal error. E ya me-encrypt ing wallet yu.</translation>
    </message>
    <message>
        <source>The supplied passphrases do not match.</source>
        <translation type="unfinished">E la mitutugma ring mibieng passphrase</translation>
    </message>
    <message>
        <source>Wallet unlock failed</source>
        <translation type="unfinished">Memali ya ing pamag-unlock king wallet </translation>
    </message>
    <message>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation type="unfinished">E ya istu ing passphrase a pepalub da para king wallet decryption</translation>
    </message>
    <message>
        <source>Wallet passphrase was successfully changed.</source>
        <translation type="unfinished">Mi-alilan ne ing passphrase na ning wallet.</translation>
    </message>
    <message>
        <source>Warning: The Caps Lock key is on!</source>
        <translation type="unfinished">Kapabaluan: Makabuklat ya ing Caps Lock key!</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>unknown</source>
        <translation type="unfinished">e miya balu</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">Alaga</translation>
    </message>
    <message numerus="yes">
        <source>%n second(s)</source>
        <translation type="unfinished">
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n minute(s)</source>
        <translation type="unfinished">
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n hour(s)</source>
        <translation type="unfinished">
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n day(s)</source>
        <translation type="unfinished">
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n week(s)</source>
        <translation type="unfinished">
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n year(s)</source>
        <translation type="unfinished">
            <numerusform />
        </translation>
    </message>
    </context>
<context>
    <name>KawraGUI</name>
    <message>
        <source>Show general overview of wallet</source>
        <translation type="unfinished">Ipakit ing kabuuang lawe ning wallet</translation>
    </message>
    <message>
        <source>&amp;Transactions</source>
        <translation type="unfinished">&amp;Transaksion</translation>
    </message>
    <message>
        <source>Browse transaction history</source>
        <translation type="unfinished">Lawan ing kasalesayan ning transaksion</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation type="unfinished">L&amp;umwal</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation type="unfinished">Tuknangan ing aplikasyon</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation type="unfinished">Tungkul &amp;Qt</translation>
    </message>
    <message>
        <source>Show information about Qt</source>
        <translation type="unfinished">Magpakit impormasion tungkul king Qt</translation>
    </message>
    <message>
        <source>Send coins to a Kawra address</source>
        <translation type="unfinished">Magpadalang barya king Kawra address</translation>
    </message>
    <message>
        <source>Backup wallet to another location</source>
        <translation type="unfinished">I-backup ing wallet king aliwang lugal</translation>
    </message>
    <message>
        <source>Change the passphrase used for wallet encryption</source>
        <translation type="unfinished">Alilan ya ing passphrase a gagamitan para king wallet encryption</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation type="unfinished">&amp;Pamag-ayus</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation type="unfinished">&amp;Saup</translation>
    </message>
    <message>
        <source>Tabs toolbar</source>
        <translation type="unfinished">Gamit para king Tabs</translation>
    </message>
    <message>
        <source>&amp;Command-line options</source>
        <translation type="unfinished">Pipamilian &amp;command-line</translation>
    </message>
    <message numerus="yes">
        <source>Processed %n block(s) of transaction history.</source>
        <translation type="unfinished">
            <numerusform />
        </translation>
    </message>
    <message>
        <source>Last received block was generated %1 ago.</source>
        <translation type="unfinished">Ing tatauling block a metanggap,  me-generate ya %1 ing milabas</translation>
    </message>
    <message>
        <source>Transactions after this will not yet be visible.</source>
        <translation type="unfinished">Ing transaksion kaibat na nini ali yapa magsilbing ipakit.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">Mali</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation type="unfinished">Kapabaluan</translation>
    </message>
    <message>
        <source>Information</source>
        <translation type="unfinished">&amp;Impormasion</translation>
    </message>
    <message>
        <source>Up to date</source>
        <translation type="unfinished">Makatuki ya king aldo</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation type="unfinished">&amp;Awang</translation>
    </message>
    <message numerus="yes">
        <source>%n active connection(s) to Kawra network.</source>
        <extracomment>A substring of the tooltip.</extracomment>
        <translation type="unfinished">
            <numerusform />
        </translation>
    </message>
    <message>
        <source>Sent transaction</source>
        <translation type="unfinished">Mipadalang transaksion</translation>
    </message>
    <message>
        <source>Incoming transaction</source>
        <translation type="unfinished">Paparatang a transaksion</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation type="unfinished">Maka-&lt;b&gt;encrypt&lt;/b&gt; ya ing wallet at kasalukuyan yang maka-&lt;b&gt;unlocked&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation type="unfinished">Maka-&lt;b&gt;encrypt&lt;/b&gt; ya ing wallet at kasalukuyan yang maka-&lt;b&gt;locked&lt;/b&gt;</translation>
    </message>
    </context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Amount:</source>
        <translation type="unfinished">Alaga:</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">Alaga</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished">Kaaldauan</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation type="unfinished">Me-kumpirma</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation type="unfinished">Kopyan ing alaga</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(alang label)</translation>
    </message>
    </context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation type="unfinished">Alilan ing Address</translation>
    </message>
    <message>
        <source>New sending address</source>
        <translation type="unfinished">Bayung address king pamagpadala</translation>
    </message>
    <message>
        <source>Edit receiving address</source>
        <translation type="unfinished">Alilan ya ing address king pamagpadala</translation>
    </message>
    <message>
        <source>Edit sending address</source>
        <translation type="unfinished">Alilan ya ing address king pamagpadala</translation>
    </message>
    <message>
        <source>The entered address "%1" is not a valid Kawra address.</source>
        <translation type="unfinished">Ing pepalub yung address "%1" ali ya katanggap-tanggap a Kawra address.</translation>
    </message>
    <message>
        <source>Could not unlock wallet.</source>
        <translation type="unfinished">Ali ya bisang mag-unlock ing wallet</translation>
    </message>
    <message>
        <source>New key generation failed.</source>
        <translation type="unfinished">Memali ya ing pamangaua king key</translation>
    </message>
</context>
<context>
    <name>Intro</name>
    <message numerus="yes">
        <source>%n GB of space available</source>
        <translation type="unfinished">
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>(of %n GB needed)</source>
        <translation type="unfinished">
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>(%n GB needed for full chain)</source>
        <translation type="unfinished">
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>(sufficient to restore backups %n day(s) old)</source>
        <extracomment>Explanatory text on the capability of the current prune target.</extracomment>
        <translation type="unfinished">
            <numerusform />
        </translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">Mali</translation>
    </message>
    <message>
        <source>Welcome</source>
        <translation type="unfinished">Malaus ka</translation>
    </message>
    </context>
<context>
    <name>HelpMessageDialog</name>
    <message>
        <source>version</source>
        <translation type="unfinished">bersion</translation>
    </message>
    <message>
        <source>Command-line options</source>
        <translation type="unfinished">Pipamilian command-line</translation>
    </message>
</context>
<context>
    <name>ModalOverlay</name>
    <message>
        <source>Last block time</source>
        <translation type="unfinished">Tatauling oras na ning block</translation>
    </message>
    </context>
<context>
    <name>OpenURIDialog</name>
    <message>
        <source>Paste address from clipboard</source>
        <extracomment>Tooltip text for button that allows you to paste an address that is in your clipboard.</extracomment>
        <translation type="unfinished">Idikit ing address menibat king clipboard</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation type="unfinished">Pipamilian</translation>
    </message>
    <message>
        <source>&amp;Main</source>
        <translation type="unfinished">&amp;Pun</translation>
    </message>
    <message>
        <source>Automatically open the Kawra client port on the router. This only works when your router supports UPnP and it is enabled.</source>
        <translation type="unfinished">Ibuklat yang antimanu ing Kawra client port king router. Gagana yamu ini istung ing router mu susuporta yang UPnP at magsilbi ya.</translation>
    </message>
    <message>
        <source>Map port using &amp;UPnP</source>
        <translation type="unfinished">Mapa ng ning port gamit ing &amp;UPnP</translation>
    </message>
    <message>
        <source>Port of the proxy (e.g. 9050)</source>
        <translation type="unfinished">Port na ning proxy(e.g. 9050)</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation type="unfinished">&amp;Awang</translation>
    </message>
    <message>
        <source>Show only a tray icon after minimizing the window.</source>
        <translation type="unfinished">Ipakit mu ing tray icon kaibat meng pelatian ing awang.</translation>
    </message>
    <message>
        <source>&amp;Minimize to the tray instead of the taskbar</source>
        <translation type="unfinished">&amp;Latian ya ing tray kesa king taskbar</translation>
    </message>
    <message>
        <source>M&amp;inimize on close</source>
        <translation type="unfinished">P&amp;alatian istung isara</translation>
    </message>
    <message>
        <source>&amp;Display</source>
        <translation type="unfinished">&amp;Ipalto</translation>
    </message>
    <message>
        <source>User Interface &amp;language:</source>
        <translation type="unfinished">Amanu na ning user interface:</translation>
    </message>
    <message>
        <source>&amp;Unit to show amounts in:</source>
        <translation type="unfinished">Ing &amp;Unit a ipakit king alaga ning:</translation>
    </message>
    <message>
        <source>Choose the default subdivision unit to show in the interface and when sending coins.</source>
        <translation type="unfinished">Pilinan ing default subdivision unit a ipalto o ipakit king interface at istung magpadala kang barya.</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="unfinished">I-&amp;Cancel</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">Mali</translation>
    </message>
    <message>
        <source>The supplied proxy address is invalid.</source>
        <translation type="unfinished">Ing milageng proxy address eya katanggap-tanggap.</translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>The displayed information may be out of date. Your wallet automatically synchronizes with the Kawra network after a connection is established, but this process has not completed yet.</source>
        <translation type="unfinished">Ing makaltong impormasion mapalyaring luma ne. Ing kekang wallet otomatiku yang mag-synchronize keng Kawra network istung mekakonekta ne king network, oneng ing prosesung ini ali ya pa kumpletu.</translation>
    </message>
    <message>
        <source>Your current spendable balance</source>
        <translation type="unfinished">Ing kekang kasalungsungan balanse a malyari mung gastusan</translation>
    </message>
    <message>
        <source>Total of transactions that have yet to be confirmed, and do not yet count toward the spendable balance</source>
        <translation type="unfinished">Ing kabuuan dareng transaksion a kasalungsungan ali pa me-kumpirma, at kasalungsungan ali pa mebilang kareng kekang balanseng malyari mung gastusan</translation>
    </message>
    <message>
        <source>Mined balance that has not yet matured</source>
        <translation type="unfinished">Reng me-minang balanse a epa meg-matured</translation>
    </message>
    <message>
        <source>Total:</source>
        <translation type="unfinished">Kabuuan:</translation>
    </message>
    <message>
        <source>Your current total balance</source>
        <translation type="unfinished">Ing kekang kasalungsungan kabuuang balanse</translation>
    </message>
    </context>
<context>
    <name>PeerTableModel</name>
    <message>
        <source>Type</source>
        <extracomment>Title of Peers Table column which describes the type of peer connection. The "type" describes why the connection exists.</extracomment>
        <translation type="unfinished">Klase</translation>
    </message>
    </context>
<context>
    <name>RPCConsole</name>
    <message>
        <source>Client version</source>
        <translation type="unfinished">Bersion ning Cliente</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation type="unfinished">&amp;Impormasion</translation>
    </message>
    <message>
        <source>Startup time</source>
        <translation type="unfinished">Oras ning umpisa</translation>
    </message>
    <message>
        <source>Number of connections</source>
        <translation type="unfinished">Bilang dareng koneksion</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation type="unfinished">Tatauling oras na ning block</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation type="unfinished">&amp;Ibuklat</translation>
    </message>
    <message>
        <source>Totals</source>
        <translation type="unfinished">Kabuuan:</translation>
    </message>
    <message>
        <source>Clear console</source>
        <translation type="unfinished">I-Clear ing console</translation>
    </message>
    <message>
        <source>To</source>
        <translation type="unfinished">Para kang</translation>
    </message>
    <message>
        <source>From</source>
        <translation type="unfinished">Menibat</translation>
    </message>
    </context>
<context>
    <name>ReceiveCoinsDialog</name>
    <message>
        <source>Could not unlock wallet.</source>
        <translation type="unfinished">Ali ya bisang mag-unlock ing wallet</translation>
    </message>
    </context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>Amount:</source>
        <translation type="unfinished">Alaga:</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation type="unfinished">Mensayi:</translation>
    </message>
    <message>
        <source>Copy &amp;Address</source>
        <translation type="unfinished">&amp;Kopyan ing address</translation>
    </message>
    </context>
<context>
    <name>RecentRequestsTableModel</name>
    <message>
        <source>Date</source>
        <translation type="unfinished">Kaaldauan</translation>
    </message>
    <message>
        <source>Message</source>
        <translation type="unfinished">Mensayi</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(alang label)</translation>
    </message>
    </context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Send Coins</source>
        <translation type="unfinished">Magpadalang Barya</translation>
    </message>
    <message>
        <source>Insufficient funds!</source>
        <translation type="unfinished">Kulang a pondo</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation type="unfinished">Alaga:</translation>
    </message>
    <message>
        <source>Transaction Fee:</source>
        <translation type="unfinished">Bayad king Transaksion:</translation>
    </message>
    <message>
        <source>Send to multiple recipients at once</source>
        <translation type="unfinished">Misanang magpadala kareng alialiuang tumanggap</translation>
    </message>
    <message>
        <source>Add &amp;Recipient</source>
        <translation type="unfinished">Maglage &amp;Tumanggap</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation type="unfinished">I-Clear &amp;Eganagana</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation type="unfinished">Balanse:</translation>
    </message>
    <message>
        <source>Confirm the send action</source>
        <translation type="unfinished">Kumpirman ing aksion king pamagpadala</translation>
    </message>
    <message>
        <source>S&amp;end</source>
        <translation type="unfinished">&amp;Ipadala</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation type="unfinished">Kopyan ing alaga</translation>
    </message>
    <message>
        <source>Transaction fee</source>
        <translation type="unfinished">Bayad king Transaksion</translation>
    </message>
    <message>
        <source>Confirm send coins</source>
        <translation type="unfinished">Kumpirman ing pamagpadalang barya</translation>
    </message>
    <message>
        <source>The amount to pay must be larger than 0.</source>
        <translation type="unfinished">Ing alaga na ning bayaran dapat mung mas matas ya king 0.</translation>
    </message>
    <message>
        <source>The amount exceeds your balance.</source>
        <translation type="unfinished">Ing alaga mipasobra ya king kekang balanse.</translation>
    </message>
    <message>
        <source>The total exceeds your balance when the %1 transaction fee is included.</source>
        <translation type="unfinished">Ing kabuuan mipasobra ya king kekang balanse istung inabe ya ing %1 a bayad king transaksion </translation>
    </message>
    <message numerus="yes">
        <source>Estimated to begin confirmation within %n block(s).</source>
        <translation type="unfinished">
            <numerusform />
        </translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(alang label)</translation>
    </message>
</context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>A&amp;mount:</source>
        <translation type="unfinished">A&amp;laga:</translation>
    </message>
    <message>
        <source>Pay &amp;To:</source>
        <translation type="unfinished">Ibayad &amp;kang:</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation type="unfinished">Idikit ing address menibat king clipboard</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation type="unfinished">Mensayi:</translation>
    </message>
    </context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>Signatures - Sign / Verify a Message</source>
        <translation type="unfinished">Pirma - Pirman / I-beripika ing mensayi</translation>
    </message>
    <message>
        <source>&amp;Sign Message</source>
        <translation type="unfinished">&amp;Pirman ing Mensayi</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation type="unfinished">Idikit ing address menibat king clipboard</translation>
    </message>
    <message>
        <source>Enter the message you want to sign here</source>
        <translation type="unfinished">Ipalub ing mensayi a buri mung pirman keni</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation type="unfinished">Pirma</translation>
    </message>
    <message>
        <source>Copy the current signature to the system clipboard</source>
        <translation type="unfinished">Kopyan ing kasalungsungan pirma king system clipboard</translation>
    </message>
    <message>
        <source>Sign the message to prove you own this Kawra address</source>
        <translation type="unfinished">Pirman ing mensayi ban patune na keka ya ining Kawra address</translation>
    </message>
    <message>
        <source>Sign &amp;Message</source>
        <translation type="unfinished">Pirman ing &amp;Mensayi</translation>
    </message>
    <message>
        <source>Reset all sign message fields</source>
        <translation type="unfinished">Ibalik keng dati reng ngan fields keng pamamirmang mensayi</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation type="unfinished">I-Clear &amp;Eganagana</translation>
    </message>
    <message>
        <source>&amp;Verify Message</source>
        <translation type="unfinished">&amp;Beripikan ing Mensayi</translation>
    </message>
    <message>
        <source>Verify the message to ensure it was signed with the specified Kawra address</source>
        <translation type="unfinished">Beripikan ing mensayi ban asiguradu a me pirma ya ini gamit ing mepiling Kawra address</translation>
    </message>
    <message>
        <source>Verify &amp;Message</source>
        <translation type="unfinished">Beripikan ing &amp;Mensayi</translation>
    </message>
    <message>
        <source>Reset all verify message fields</source>
        <translation type="unfinished">Ibalik king dati reng ngan fields na ning pamag beripikang mensayi</translation>
    </message>
    <message>
        <source>Click "Sign Message" to generate signature</source>
        <translation type="unfinished">I-click ing "Pirman ing Mensayi" ban agawa ya ing metung a pirma</translation>
    </message>
    <message>
        <source>The entered address is invalid.</source>
        <translation type="unfinished">Ing milub a address e ya katanggap-tanggap.</translation>
    </message>
    <message>
        <source>Please check the address and try again.</source>
        <translation type="unfinished">Maliaring pakilawe pasibayu ing address at pasibayuan ya iti.</translation>
    </message>
    <message>
        <source>The entered address does not refer to a key.</source>
        <translation type="unfinished">Ing milub a address ali ya mag-refer king metung a key.</translation>
    </message>
    <message>
        <source>Wallet unlock was cancelled.</source>
        <translation type="unfinished">Me-kansela ya ing pamag-unlock king wallet.</translation>
    </message>
    <message>
        <source>Private key for the entered address is not available.</source>
        <translation type="unfinished">Ing private key para king milub a address, ala ya.</translation>
    </message>
    <message>
        <source>Message signing failed.</source>
        <translation type="unfinished">Me-mali ya ing pamag-pirma king mensayi .</translation>
    </message>
    <message>
        <source>Message signed.</source>
        <translation type="unfinished">Me-pirman ne ing mensayi.</translation>
    </message>
    <message>
        <source>The signature could not be decoded.</source>
        <translation type="unfinished">Ing pirma ali ya bisang ma-decode.</translation>
    </message>
    <message>
        <source>Please check the signature and try again.</source>
        <translation type="unfinished">Maliaring pakilawe pasibayu ing pirma kaibat pasibayuan ya iti.</translation>
    </message>
    <message>
        <source>The signature did not match the message digest.</source>
        <translation type="unfinished">Ing pirma ali ya makatugma king message digest.</translation>
    </message>
    <message>
        <source>Message verification failed.</source>
        <translation type="unfinished">Me-mali ya ing pamag-beripika king mensayi.</translation>
    </message>
    <message>
        <source>Message verified.</source>
        <translation type="unfinished">Me-beripika ne ing mensayi.</translation>
    </message>
</context>
<context>
    <name>TransactionDesc</name>
    <message>
        <source>%1/unconfirmed</source>
        <extracomment>Text explaining the current status of a transaction, shown in the status field of the details window for this transaction. This status represents a transaction confirmed in at least one block, but less than 6 blocks.</extracomment>
        <translation type="unfinished">%1/ali me-kumpirma</translation>
    </message>
    <message>
        <source>%1 confirmations</source>
        <extracomment>Text explaining the current status of a transaction, shown in the status field of the details window for this transaction. This status represents a transaction confirmed in 6 or more blocks.</extracomment>
        <translation type="unfinished">%1 kumpirmasion</translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished">Kabilian</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished">Kaaldauan</translation>
    </message>
    <message>
        <source>Source</source>
        <translation type="unfinished">Pikuanan</translation>
    </message>
    <message>
        <source>Generated</source>
        <translation type="unfinished">Megawa</translation>
    </message>
    <message>
        <source>From</source>
        <translation type="unfinished">Menibat</translation>
    </message>
    <message>
        <source>unknown</source>
        <translation type="unfinished">e miya balu</translation>
    </message>
    <message>
        <source>To</source>
        <translation type="unfinished">Para kang</translation>
    </message>
    <message>
        <source>own address</source>
        <translation type="unfinished">sariling address</translation>
    </message>
    <message numerus="yes">
        <source>matures in %n more block(s)</source>
        <translation type="unfinished">
            <numerusform />
        </translation>
    </message>
    <message>
        <source>not accepted</source>
        <translation type="unfinished">ali metanggap</translation>
    </message>
    <message>
        <source>Transaction fee</source>
        <translation type="unfinished">Bayad king Transaksion</translation>
    </message>
    <message>
        <source>Net amount</source>
        <translation type="unfinished">Alaga dareng eganagana</translation>
    </message>
    <message>
        <source>Message</source>
        <translation type="unfinished">Mensayi</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation type="unfinished">Komentu</translation>
    </message>
    <message>
        <source>Transaction ID</source>
        <translation type="unfinished">ID</translation>
    </message>
    <message>
        <source>Debug information</source>
        <translation type="unfinished">Impormasion ning Debug</translation>
    </message>
    <message>
        <source>Transaction</source>
        <translation type="unfinished">Transaksion</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">Alaga</translation>
    </message>
    <message>
        <source>true</source>
        <translation type="unfinished">tutu</translation>
    </message>
    <message>
        <source>false</source>
        <translation type="unfinished">e tutu</translation>
    </message>
</context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <source>This pane shows a detailed description of the transaction</source>
        <translation type="unfinished">Ining pane a ini magpakit yang detalyadung description ning transaksion</translation>
    </message>
    </context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Date</source>
        <translation type="unfinished">Kaaldauan</translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished">Klase</translation>
    </message>
    <message>
        <source>Confirmed (%1 confirmations)</source>
        <translation type="unfinished">Me-kumpirma(%1 kumpirmasion)</translation>
    </message>
    <message>
        <source>Generated but not accepted</source>
        <translation type="unfinished">Me-generate ya oneng ali ya metanggap</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation type="unfinished">Atanggap kayabe ning</translation>
    </message>
    <message>
        <source>Received from</source>
        <translation type="unfinished">Atanggap menibat kang</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation type="unfinished">Mipadala kang</translation>
    </message>
    <message>
        <source>Payment to yourself</source>
        <translation type="unfinished">Kabayaran keka</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation type="unfinished">Me-mina</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(alang label)</translation>
    </message>
    <message>
        <source>Transaction status. Hover over this field to show number of confirmations.</source>
        <translation type="unfinished">Status ning Transaksion: Itapat me babo na ning field a ini ban ipakit dala reng bilang dareng me-kumpirma na</translation>
    </message>
    <message>
        <source>Date and time that the transaction was received.</source>
        <translation type="unfinished">Aldo at oras nung kapilan me tanggap ya ing transaksion</translation>
    </message>
    <message>
        <source>Type of transaction.</source>
        <translation type="unfinished">Klase ning transaksion</translation>
    </message>
    <message>
        <source>Amount removed from or added to balance.</source>
        <translation type="unfinished">Alagang milako o miragdag king balanse.</translation>
    </message>
</context>
<context>
    <name>TransactionView</name>
    <message>
        <source>All</source>
        <translation type="unfinished">Eganagana</translation>
    </message>
    <message>
        <source>Today</source>
        <translation type="unfinished">Aldo iti</translation>
    </message>
    <message>
        <source>This week</source>
        <translation type="unfinished">Paruminggung iti</translation>
    </message>
    <message>
        <source>This month</source>
        <translation type="unfinished">Bulan a iti</translation>
    </message>
    <message>
        <source>Last month</source>
        <translation type="unfinished">Milabas a bulan</translation>
    </message>
    <message>
        <source>This year</source>
        <translation type="unfinished">Banuang iti</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation type="unfinished">Atanggap kayabe ning</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation type="unfinished">Mipadala kang</translation>
    </message>
    <message>
        <source>To yourself</source>
        <translation type="unfinished">Keng sarili mu</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation type="unfinished">Me-mina</translation>
    </message>
    <message>
        <source>Other</source>
        <translation type="unfinished">Aliwa</translation>
    </message>
    <message>
        <source>Min amount</source>
        <translation type="unfinished">Pekaditak a alaga</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation type="unfinished">Me-kumpirma</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished">Kaaldauan</translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished">Klase</translation>
    </message>
    <message>
        <source>Range:</source>
        <translation type="unfinished">Angga:</translation>
    </message>
    <message>
        <source>to</source>
        <translation type="unfinished">para kang</translation>
    </message>
</context>
<context>
    <name>WalletFrame</name>
    <message>
        <source>Error</source>
        <translation type="unfinished">Mali</translation>
    </message>
    </context>
<context>
    <name>WalletModel</name>
    <message>
        <source>Send Coins</source>
        <translation type="unfinished">Magpadalang Barya</translation>
    </message>
    </context>
<context>
    <name>kawra-core</name>
    <message>
        <source>Corrupted block database detected</source>
        <translation type="unfinished">Mekapansin lang me-corrupt a block database</translation>
    </message>
    <message>
        <source>Do you want to rebuild the block database now?</source>
        <translation type="unfinished">Buri meng buuan pasibayu ing block database ngene?</translation>
    </message>
    <message>
        <source>Done loading</source>
        <translation type="unfinished">Yari ne ing pamag-load</translation>
    </message>
    <message>
        <source>Error initializing block database</source>
        <translation type="unfinished">Kamalian king pamag-initialize king block na ning database</translation>
    </message>
    <message>
        <source>Error opening block database</source>
        <translation type="unfinished">Kamalian king pamag buklat king block database</translation>
    </message>
    <message>
        <source>Failed to listen on any port. Use -listen=0 if you want this.</source>
        <translation type="unfinished">Memali ya ing pamakiramdam kareng gang nanung port. Gamita me ini -listen=0 nung buri me ini.</translation>
    </message>
    <message>
        <source>Insufficient funds</source>
        <translation type="unfinished">Kulang a pondo</translation>
    </message>
    <message>
        <source>Transaction too large</source>
        <translation type="unfinished">Maragul yang masiadu ing transaksion</translation>
    </message>
    <message>
        <source>Unknown network specified in -onlynet: '%s'</source>
        <translation type="unfinished">E kilalang network ing mepili king -onlynet: '%s'</translation>
    </message>
    </context>
</TS>