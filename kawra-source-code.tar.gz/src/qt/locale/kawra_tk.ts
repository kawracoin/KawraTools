<TS version="2.1" language="tk">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Right-click to edit address or label</source>
        <translation type="unfinished">Salgyny ýa-da belligi rejelemek üçin syçanjygyň sag düwmesine basyň</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation type="unfinished">Täze salgy döret</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation type="unfinished">&amp;Täze</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation type="unfinished">Häzir saýlanan salgyny ulgamyň alyş-çalyş paneline göçür</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation type="unfinished">&amp;Göçür</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation type="unfinished">Ý&amp;ap</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation type="unfinished">Häzir saýlanan salgyny bu sanawdan poz</translation>
    </message>
    <message>
        <source>Enter address or label to search</source>
        <translation type="unfinished">Gözlemek üçin salgy ýa-da belligi ýaz</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation type="unfinished">Häzirki bellikdäki maglumaty faýla geçir</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation type="unfinished">&amp;Geçir</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation type="unfinished">&amp;Poz</translation>
    </message>
    <message>
        <source>Choose the address to send coins to</source>
        <translation type="unfinished">Teňňeleriň haýsy salga iberiljekdigini saýla</translation>
    </message>
    <message>
        <source>Choose the address to receive coins with</source>
        <translation type="unfinished">Teňňeleriň haýsy salgydan alynjakdygyny saýla</translation>
    </message>
    <message>
        <source>C&amp;hoose</source>
        <translation type="unfinished">S&amp;aýla</translation>
    </message>
    <message>
        <source>Sending addresses</source>
        <translation type="unfinished">Iberýän salgylar</translation>
    </message>
    <message>
        <source>Receiving addresses</source>
        <translation type="unfinished">Kabul edýän salgylar</translation>
    </message>
    <message>
        <source>These are your Kawra addresses for sending payments. Always check the amount and the receiving address before sending coins.</source>
        <translation type="unfinished">Tölegleri ibermek üçin siziň Bitkoin salgylaryňyz şulardyr. Teňňeleri ibermezden ozal hemişe möçberi we kabul edýän salgyny barlaň.</translation>
    </message>
    <message>
        <source>These are your Kawra addresses for receiving payments. Use the 'Create new receiving address' button in the receive tab to create new addresses.
Signing is only possible with addresses of the type 'legacy'.</source>
        <translation type="unfinished">Tölegleri kabul etmek üçin siziň Bitkoin salgylaryňyz şulardyr. Täze salgylary döretmek üçin kabul etmek bölüminde "Täze kabul ediji salgyny döret" düwmesini ulan.
Diňe "miras" görnüşli salgylar bilen gol çekmek mümkin.</translation>
    </message>
    <message>
        <source>&amp;Copy Address</source>
        <translation type="unfinished">Salgyny göçür</translation>
    </message>
    <message>
        <source>Copy &amp;Label</source>
        <translation type="unfinished">&amp;Belligi göçür</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation type="unfinished">&amp;Rejele</translation>
    </message>
    <message>
        <source>Export Address List</source>
        <translation type="unfinished">Salgylar sanawyny geçir</translation>
    </message>
    <message>
        <source>Comma separated file</source>
        <extracomment>Expanded name of the CSV file format. See: https://en.wikipedia.org/wiki/Comma-separated_values.</extracomment>
        <translation type="unfinished">Otur bilen aýrylan faýl</translation>
    </message>
    <message>
        <source>There was an error trying to save the address list to %1. Please try again.</source>
        <extracomment>An error message. %1 is a stand-in argument for the name of the file we attempted to save to.</extracomment>
        <translation type="unfinished">Salgylar sanawyny %1 içine bellemäge çalşylanda ýalňyşlyk ýüze çykdy. Täzeden synap görüň.</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation type="unfinished">Geçirip bolmady</translation>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Label</source>
        <translation type="unfinished">Bellik</translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="unfinished">Salgy</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(bellik ýok)</translation>
    </message>
</context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Passphrase Dialog</source>
        <translation type="unfinished">Parol sözlemi gepleşigi</translation>
    </message>
    <message>
        <source>Enter passphrase</source>
        <translation type="unfinished">Parol sözlemini ýaz</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation type="unfinished">Täze parol sözlemi</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation type="unfinished">Täze parol sözlemini gaýtala</translation>
    </message>
    <message>
        <source>Show passphrase</source>
        <translation type="unfinished">Parol sözlemini görkez</translation>
    </message>
    <message>
        <source>Encrypt wallet</source>
        <translation type="unfinished">Gapjygy şifrle</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation type="unfinished">Bu amal üçin gapjygyň parol sözlemi bilen gapjygyňyzyň gulpuny açmagyňyz gerek.</translation>
    </message>
    <message>
        <source>Unlock wallet</source>
        <translation type="unfinished">Gapjygyň gulpuny aç</translation>
    </message>
    <message>
        <source>Change passphrase</source>
        <translation type="unfinished">Parol sözlemini çalyş</translation>
    </message>
    <message>
        <source>Confirm wallet encryption</source>
        <translation type="unfinished">Gapjygyň şifrlenmegini tassykla</translation>
    </message>
    <message>
        <source>Warning: If you encrypt your wallet and lose your passphrase, you will &lt;b&gt;LOSE ALL OF YOUR KAWRAS&lt;/b&gt;!</source>
        <translation type="unfinished">Duýduryş: Eger gapjygyňy şifrleseň we parol sözlemiňi ýitirseň, sen &lt;b&gt;ÄHLI BITKOINLERIŇI ÝITIRERSIŇ&lt;/b&gt;!</translation>
    </message>
    <message>
        <source>Are you sure you wish to encrypt your wallet?</source>
        <translation type="unfinished">Gapjygyňy şifrlemek isleýäniň çynmy?</translation>
    </message>
    <message>
        <source>Wallet encrypted</source>
        <translation type="unfinished">Gapjyk şifrlenen</translation>
    </message>
    <message>
        <source>Enter the new passphrase for the wallet.&lt;br/&gt;Please use a passphrase of &lt;b&gt;ten or more random characters&lt;/b&gt;, or &lt;b&gt;eight or more words&lt;/b&gt;.</source>
        <translation type="unfinished">Gapjyk üçin täze parol sözlemini ýaz.&lt;br/&gt;&lt;b&gt;On ýa-da has köp tötänleýin nyşandan&lt;/b&gt; ýa-da &lt;b&gt;sekiz ýa-da has köp sözden&lt;/b&gt; ybarat parol sözlemini ulanyň.</translation>
    </message>
    <message>
        <source>Enter the old passphrase and new passphrase for the wallet.</source>
        <translation type="unfinished">Gapjyk üçin öňki we täze parol sözlemiňi ýaz.</translation>
    </message>
    <message>
        <source>Remember that encrypting your wallet cannot fully protect your kawras from being stolen by malware infecting your computer.</source>
        <translation type="unfinished">Gapjygyňy şifrlemek kompýuteriňe zyýanly programma ýokuşmak arkaly bitkoinleriň ogurlanmagyndan doly gorap bilmejekdigini ýatdan çykarma.</translation>
    </message>
    <message>
        <source>Wallet to be encrypted</source>
        <translation type="unfinished">Şifrlenmeli gapjyk</translation>
    </message>
    <message>
        <source>Your wallet is about to be encrypted. </source>
        <translation type="unfinished">Gapjygyň şifrlener.</translation>
    </message>
    <message>
        <source>Your wallet is now encrypted. </source>
        <translation type="unfinished">Gapjygyň häzir şifrlenen.</translation>
    </message>
    <message>
        <source>IMPORTANT: Any previous backups you have made of your wallet file should be replaced with the newly generated, encrypted wallet file. For security reasons, previous backups of the unencrypted wallet file will become useless as soon as you start using the new, encrypted wallet.</source>
        <translation type="unfinished">WAJYP: Gapjyk faýlyň islendik ozalky ätiýaçlyk nusgalary täze emele gelen, şifrlenen gapjyk faýly bilen çalşyrylmaly. Howpsuzlyk maksady bilen, şifrlenen gapjyk faýlynyň ozalky ätiýaçlyk nusgalary täze şifrlenen gapjygy ulanyp başlan badyňyza peýdasyz bolup galar.</translation>
    </message>
    <message>
        <source>Wallet encryption failed</source>
        <translation type="unfinished">Gapjygy şifrläp bolmady</translation>
    </message>
    <message>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation type="unfinished">Içki ýalňyşlyk sebäpli gapjygy şifrläp bolmady. Gapjygyň şifrlenmedi.</translation>
    </message>
    <message>
        <source>The supplied passphrases do not match.</source>
        <translation type="unfinished">Üpjün edilen parol sözlemleri gabat gelenok.</translation>
    </message>
    <message>
        <source>Wallet unlock failed</source>
        <translation type="unfinished">Gapjygyň gulpuny açyp bolmady</translation>
    </message>
    <message>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation type="unfinished">Gapjygyň şifrini açmak üçin ýazylan parol sözlemi nädogry.</translation>
    </message>
    <message>
        <source>Wallet passphrase was successfully changed.</source>
        <translation type="unfinished">Gapjygyň parol sözlemi üstünlikli çalşyldy.</translation>
    </message>
    <message>
        <source>Warning: The Caps Lock key is on!</source>
        <translation type="unfinished">Duýduryş: Caps Lock düwmesi açyk!</translation>
    </message>
</context>
<context>
    <name>BanTableModel</name>
    <message>
        <source>Banned Until</source>
        <translation type="unfinished">Gadagan edilen möhleti</translation>
    </message>
</context>
<context>
    <name>KawraApplication</name>
    <message>
        <source>Runaway exception</source>
        <translation type="unfinished">Dolandyryp bolmaýan ýagdaý</translation>
    </message>
    <message>
        <source>A fatal error occurred. %1 can no longer continue safely and will quit.</source>
        <translation type="unfinished">Ýowuz ýalňyşlyk ýüze çykdy. %1 indi ygtybarly dowam edip bilenok we çykar.</translation>
    </message>
    <message>
        <source>Internal error</source>
        <translation type="unfinished">Içki ýalňyşlyk</translation>
    </message>
    <message>
        <source>An internal error occurred. %1 will attempt to continue safely. This is an unexpected bug which can be reported as described below.</source>
        <translation type="unfinished">Içki ýalňyşlyk ýüze çykdy. %1 ygtybarly dowam etmäge çalyşar. Bu garaşylmadyk näsazlyk we ol barada aşakda beýan edilişi ýaly hasabat berip bolar.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Do you want to reset settings to default values, or to abort without making changes?</source>
        <extracomment>Explanatory text shown on startup when the settings file cannot be read. Prompts user to make a choice between resetting or aborting.</extracomment>
        <translation type="unfinished">Sazlamalary deslapky ýagdaýyna getirmek isleýäňmi ýa-da hiçhili üýtgeşme girizmezden ýatyrmak?</translation>
    </message>
    <message>
        <source>A fatal error occurred. Check that settings file is writable, or try running with -nosettings.</source>
        <extracomment>Explanatory text shown on startup when the settings file could not be written. Prompts user to check that we have the ability to write to the file. Explains that the user has the option of running without a settings file.</extracomment>
        <translation type="unfinished">Ýowuz ýalňyşlyk ýüze çykdy. Sazlamalar faýlyna ýazmak mümkinçiliginiň bardygyny ýa-da ýokdugyny barla, bolmasa -nosettings bilen işletmäge çalyş.</translation>
    </message>
    <message>
        <source>Error: %1</source>
        <translation type="unfinished">Ýalňyşlyk: %1</translation>
    </message>
    <message>
        <source>%1 didn't yet exit safely…</source>
        <translation type="unfinished">%1 entek ygtybarly çykmady...</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">Möçber</translation>
    </message>
    <message numerus="yes">
        <source>%n second(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n minute(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n hour(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n day(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n week(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n year(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    </context>
<context>
    <name>KawraGUI</name>
    <message>
        <source>&amp;Overview</source>
        <translation type="unfinished">&amp;Umumy syn</translation>
    </message>
    <message>
        <source>Show general overview of wallet</source>
        <translation type="unfinished">Gapjygyň umumy synyny görkez</translation>
    </message>
    <message>
        <source>&amp;Transactions</source>
        <translation type="unfinished">&amp;Amallar</translation>
    </message>
    <message>
        <source>Browse transaction history</source>
        <translation type="unfinished">Amallaryň geçmişine göz aýla</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation type="unfinished">Ç&amp;yk</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation type="unfinished">Programmadan çyk</translation>
    </message>
    <message>
        <source>&amp;About %1</source>
        <translation type="unfinished">%1 &amp;barada</translation>
    </message>
    <message>
        <source>Show information about %1</source>
        <translation type="unfinished">%1 barada maglumat görkez</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation type="unfinished">&amp;Qt barada</translation>
    </message>
    <message>
        <source>Show information about Qt</source>
        <translation type="unfinished">Qt barada maglumat görkez</translation>
    </message>
    <message>
        <source>Modify configuration options for %1</source>
        <translation type="unfinished">%1 üçin konfigurasiýa opsiýalaryny üýtget</translation>
    </message>
    <message>
        <source>Create a new wallet</source>
        <translation type="unfinished">Taze gapjyk döret</translation>
    </message>
    <message>
        <source>&amp;Minimize</source>
        <translation type="unfinished">&amp;Kiçelt</translation>
    </message>
    <message>
        <source>Wallet:</source>
        <translation type="unfinished">Gapjyk:</translation>
    </message>
    <message>
        <source>Network activity disabled.</source>
        <extracomment>A substring of the tooltip.</extracomment>
        <translation type="unfinished">Tor işleýşi ýapyk.</translation>
    </message>
    <message>
        <source>Proxy is &lt;b&gt;enabled&lt;/b&gt;: %1</source>
        <translation type="unfinished">Proksi &lt;b&gt;işleýär&lt;/b&gt;: %1</translation>
    </message>
    <message>
        <source>Send coins to a Kawra address</source>
        <translation type="unfinished">Bitkoin salgysyna teňňeleri iber</translation>
    </message>
    <message>
        <source>Backup wallet to another location</source>
        <translation type="unfinished">Gapjygyň ätiýaçlyk nusgasyny başga ýere goý</translation>
    </message>
    <message>
        <source>Change the passphrase used for wallet encryption</source>
        <translation type="unfinished">Gapjygy şifrlemek üçin ulanylan parol sözlemini üýtget</translation>
    </message>
    <message>
        <source>&amp;Send</source>
        <translation type="unfinished">&amp;Iber</translation>
    </message>
    <message>
        <source>&amp;Receive</source>
        <translation type="unfinished">&amp;Kabul edip al</translation>
    </message>
    <message>
        <source>&amp;Options…</source>
        <translation type="unfinished">&amp;Opsiýalar…</translation>
    </message>
    <message>
        <source>&amp;Encrypt Wallet…</source>
        <translation type="unfinished">&amp;Gapjygy şifrle…</translation>
    </message>
    <message>
        <source>Encrypt the private keys that belong to your wallet</source>
        <translation type="unfinished">Gapjygyňa degişli hususy açarlary şifrle</translation>
    </message>
    <message>
        <source>&amp;Backup Wallet…</source>
        <translation type="unfinished">&amp;Gapjygyň ätiýaçlyk nusgasyny sakla…</translation>
    </message>
    <message>
        <source>&amp;Change Passphrase…</source>
        <translation type="unfinished">&amp;Parol sözlemini çalyş...</translation>
    </message>
    <message>
        <source>Sign &amp;message…</source>
        <translation type="unfinished">&amp;Habara gol çek…</translation>
    </message>
    <message>
        <source>Sign messages with your Kawra addresses to prove you own them</source>
        <translation type="unfinished">Bitkoin salgylarynyň eýesidigini subut etmek üçin habarlara öz Bitkoin salgylaryň bilen gol çek</translation>
    </message>
    <message>
        <source>&amp;Verify message…</source>
        <translation type="unfinished">&amp;Habary tassykla…</translation>
    </message>
    <message>
        <source>Verify messages to ensure they were signed with specified Kawra addresses</source>
        <translation type="unfinished">Habarlaryň görkezilen Bitkoin salgylary bilen gol çekilendigini kepillendirmek üçin habarlary tassykla</translation>
    </message>
    <message>
        <source>&amp;Load PSBT from file…</source>
        <translation type="unfinished">Faýldan BGÇBA &amp;ýükle…</translation>
    </message>
    <message>
        <source>Open &amp;URI…</source>
        <translation type="unfinished">&amp;URI aç…</translation>
    </message>
    <message>
        <source>Close Wallet…</source>
        <translation type="unfinished">Gapjygy ýap...</translation>
    </message>
    <message>
        <source>Create Wallet…</source>
        <translation type="unfinished">Gapjyk döret...</translation>
    </message>
    <message>
        <source>Close All Wallets…</source>
        <translation type="unfinished">Ähli gapjyklary ýap...</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation type="unfinished">&amp;Faýl</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation type="unfinished">&amp;Sazlamalar</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation type="unfinished">&amp;Kömek</translation>
    </message>
    <message>
        <source>Tabs toolbar</source>
        <translation type="unfinished">Bölümler gurallar paneli</translation>
    </message>
    <message>
        <source>Syncing Headers (%1%)…</source>
        <translation type="unfinished">Sözbaşylary sinhron ýagdaýa getirmek (%1%)...</translation>
    </message>
    <message>
        <source>Synchronizing with network…</source>
        <translation type="unfinished">Tor bilen sinhronlaşdyrmak...</translation>
    </message>
    <message>
        <source>Indexing blocks on disk…</source>
        <translation type="unfinished">Diskde bloklar indekslenýär...</translation>
    </message>
    <message>
        <source>Processing blocks on disk…</source>
        <translation type="unfinished">Diskde bloklar işlenýär...</translation>
    </message>
    <message>
        <source>Connecting to peers…</source>
        <translation type="unfinished">Deňdeşlere baglanylýar...</translation>
    </message>
    <message>
        <source>Request payments (generates QR codes and kawra: URIs)</source>
        <translation type="unfinished">Tölegleri sora (QR kodlary we bitkoin: URIleri döredýär)</translation>
    </message>
    <message>
        <source>Show the list of used sending addresses and labels</source>
        <translation type="unfinished">Ulanylan iberilýän salgylaryň we bellikleriň sanawyny görkez</translation>
    </message>
    <message>
        <source>Show the list of used receiving addresses and labels</source>
        <translation type="unfinished">Ulanylan kabul edip alýan salgylaryň we bellikleriň sanawyny görkez</translation>
    </message>
    <message>
        <source>&amp;Command-line options</source>
        <translation type="unfinished">&amp;Buýruk setiri opsiýalary</translation>
    </message>
    <message numerus="yes">
        <source>Processed %n block(s) of transaction history.</source>
        <translation type="unfinished">
            <numerusform>Amallar geçmişinden %n blok(lar) işlendi.</numerusform>
            <numerusform>Amallar geçmişinden %n blok(lar) işlendi.</numerusform>
        </translation>
    </message>
    <message>
        <source>%1 behind</source>
        <translation type="unfinished">%1 galdy</translation>
    </message>
    <message>
        <source>Catching up…</source>
        <translation type="unfinished">Tutulýar...</translation>
    </message>
    <message>
        <source>Last received block was generated %1 ago.</source>
        <translation type="unfinished">Soňky kabul edilen blok %1 öň döredilipdi.</translation>
    </message>
    <message>
        <source>Transactions after this will not yet be visible.</source>
        <translation type="unfinished">Mundan soňky geleşikler entek görünmez.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">Ýalňyşlyk</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation type="unfinished">Duýduryş</translation>
    </message>
    <message>
        <source>Information</source>
        <translation type="unfinished">Maglumat</translation>
    </message>
    <message>
        <source>Up to date</source>
        <translation type="unfinished">Döwrebap</translation>
    </message>
    <message>
        <source>Load Partially Signed Kawra Transaction</source>
        <translation type="unfinished">Bölekleýýin gol çekilen bitkoin amalyny (BGÇBA) ýükle</translation>
    </message>
    <message>
        <source>Load PSBT from &amp;clipboard…</source>
        <translation type="unfinished">&amp;alyş-çalyş panelinden BGÇBA ýükle…</translation>
    </message>
    <message>
        <source>Load Partially Signed Kawra Transaction from clipboard</source>
        <translation type="unfinished">Bölekleýin gol çekilen bitkoin amalyny alyş-çalyş panelinden ýükle</translation>
    </message>
    <message>
        <source>Node window</source>
        <translation type="unfinished">Düwün penjiresi</translation>
    </message>
    <message>
        <source>Open node debugging and diagnostic console</source>
        <translation type="unfinished">Düwüni zyýansyzlaşdyrma we anyklaýyş konsolyny aç</translation>
    </message>
    <message>
        <source>&amp;Sending addresses</source>
        <translation type="unfinished">&amp;Iberilýän salgylar</translation>
    </message>
    <message>
        <source>&amp;Receiving addresses</source>
        <translation type="unfinished">&amp;Kabul edýän salgylar</translation>
    </message>
    <message>
        <source>Open a kawra: URI</source>
        <translation type="unfinished">Bitkoin aç: URI</translation>
    </message>
    <message>
        <source>Open Wallet</source>
        <translation type="unfinished">Gapjygy aç</translation>
    </message>
    <message>
        <source>Open a wallet</source>
        <translation type="unfinished">Gapjyk aç</translation>
    </message>
    <message>
        <source>Close wallet</source>
        <translation type="unfinished">Gapjygy ýap</translation>
    </message>
    <message>
        <source>Close all wallets</source>
        <translation type="unfinished">Ähli gapjyklary ýap</translation>
    </message>
    <message>
        <source>Show the %1 help message to get a list with possible Kawra command-line options</source>
        <translation type="unfinished">Mümkin bolan Bitkoin buýruk setiri opsiýalarynyň sanawyny görmek üçin %1 goldaw habaryny görkez</translation>
    </message>
    <message>
        <source>&amp;Mask values</source>
        <translation type="unfinished">&amp;Sanlaryň üstüni ört</translation>
    </message>
    <message>
        <source>Mask the values in the Overview tab</source>
        <translation type="unfinished">Gözden geçir bölüminde sanlaryň üstüni ört</translation>
    </message>
    <message>
        <source>default wallet</source>
        <translation type="unfinished">deslapky bellenen gapjyk</translation>
    </message>
    <message>
        <source>No wallets available</source>
        <translation type="unfinished">Elýeterli gapjyk ýok</translation>
    </message>
    <message>
        <source>Wallet Name</source>
        <extracomment>Label of the input field where the name of the wallet is entered.</extracomment>
        <translation type="unfinished">Gapjygyň ady</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation type="unfinished">&amp;Penjire</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation type="unfinished">Ulalt</translation>
    </message>
    <message>
        <source>Main Window</source>
        <translation type="unfinished">Esasy penjire</translation>
    </message>
    <message>
        <source>%1 client</source>
        <translation type="unfinished">%1 müşderi</translation>
    </message>
    <message>
        <source>&amp;Hide</source>
        <translation type="unfinished">&amp;Gizle</translation>
    </message>
    <message>
        <source>S&amp;how</source>
        <translation type="unfinished">G&amp;örkez</translation>
    </message>
    <message numerus="yes">
        <source>%n active connection(s) to Kawra network.</source>
        <extracomment>A substring of the tooltip.</extracomment>
        <translation type="unfinished">
            <numerusform>Bitkoin toruna %n işjeň arabaglanyşyk.</numerusform>
            <numerusform>Bitkoin ulgamyna %n işjeň arabaglanyşyk.</numerusform>
        </translation>
    </message>
    <message>
        <source>Click for more actions.</source>
        <extracomment>A substring of the tooltip. "More actions" are available via the context menu.</extracomment>
        <translation type="unfinished">Başga hereketler üçin bas.</translation>
    </message>
    <message>
        <source>Show Peers tab</source>
        <extracomment>A context menu item. The "Peers tab" is an element of the "Node window".</extracomment>
        <translation type="unfinished">Deňdeşler bölümini görkez</translation>
    </message>
    <message>
        <source>Disable network activity</source>
        <extracomment>A context menu item.</extracomment>
        <translation type="unfinished">Ulgamyň işjeňligini öçür</translation>
    </message>
    <message>
        <source>Enable network activity</source>
        <extracomment>A context menu item. The network activity was disabled previously.</extracomment>
        <translation type="unfinished">Ulgamyň işjeňligini aç</translation>
    </message>
    <message>
        <source>Error: %1</source>
        <translation type="unfinished">Ýalňyşlyk: %1</translation>
    </message>
    <message>
        <source>Warning: %1</source>
        <translation type="unfinished">Duýduryş: %1</translation>
    </message>
    <message>
        <source>Date: %1
</source>
        <translation type="unfinished">Sene: %1
</translation>
    </message>
    <message>
        <source>Amount: %1
</source>
        <translation type="unfinished">Möçber: %1
</translation>
    </message>
    <message>
        <source>Wallet: %1
</source>
        <translation type="unfinished">Gapjyk: %1
</translation>
    </message>
    <message>
        <source>Type: %1
</source>
        <translation type="unfinished">Görnüş: %1
</translation>
    </message>
    <message>
        <source>Label: %1
</source>
        <translation type="unfinished">Bellik: %1
</translation>
    </message>
    <message>
        <source>Address: %1
</source>
        <translation type="unfinished">Salgy: %1
</translation>
    </message>
    <message>
        <source>Sent transaction</source>
        <translation type="unfinished">Iberilen geleşik</translation>
    </message>
    <message>
        <source>Incoming transaction</source>
        <translation type="unfinished">Gelýän geleşik</translation>
    </message>
    <message>
        <source>HD key generation is &lt;b&gt;enabled&lt;/b&gt;</source>
        <translation type="unfinished">HD açar döretmeklik &lt;b&gt;işjeň&lt;/b&gt;</translation>
    </message>
    <message>
        <source>HD key generation is &lt;b&gt;disabled&lt;/b&gt;</source>
        <translation type="unfinished">HD açar döretmeklik &lt;b&gt;öçük&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Private key &lt;b&gt;disabled&lt;/b&gt;</source>
        <translation type="unfinished">Hususy açar &lt;b&gt;öçük&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation type="unfinished">Gapjyk &lt;b&gt;şifrlenen&lt;/b&gt; we häzirki wagtda &lt;b&gt;gulpy açyk&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation type="unfinished">Gapjyk &lt;b&gt;şifrlenen&lt;/b&gt; we häzirki wagtda &lt;b&gt;gulply&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Original message:</source>
        <translation type="unfinished">Başdaky habar:</translation>
    </message>
</context>
<context>
    <name>UnitDisplayStatusBarControl</name>
    <message>
        <source>Unit to show amounts in. Click to select another unit.</source>
        <translation type="unfinished">Möçberleri görkezmek üçin ölçeg birligi. Başga ölçeg birligini saýlamak üçin bas.</translation>
    </message>
</context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Coin Selection</source>
        <translation type="unfinished">Teňňe saýlamak</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation type="unfinished">Sany:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation type="unfinished">Baýtlar:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation type="unfinished">Möçber:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation type="unfinished">Gatanç:</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation type="unfinished">Toz:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation type="unfinished">Soňundan gatanç:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation type="unfinished">Çalyş:</translation>
    </message>
    <message>
        <source>(un)select all</source>
        <translation type="unfinished">hemmesini saýla(ma)</translation>
    </message>
    <message>
        <source>Tree mode</source>
        <translation type="unfinished">Agaç tertibi</translation>
    </message>
    <message>
        <source>List mode</source>
        <translation type="unfinished">Sanaw tertibi</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">Möçber</translation>
    </message>
    <message>
        <source>Received with label</source>
        <translation type="unfinished">Bellik bilen kabul edildi</translation>
    </message>
    <message>
        <source>Received with address</source>
        <translation type="unfinished">Salgy bilen kabul edildi</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished">Sene</translation>
    </message>
    <message>
        <source>Confirmations</source>
        <translation type="unfinished">Tassyklamalar</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation type="unfinished">Tassyklandy</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation type="unfinished">Möçberi göçür</translation>
    </message>
    <message>
        <source>&amp;Copy address</source>
        <translation type="unfinished">&amp;Salgyny göçür</translation>
    </message>
    <message>
        <source>Copy &amp;label</source>
        <translation type="unfinished">&amp;Belligi göçür</translation>
    </message>
    <message>
        <source>Copy &amp;amount</source>
        <translation type="unfinished">&amp;Möçberi göçür</translation>
    </message>
    <message>
        <source>Copy transaction &amp;ID and output index</source>
        <translation type="unfinished">Amal &amp;IDsini we çykyş indeksini göçür</translation>
    </message>
    <message>
        <source>L&amp;ock unspent</source>
        <translation type="unfinished">Ulanylmadygyny g&amp;ulpla</translation>
    </message>
    <message>
        <source>&amp;Unlock unspent</source>
        <translation type="unfinished">Ulanylmadygynyň &amp;gulpuny aç</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation type="unfinished">Sany göçür</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation type="unfinished">Gatanjy göçür</translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation type="unfinished">Soňundan gatanjy göçür</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation type="unfinished">Baýtlary göçür</translation>
    </message>
    <message>
        <source>Copy dust</source>
        <translation type="unfinished">Tozy göçür</translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation type="unfinished">Gaýtargyny göçür</translation>
    </message>
    <message>
        <source>(%1 locked)</source>
        <translation type="unfinished">(%1 gulply)</translation>
    </message>
    <message>
        <source>yes</source>
        <translation type="unfinished">hawa</translation>
    </message>
    <message>
        <source>no</source>
        <translation type="unfinished">ýok</translation>
    </message>
    <message>
        <source>This label turns red if any recipient receives an amount smaller than the current dust threshold.</source>
        <translation type="unfinished">Islendik kabul ediji häzirki toz çäginden has kiçi möçberi kabul edip alsa, bu bellik gyzyla öwrülýär.</translation>
    </message>
    <message>
        <source>Can vary +/- %1 satoshi(s) per input.</source>
        <translation type="unfinished">Her giriş üçin +/- %1 satosi üýtgäp biler.</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(bellik ýok)</translation>
    </message>
    <message>
        <source>change from %1 (%2)</source>
        <translation type="unfinished">%1-den gaýtargy (%2)</translation>
    </message>
    <message>
        <source>(change)</source>
        <translation type="unfinished">(gaýtargy)</translation>
    </message>
</context>
<context>
    <name>CreateWalletActivity</name>
    <message>
        <source>Create Wallet</source>
        <extracomment>Title of window indicating the progress of creation of a new wallet.</extracomment>
        <translation type="unfinished">Gapjyk döret</translation>
    </message>
    <message>
        <source>Creating Wallet &lt;b&gt;%1&lt;/b&gt;…</source>
        <extracomment>Descriptive text of the create wallet progress window which indicates to the user which wallet is currently being created.</extracomment>
        <translation type="unfinished">&lt;b&gt;%1&lt;/b&gt; gapjyk döredilýär...</translation>
    </message>
    <message>
        <source>Create wallet failed</source>
        <translation type="unfinished">Gapjyk döredip bolmady</translation>
    </message>
    <message>
        <source>Create wallet warning</source>
        <translation type="unfinished">Gapjyk döretmek duýduryşy</translation>
    </message>
    <message>
        <source>Can't list signers</source>
        <translation type="unfinished">Gol çekenleriň sanawyny görkezip bolanok</translation>
    </message>
    </context>
<context>
    <name>OpenWalletActivity</name>
    <message>
        <source>Open wallet failed</source>
        <translation type="unfinished">Gapjyk açyp bolmady</translation>
    </message>
    <message>
        <source>Open wallet warning</source>
        <translation type="unfinished">Gapjyk açmak duýduryşy</translation>
    </message>
    <message>
        <source>default wallet</source>
        <translation type="unfinished">deslapky bellenen gapjyk</translation>
    </message>
    <message>
        <source>Open Wallet</source>
        <extracomment>Title of window indicating the progress of opening of a wallet.</extracomment>
        <translation type="unfinished">Gapjygy aç</translation>
    </message>
    <message>
        <source>Opening Wallet &lt;b&gt;%1&lt;/b&gt;…</source>
        <extracomment>Descriptive text of the open wallet progress window which indicates to the user which wallet is currently being opened.</extracomment>
        <translation type="unfinished">&lt;b&gt;%1&lt;/b&gt; gapjyk açylýar...</translation>
    </message>
</context>
<context>
    <name>WalletController</name>
    <message>
        <source>Close wallet</source>
        <translation type="unfinished">Gapjygy ýap</translation>
    </message>
    <message>
        <source>Are you sure you wish to close the wallet &lt;i&gt;%1&lt;/i&gt;?</source>
        <translation type="unfinished">&lt;i&gt;%1&lt;/i&gt; gapjygy ýapmak isleýäniňiz çynmy?</translation>
    </message>
    <message>
        <source>Closing the wallet for too long can result in having to resync the entire chain if pruning is enabled.</source>
        <translation type="unfinished">Kesip gysgaltmaklyk işjeň bolsa, aşa uzak wagtlap gapjygyň ýapylmagy tutuş zynjyryň gaýtadan utgaşmak zerurlygyna getirip biler.</translation>
    </message>
    <message>
        <source>Close all wallets</source>
        <translation type="unfinished">Ähli gapjyklary ýap</translation>
    </message>
    <message>
        <source>Are you sure you wish to close all wallets?</source>
        <translation type="unfinished">Ähli gapjyklary ýapmak isleýäniňiz çynmy?</translation>
    </message>
</context>
<context>
    <name>CreateWalletDialog</name>
    <message>
        <source>Create Wallet</source>
        <translation type="unfinished">Gapjyk döret</translation>
    </message>
    <message>
        <source>Wallet Name</source>
        <translation type="unfinished">Gapjygyň ady</translation>
    </message>
    <message>
        <source>Wallet</source>
        <translation type="unfinished">Gapjyk</translation>
    </message>
    <message>
        <source>Encrypt the wallet. The wallet will be encrypted with a passphrase of your choice.</source>
        <translation type="unfinished">Gapjygy şifrle. Gapjyk siziň saýlan parol sözlemi bilen şifrlener.</translation>
    </message>
    <message>
        <source>Encrypt Wallet</source>
        <translation type="unfinished">Gapjygy şifrle</translation>
    </message>
    <message>
        <source>Advanced Options</source>
        <translation type="unfinished">Giňişleýin opsiýalar</translation>
    </message>
    <message>
        <source>Disable private keys for this wallet. Wallets with private keys disabled will have no private keys and cannot have an HD seed or imported private keys. This is ideal for watch-only wallets.</source>
        <translation type="unfinished">Bu gapjyk üçin hususy açarlary öçür. Hususy açarlary öçük gapjyklaryň hiçhili hususy açary bolmaz we HD esasy açary ýa-da import edilen hususy açary bolmaz. Diňe gözden geçirip bolýan gapjyklar üçin iň göwnejaýydyr.</translation>
    </message>
    <message>
        <source>Disable Private Keys</source>
        <translation type="unfinished">Hususy açarlary öçür</translation>
    </message>
    <message>
        <source>Make a blank wallet. Blank wallets do not initially have private keys or scripts. Private keys and addresses can be imported, or an HD seed can be set, at a later time.</source>
        <translation type="unfinished">Boş gapjyk emele getir. Boş gapjyklaryň başda hususy açary ýa-da skripti bolmaýar. Soňra hususy açarlar ýa-da salgylar import edilip bilner ýa-da HD esasy açar bellenip bilner.</translation>
    </message>
    <message>
        <source>Make Blank Wallet</source>
        <translation type="unfinished">Boş gapjyk emele getir</translation>
    </message>
    <message>
        <source>Use descriptors for scriptPubKey management</source>
        <translation type="unfinished">scriptPubKey dolandyryşy üçin beýan edijileri ulan</translation>
    </message>
    <message>
        <source>Descriptor Wallet</source>
        <translation type="unfinished">Beýan ediji gapjyk</translation>
    </message>
    <message>
        <source>Use an external signing device such as a hardware wallet. Configure the external signer script in wallet preferences first.</source>
        <translation type="unfinished">Enjam gapjygy ýaly daşyndan gol çekilýän enjamy ulan. Ilki bilen gapjygyň ileri tutmalarynda daşyndan gol çekiji skriptini sazla.</translation>
    </message>
    <message>
        <source>External signer</source>
        <translation type="unfinished">Daşyndan gol çekiji</translation>
    </message>
    <message>
        <source>Create</source>
        <translation type="unfinished">Döret</translation>
    </message>
    <message>
        <source>Compiled without sqlite support (required for descriptor wallets)</source>
        <translation type="unfinished">Sqlite goldawsyz (beýan ediji gapjyklar üçin gerek) düzüldi</translation>
    </message>
    <message>
        <source>Compiled without external signing support (required for external signing)</source>
        <extracomment>"External signing" means using devices such as hardware wallets.</extracomment>
        <translation type="unfinished">Daşyndan gol çekmek üçin goldawsyz (daşyndan gol çekmek üçin gerek) düzüldi</translation>
    </message>
</context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation type="unfinished">Salgyny rejele</translation>
    </message>
    <message>
        <source>&amp;Label</source>
        <translation type="unfinished">&amp;Bellik</translation>
    </message>
    <message>
        <source>The label associated with this address list entry</source>
        <translation type="unfinished">Bu salgy sanawyndaky ýazgy bilen baglanyşykly bellik</translation>
    </message>
    <message>
        <source>The address associated with this address list entry. This can only be modified for sending addresses.</source>
        <translation type="unfinished">Bu salgy sanawyndaky ýazgy bilen baglanyşykly salgy. Bu diňe iberýän salgylar üçin üýtgedilip bilner.</translation>
    </message>
    <message>
        <source>&amp;Address</source>
        <translation type="unfinished">&amp;Salgy</translation>
    </message>
    <message>
        <source>New sending address</source>
        <translation type="unfinished">Täze iberýän salgy</translation>
    </message>
    <message>
        <source>Edit receiving address</source>
        <translation type="unfinished">Kabul edýän salgyny rejele</translation>
    </message>
    <message>
        <source>Edit sending address</source>
        <translation type="unfinished">Iberýän salgyny rejele</translation>
    </message>
    <message>
        <source>The entered address "%1" is not a valid Kawra address.</source>
        <translation type="unfinished">Ýazylan salgy %1 ýaly Bitkoin salgysy ýok.</translation>
    </message>
    <message>
        <source>Address "%1" already exists as a receiving address with label "%2" and so cannot be added as a sending address.</source>
        <translation type="unfinished">%1 salgysy %2 bellikli kabul edýän salgy hökmünde eýýäm bar we şonuň üçin ony iberýän salgy hökmünde goşup bolanok.</translation>
    </message>
    <message>
        <source>The entered address "%1" is already in the address book with label "%2".</source>
        <translation type="unfinished">Ýazylan %1 salgysy salgylar kitabynda %2 belligi astynda eýýäm bar.</translation>
    </message>
    <message>
        <source>Could not unlock wallet.</source>
        <translation type="unfinished">Gapjygyň gulpuny açyp bolmady.</translation>
    </message>
    <message>
        <source>New key generation failed.</source>
        <translation type="unfinished">Täze açar döredip bolmady.</translation>
    </message>
</context>
<context>
    <name>FreespaceChecker</name>
    <message>
        <source>A new data directory will be created.</source>
        <translation type="unfinished">Täze maglumat sanawy dörediler. </translation>
    </message>
    <message>
        <source>name</source>
        <translation type="unfinished">at</translation>
    </message>
    <message>
        <source>Directory already exists. Add %1 if you intend to create a new directory here.</source>
        <translation type="unfinished">Sanaw eýýäm bar. Bu ýerde täze sanaw döretmekçi bolsaňyz, %1 goşuň.</translation>
    </message>
    <message>
        <source>Path already exists, and is not a directory.</source>
        <translation type="unfinished">Ýol eýýäm bar we ol sanaw däldir.</translation>
    </message>
    <message>
        <source>Cannot create data directory here.</source>
        <translation type="unfinished">Bu ýerde maglumat sanawyny döredip bolanok.</translation>
    </message>
</context>
<context>
    <name>Intro</name>
    <message>
        <source>Kawra</source>
        <translation type="unfinished">Bitkoin</translation>
    </message>
    <message numerus="yes">
        <source>%n GB of space available</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>(of %n GB needed)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>(%n GB needed for full chain)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message>
        <source>At least %1 GB of data will be stored in this directory, and it will grow over time.</source>
        <translation type="unfinished">Bu sanawda azyndan %1 GB maglumat saklanar we ol wagtyň geçmegi bilen köpeler.</translation>
    </message>
    <message>
        <source>Approximately %1 GB of data will be stored in this directory.</source>
        <translation type="unfinished">Bu sanawda takmynan %1 GB maglumat saklanar.</translation>
    </message>
    <message numerus="yes">
        <source>(sufficient to restore backups %n day(s) old)</source>
        <extracomment>Explanatory text on the capability of the current prune target.</extracomment>
        <translation type="unfinished">
            <numerusform>(%n gün geçen ätiýaçlyk nusgalaryny dikeltmek üçin ýeterlik)</numerusform>
            <numerusform>(%n gün geçen ätiýaçlyk nusgalaryny dikeltmek üçin ýeterlik)</numerusform>
        </translation>
    </message>
    <message>
        <source>%1 will download and store a copy of the Kawra block chain.</source>
        <translation type="unfinished">%1 Bitkoin blok zynjyrynyň nusgasyny ýükläp alar we göçürer.</translation>
    </message>
    <message>
        <source>The wallet will also be stored in this directory.</source>
        <translation type="unfinished">Gapjyk hem bu sanawa saklanar.</translation>
    </message>
    <message>
        <source>Error: Specified data directory "%1" cannot be created.</source>
        <translation type="unfinished">Ýalňyşlyk: Görkezilen %1 maglumat sanawyny döredip bolanok.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">Ýalňyşlyk</translation>
    </message>
    <message>
        <source>Welcome</source>
        <translation type="unfinished">Hoş geldiňiz</translation>
    </message>
    <message>
        <source>Welcome to %1.</source>
        <translation type="unfinished">%1-a hoş geldiňiz.</translation>
    </message>
    <message>
        <source>As this is the first time the program is launched, you can choose where %1 will store its data.</source>
        <translation type="unfinished">Bu programma ilkinji gezek başlandygy sebäpli, %1-nyň öz maglumatlaryny nirä saklajakdygyny saýlap bilersiň.</translation>
    </message>
    <message>
        <source>Limit block chain storage to</source>
        <translation type="unfinished">Blok zynjyrynyň saklanmagyny çäklendir</translation>
    </message>
    <message>
        <source>Reverting this setting requires re-downloading the entire blockchain. It is faster to download the full chain first and prune it later. Disables some advanced features.</source>
        <translation type="unfinished">Bu sazlamany yzyna gaýtarmaklyk tutuş blok zynjyryny gaýtadan ýükläp almak zerur. Ilki bilen tutuş zynjyry ýükläp almak we soň ony kesmek has çalt bolar. Käbir giňişleýin aýratynlyklary öçürer.</translation>
    </message>
    <message>
        <source> GB</source>
        <translation type="unfinished">GB</translation>
    </message>
    <message>
        <source>This initial synchronisation is very demanding, and may expose hardware problems with your computer that had previously gone unnoticed. Each time you run %1, it will continue downloading where it left off.</source>
        <translation type="unfinished">Bu başdaky utgaşdyrma örän çylşyrymlydyr we kompýuteriňiziň ozal üns berilmedik enjam näsazlyklaryny ýüze çykaryp biler. Her sapar %1 işledeniňizde ol säginen ýerinden ýükläp almaga dowam eder.</translation>
    </message>
    <message>
        <source>If you have chosen to limit block chain storage (pruning), the historical data must still be downloaded and processed, but will be deleted afterward to keep your disk usage low.</source>
        <translation type="unfinished">Blok zynjyrynyň saklanyşyny çäklendirmegi (kesip aýyrmagy) saýlan bolsaňyz, geçmiş maglumatlary ýene-de ýüklenip alynmaly we işlenmelidir, emma diskiňiziň ulanylyşyny azaltmak üçin soňundan pozular. </translation>
    </message>
    <message>
        <source>Use the default data directory</source>
        <translation type="unfinished">Deslapky bellenen maglumat sanawyny ulan</translation>
    </message>
    <message>
        <source>Use a custom data directory:</source>
        <translation type="unfinished">Aýratyn maglumat sanawyny ulan:</translation>
    </message>
</context>
<context>
    <name>HelpMessageDialog</name>
    <message>
        <source>version</source>
        <translation type="unfinished">wersiýa</translation>
    </message>
    <message>
        <source>About %1</source>
        <translation type="unfinished">%1 barada</translation>
    </message>
    <message>
        <source>Command-line options</source>
        <translation type="unfinished">Buýruk setiri opsiýalary</translation>
    </message>
</context>
<context>
    <name>ShutdownWindow</name>
    <message>
        <source>%1 is shutting down…</source>
        <translation type="unfinished">%1 ýapylýar...</translation>
    </message>
    <message>
        <source>Do not shut down the computer until this window disappears.</source>
        <translation type="unfinished">Bu penjire ýitýänçä kompýuteri ýapmaň.</translation>
    </message>
</context>
<context>
    <name>ModalOverlay</name>
    <message>
        <source>Form</source>
        <translation type="unfinished">Forma</translation>
    </message>
    <message>
        <source>Recent transactions may not yet be visible, and therefore your wallet's balance might be incorrect. This information will be correct once your wallet has finished synchronizing with the kawra network, as detailed below.</source>
        <translation type="unfinished">Soňky geleşikler entek görünmän biler, şonuň üçin gapjygyňyzdaky galyndy nädogry bolup biler. Bu maglumat aşakda beýan edilişi ýaly gapjygyňyz bitkoin tory bilen utgaşmagy tamamlanda dogry bolar.</translation>
    </message>
    <message>
        <source>Attempting to spend kawras that are affected by not-yet-displayed transactions will not be accepted by the network.</source>
        <translation type="unfinished">Entek görkezilmedik geleşikleriň täsirine düşen bitkoinleri sarp etmek synanyşygy ulgam tarapyndan kabul edilmez.</translation>
    </message>
    </context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>&amp;Window</source>
        <translation type="unfinished">&amp;Penjire</translation>
    </message>
    <message>
        <source>Compiled without external signing support (required for external signing)</source>
        <extracomment>"External signing" means using devices such as hardware wallets.</extracomment>
        <translation type="unfinished">Daşyndan gol çekmek üçin goldawsyz (daşyndan gol çekmek üçin gerek) düzüldi</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">Ýalňyşlyk</translation>
    </message>
    </context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Form</source>
        <translation type="unfinished">Forma</translation>
    </message>
    </context>
<context>
    <name>PeerTableModel</name>
    <message>
        <source>Address</source>
        <extracomment>Title of Peers Table column which contains the IP/Onion/I2P address of the connected peer.</extracomment>
        <translation type="unfinished">Salgy</translation>
    </message>
    </context>
<context>
    <name>RPCConsole</name>
    <message>
        <source>Node window</source>
        <translation type="unfinished">Düwün penjiresi</translation>
    </message>
    <message>
        <source>&amp;Copy address</source>
        <extracomment>Context menu action to copy the address of a peer.</extracomment>
        <translation type="unfinished">&amp;Salgyny göçür</translation>
    </message>
    </context>
<context>
    <name>ReceiveCoinsDialog</name>
    <message>
        <source>&amp;Copy address</source>
        <translation type="unfinished">&amp;Salgyny göçür</translation>
    </message>
    <message>
        <source>Copy &amp;label</source>
        <translation type="unfinished">&amp;Belligi göçür</translation>
    </message>
    <message>
        <source>Copy &amp;amount</source>
        <translation type="unfinished">&amp;Möçberi göçür</translation>
    </message>
    <message>
        <source>Could not unlock wallet.</source>
        <translation type="unfinished">Gapjygyň gulpuny açyp bolmady.</translation>
    </message>
    </context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>Amount:</source>
        <translation type="unfinished">Möçber:</translation>
    </message>
    <message>
        <source>Wallet:</source>
        <translation type="unfinished">Gapjyk:</translation>
    </message>
    </context>
<context>
    <name>RecentRequestsTableModel</name>
    <message>
        <source>Date</source>
        <translation type="unfinished">Sene</translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished">Bellik</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(bellik ýok)</translation>
    </message>
    </context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Quantity:</source>
        <translation type="unfinished">Sany:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation type="unfinished">Baýtlar:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation type="unfinished">Möçber:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation type="unfinished">Gatanç:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation type="unfinished">Soňundan gatanç:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation type="unfinished">Çalyş:</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation type="unfinished">Toz:</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation type="unfinished">Sany göçür</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation type="unfinished">Möçberi göçür</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation type="unfinished">Gatanjy göçür</translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation type="unfinished">Soňundan gatanjy göçür</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation type="unfinished">Baýtlary göçür</translation>
    </message>
    <message>
        <source>Copy dust</source>
        <translation type="unfinished">Tozy göçür</translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation type="unfinished">Gaýtargyny göçür</translation>
    </message>
    <message numerus="yes">
        <source>Estimated to begin confirmation within %n block(s).</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(bellik ýok)</translation>
    </message>
</context>
<context>
    <name>TransactionDesc</name>
    <message>
        <source>Date</source>
        <translation type="unfinished">Sene</translation>
    </message>
    <message numerus="yes">
        <source>matures in %n more block(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">Möçber</translation>
    </message>
    </context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Date</source>
        <translation type="unfinished">Sene</translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished">Bellik</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(bellik ýok)</translation>
    </message>
    </context>
<context>
    <name>TransactionView</name>
    <message>
        <source>&amp;Copy address</source>
        <translation type="unfinished">&amp;Salgyny göçür</translation>
    </message>
    <message>
        <source>Copy &amp;label</source>
        <translation type="unfinished">&amp;Belligi göçür</translation>
    </message>
    <message>
        <source>Copy &amp;amount</source>
        <translation type="unfinished">&amp;Möçberi göçür</translation>
    </message>
    <message>
        <source>Copy transaction &amp;ID</source>
        <translation type="unfinished">Geleşigiň &amp;ID-sini göçür</translation>
    </message>
    <message>
        <source>Comma separated file</source>
        <extracomment>Expanded name of the CSV file format. See: https://en.wikipedia.org/wiki/Comma-separated_values.</extracomment>
        <translation type="unfinished">Otur bilen aýrylan faýl</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation type="unfinished">Tassyklandy</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished">Sene</translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished">Bellik</translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="unfinished">Salgy</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation type="unfinished">Geçirip bolmady</translation>
    </message>
    </context>
<context>
    <name>WalletFrame</name>
    <message>
        <source>Create a new wallet</source>
        <translation type="unfinished">Taze gapjyk döret</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">Ýalňyşlyk</translation>
    </message>
    </context>
<context>
    <name>WalletModel</name>
    <message>
        <source>default wallet</source>
        <translation type="unfinished">deslapky bellenen gapjyk</translation>
    </message>
</context>
<context>
    <name>WalletView</name>
    <message>
        <source>&amp;Export</source>
        <translation type="unfinished">&amp;Geçir</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation type="unfinished">Häzirki bellikdäki maglumaty faýla geçir</translation>
    </message>
    </context>
<context>
    <name>kawra-core</name>
    <message>
        <source>Settings file could not be read</source>
        <translation type="unfinished">Sazlamalar faýlyny okap bolanok</translation>
    </message>
    <message>
        <source>Settings file could not be written</source>
        <translation type="unfinished">Sazlamalar faýlyny ýazdyryp bolanok</translation>
    </message>
</context>
</TS>