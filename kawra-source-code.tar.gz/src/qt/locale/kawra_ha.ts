<TS version="2.1" language="ha">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Right-click to edit address or label</source>
        <translation type="unfinished">Danna dama don gyara adireshi ko labil</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation type="unfinished">Ƙirƙiri sabon adireshi</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation type="unfinished">&amp;Sabontawa</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation type="unfinished">Kwafi adireshin da aka zaɓa a halin yanzu domin yin amfani dashi</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation type="unfinished">&amp;Kwafi</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation type="unfinished">C&amp;Rufe</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation type="unfinished">Share adireshin da aka zaɓa a halin yanzu daga jerin </translation>
    </message>
    <message>
        <source>Enter address or label to search</source>
        <translation type="unfinished">Shigar da adireshi ko lakabi don bincika</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation type="unfinished">Fitar da bayanan da ke cikin shafin na yanzu zuwa fayil</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation type="unfinished">&amp; Fitarwa</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation type="unfinished">&amp;Sharewa</translation>
    </message>
    <message>
        <source>Choose the address to send coins to</source>
        <translation type="unfinished">zaɓi adireshin don aika tsabar kudi</translation>
    </message>
    <message>
        <source>Choose the address to receive coins with</source>
        <translation type="unfinished">Zaɓi adireshin don karɓar kuɗi internet da shi</translation>
    </message>
    <message>
        <source>Sending addresses</source>
        <translation type="unfinished">adireshin aikawa</translation>
    </message>
    <message>
        <source>Receiving addresses</source>
        <translation type="unfinished">Adireshi da za a karba dashi</translation>
    </message>
    <message>
        <source>These are your Kawra addresses for sending payments. Always check the amount and the receiving address before sending coins.</source>
        <translation type="unfinished">Waɗannan adiresoshin Kawra ne don tura kuɗi kawra . ka tabbatar da cewa adreshin daidai ne kamin ka tura abua a ciki</translation>
    </message>
    <message>
        <source>These are your Kawra addresses for receiving payments. Use the 'Create new receiving address' button in the receive tab to create new addresses.
Signing is only possible with addresses of the type 'legacy'.</source>
        <translation type="unfinished">Waɗannan adiresoshin Kawra ne don karɓar kuɗi. Yi amfani da maɓallin 'Ƙirƙiri sabon adireshin karɓa' a cikin shafin karɓa don ƙirƙirar sababbin adireshi.
zaka iya shiga ne kawai da adiresoshin 'na musamman' kawai.</translation>
    </message>
    <message>
        <source>&amp;Copy Address</source>
        <translation type="unfinished">&amp;Kwafi Adireshin</translation>
    </message>
    <message>
        <source>Copy &amp;Label</source>
        <translation type="unfinished">Kwafi &amp; Lakabi</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation type="unfinished">&amp;Gyara</translation>
    </message>
    <message>
        <source>Export Address List</source>
        <translation type="unfinished">Fitarwar Jerin Adireshi</translation>
    </message>
    <message>
        <source>Comma separated file</source>
        <extracomment>Expanded name of the CSV file format. See: https://en.wikipedia.org/wiki/Comma-separated_values.</extracomment>
        <translation type="unfinished">waƙafin rabuwar fayil</translation>
    </message>
    <message>
        <source>There was an error trying to save the address list to %1. Please try again.</source>
        <extracomment>An error message. %1 is a stand-in argument for the name of the file we attempted to save to.</extracomment>
        <translation type="unfinished">An sami kuskure wajen ƙoƙarin ajiye jerin adireshi zuwa %1. Da fatan za a sake gwadawa. </translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation type="unfinished">Ba a yi nasarar fitarwa ba</translation>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Address</source>
        <translation type="unfinished">Adireshi</translation>
    </message>
    </context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Unlock wallet</source>
        <translation type="unfinished">Bude Walet</translation>
    </message>
    </context>
<context>
    <name>QObject</name>
    <message numerus="yes">
        <source>%n second(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n minute(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n hour(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n day(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n week(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n year(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    </context>
<context>
    <name>KawraGUI</name>
    <message numerus="yes">
        <source>Processed %n block(s) of transaction history.</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n active connection(s) to Kawra network.</source>
        <extracomment>A substring of the tooltip.</extracomment>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    </context>
<context>
    <name>Intro</name>
    <message>
        <source>Kawra</source>
        <translation type="unfinished">Bitkoin</translation>
    </message>
    <message numerus="yes">
        <source>%n GB of space available</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>(of %n GB needed)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>(%n GB needed for full chain)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>(sufficient to restore backups %n day(s) old)</source>
        <extracomment>Explanatory text on the capability of the current prune target.</extracomment>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    </context>
<context>
    <name>PeerTableModel</name>
    <message>
        <source>Address</source>
        <extracomment>Title of Peers Table column which contains the IP/Onion/I2P address of the connected peer.</extracomment>
        <translation type="unfinished">Adireshi</translation>
    </message>
    </context>
<context>
    <name>SendCoinsDialog</name>
    <message numerus="yes">
        <source>Estimated to begin confirmation within %n block(s).</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    </context>
<context>
    <name>TransactionDesc</name>
    <message numerus="yes">
        <source>matures in %n more block(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    </context>
<context>
    <name>TransactionView</name>
    <message>
        <source>Comma separated file</source>
        <extracomment>Expanded name of the CSV file format. See: https://en.wikipedia.org/wiki/Comma-separated_values.</extracomment>
        <translation type="unfinished">waƙafin rabuwar fayil</translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="unfinished">Adireshi</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation type="unfinished">Ba a yi nasarar fitarwa ba</translation>
    </message>
    </context>
<context>
    <name>WalletView</name>
    <message>
        <source>&amp;Export</source>
        <translation type="unfinished">&amp; Fitarwa</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation type="unfinished">Fitar da bayanan da ke cikin shafin na yanzu zuwa fayil</translation>
    </message>
    </context>
</TS>