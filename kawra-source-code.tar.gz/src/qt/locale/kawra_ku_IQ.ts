<TS version="2.1" language="ku_IQ">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Right-click to edit address or label</source>
        <translation type="unfinished">کرتەی-ڕاست بکە بۆ دەسکاری کردنی ناونیشان یان پێناسە</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation type="unfinished">ناوونیشانێکی نوێ دروست بکە</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation type="unfinished">&amp;نوێ</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation type="unfinished">کۆپیکردنی ناونیشانی هەڵبژێردراوی ئێستا بۆ کلیپ بۆردی سیستەم</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation type="unfinished">&amp;ڕوونووس</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation type="unfinished">C&amp;داخستن</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation type="unfinished">سڕینەوەی ناونیشانی هەڵبژێردراوی ئێستا لە لیستەکە</translation>
    </message>
    <message>
        <source>Enter address or label to search</source>
        <translation type="unfinished">ناونیشانێک بنووسە یان پێناسەیەک داخڵ بکە بۆ گەڕان</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation type="unfinished">ناردنی داتا لە خشتەبەندی ئێستا بۆ فایلێک</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation type="unfinished">&amp;هەناردن</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation type="unfinished">&amp;سڕینەوە</translation>
    </message>
    <message>
        <source>Choose the address to send coins to</source>
        <translation type="unfinished">ناونیشانەکە هەڵبژێرە بۆ ناردنی دراوەکان بۆ</translation>
    </message>
    <message>
        <source>Choose the address to receive coins with</source>
        <translation type="unfinished">ناونیشانەکە هەڵبژێرە بۆ وەرگرتنی دراوەکان لەگەڵ</translation>
    </message>
    <message>
        <source>C&amp;hoose</source>
        <translation type="unfinished">&amp;هەڵبژێرە</translation>
    </message>
    <message>
        <source>Sending addresses</source>
        <translation type="unfinished">ناردنی ناونیشانەکان</translation>
    </message>
    <message>
        <source>Receiving addresses</source>
        <translation type="unfinished">وەرگرتنی ناونیشانەکان</translation>
    </message>
    <message>
        <source>These are your Kawra addresses for sending payments. Always check the amount and the receiving address before sending coins.</source>
        <translation type="unfinished">ئەمانە ناونیشانی بیتکۆبیتەکانی تۆنە بۆ ناردنی پارەدانەکان. هەمیشە بڕی و ناونیشانی وەرگرەکان بپشکنە پێش ناردنی دراوەکان.</translation>
    </message>
    <message>
        <source>These are your Kawra addresses for receiving payments. Use the 'Create new receiving address' button in the receive tab to create new addresses.
Signing is only possible with addresses of the type 'legacy'.</source>
        <translation type="unfinished">ئەمانە ناونیشانی بیتکۆبیتەکانی تۆنە بۆ وەرگرتنی پارەدانەکان. دوگمەی 'دروستکردنیناونیشانی وەرگرتنی نوێ' لە تابی وەرگرتندا بۆ دروستکردنی ناونیشانی نوێ بەکاربێنە.
واژووکردن تەنها دەکرێت لەگەڵ ناونیشانەکانی جۆری 'میرات'.</translation>
    </message>
    <message>
        <source>&amp;Copy Address</source>
        <translation type="unfinished">&amp;ڕوونووسکردن ناوونیشان</translation>
    </message>
    <message>
        <source>Copy &amp;Label</source>
        <translation type="unfinished">کۆپی &amp;ناونیشان</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation type="unfinished">&amp;دەسکاریکردن</translation>
    </message>
    <message>
        <source>Export Address List</source>
        <translation type="unfinished">لیستی ناونیشان هاوردە بکە</translation>
    </message>
    <message>
        <source>There was an error trying to save the address list to %1. Please try again.</source>
        <extracomment>An error message. %1 is a stand-in argument for the name of the file we attempted to save to.</extracomment>
        <translation type="unfinished">هەڵەیەک ڕوویدا لە هەوڵی خەزنکردنی لیستی ناونیشانەکە بۆ %1. تکایە دووبارە هەوڵ دەوە.</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation type="unfinished">هەناردەکردن سەرکەوتوو نەبوو</translation>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Label</source>
        <translation type="unfinished">پێناسەکردن</translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="unfinished">ناوونیشان</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(ناونیشان نییە)</translation>
    </message>
</context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Passphrase Dialog</source>
        <translation type="unfinished">دیالۆگی دەستەواژەی تێپەڕبوون</translation>
    </message>
    <message>
        <source>Enter passphrase</source>
        <translation type="unfinished">دەستەواژەی تێپەڕبوون بنووسە</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation type="unfinished">دەستەواژەی تێپەڕی نوێ</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation type="unfinished">دووبارەکردنەوەی دەستەواژەی تێپەڕی نوێ</translation>
    </message>
    <message>
        <source>Show passphrase</source>
        <translation type="unfinished">نیشان دانا ناوه چونه</translation>
    </message>
    <message>
        <source>Encrypt wallet</source>
        <translation type="unfinished">کیف خو یه پاره رمزه دانینه بر</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation type="unfinished">او شوله بو ور کرنا کیف پاره گرکه رمزا کیفه وؤ یه پاره بزانی</translation>
    </message>
    <message>
        <source>Unlock wallet</source>
        <translation type="unfinished">Kilîda cizdên veke</translation>
    </message>
    <message>
        <source>Change passphrase</source>
        <translation type="unfinished">Pêborînê biguherîne</translation>
    </message>
    <message>
        <source>Confirm wallet encryption</source>
        <translation type="unfinished">Şîfrekirina cizdên bipejirîne</translation>
    </message>
    <message>
        <source>Are you sure you wish to encrypt your wallet?</source>
        <translation type="unfinished">به راستی اون هشیارن کا دخازن بو کیف خو یه پاره رمزه دانین</translation>
    </message>
    <message>
        <source>Wallet encrypted</source>
        <translation type="unfinished">Cizdan hate şîfrekirin</translation>
    </message>
    <message>
        <source>Enter the new passphrase for the wallet.&lt;br/&gt;Please use a passphrase of &lt;b&gt;ten or more random characters&lt;/b&gt;, or &lt;b&gt;eight or more words&lt;/b&gt;.</source>
        <translation type="unfinished">دەستەواژەی تێپەڕەوی نوێ بنووسە بۆ جزدان. &lt;br/&gt;تکایە دەستەواژەی تێپەڕێک بەکاربێنە لە &lt;b&gt;دە یان زیاتر لە هێما هەڕەمەکییەکان&lt;/b&gt;یان &lt;b&gt;هەشت یان وشەی زیاتر&lt;/b&gt;.</translation>
    </message>
    <message>
        <source>Remember that encrypting your wallet cannot fully protect your kawras from being stolen by malware infecting your computer.</source>
        <translation type="unfinished">بیرت بێت کە ڕەمزاندنی جزدانەکەت ناتوانێت بەتەواوی بیتکۆبیتەکانت بپارێزێت لە دزرابوون لەلایەن وورنەری تووشکردنی کۆمپیوتەرەکەت.</translation>
    </message>
    <message>
        <source>IMPORTANT: Any previous backups you have made of your wallet file should be replaced with the newly generated, encrypted wallet file. For security reasons, previous backups of the unencrypted wallet file will become useless as soon as you start using the new, encrypted wallet.</source>
        <translation type="unfinished">گرنگ: هەر پاڵپشتێکی پێشووت دروست کردووە لە فایلی جزدانەکەت دەبێت جێگۆڕکێی پێ بکرێت لەگەڵ فایلی جزدانی نهێنی تازە دروستکراو. لەبەر هۆکاری پاراستن، پاڵپشتەکانی پێشووی فایلی جزدانێکی نهێنی نەکراو بێ سوود دەبن هەر کە دەستت کرد بە بەکارهێنانی جزدانی نوێی کۆدکراو.</translation>
    </message>
    </context>
<context>
    <name>QObject</name>
    <message>
        <source>Amount</source>
        <translation type="unfinished">سەرجەم</translation>
    </message>
    <message numerus="yes">
        <source>%n second(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n minute(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n hour(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n day(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n week(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>%n year(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    </context>
<context>
    <name>KawraGUI</name>
    <message>
        <source>&amp;About %1</source>
        <translation type="unfinished">&amp;دەربارەی %1</translation>
    </message>
    <message>
        <source>Wallet:</source>
        <translation type="unfinished">Cizdan:</translation>
    </message>
    <message>
        <source>&amp;Send</source>
        <translation type="unfinished">&amp;ناردن</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation type="unfinished">&amp;فایل</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation type="unfinished">&amp;ڕێکخستنەکان</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation type="unfinished">&amp;یارمەتی</translation>
    </message>
    <message numerus="yes">
        <source>Processed %n block(s) of transaction history.</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">هەڵە</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation type="unfinished">ئاگاداری</translation>
    </message>
    <message>
        <source>Information</source>
        <translation type="unfinished">زانیاری</translation>
    </message>
    <message numerus="yes">
        <source>%n active connection(s) to Kawra network.</source>
        <extracomment>A substring of the tooltip.</extracomment>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    </context>
<context>
    <name>UnitDisplayStatusBarControl</name>
    <message>
        <source>Unit to show amounts in. Click to select another unit.</source>
        <translation type="unfinished">یەکە بۆ نیشاندانی بڕی لەناو. کرتە بکە بۆ دیاریکردنی یەکەیەکی تر.</translation>
    </message>
</context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Amount:</source>
        <translation type="unfinished">کۆ:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation type="unfinished">تێچوون:</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">سەرجەم</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished">رێکەت</translation>
    </message>
    <message>
        <source>yes</source>
        <translation type="unfinished">بەڵێ</translation>
    </message>
    <message>
        <source>no</source>
        <translation type="unfinished">نەخێر</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(ناونیشان نییە)</translation>
    </message>
    </context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Address "%1" already exists as a receiving address with label "%2" and so cannot be added as a sending address.</source>
        <translation type="unfinished">ناونیشان "%1" پێشتر هەبوو وەک ناونیشانی وەرگرتن لەگەڵ ناونیشانی "%2" و بۆیە ناتوانرێت زیاد بکرێت وەک ناونیشانی ناردن.</translation>
    </message>
    </context>
<context>
    <name>FreespaceChecker</name>
    <message>
        <source>name</source>
        <translation type="unfinished">ناو</translation>
    </message>
    <message>
        <source>Directory already exists. Add %1 if you intend to create a new directory here.</source>
        <translation type="unfinished">دایەرێکتۆری پێش ئێستا هەیە. %1 زیاد بکە ئەگەر بەتەما بیت لێرە ڕێنیشاندەرێکی نوێ دروست بکەیت.</translation>
    </message>
    <message>
        <source>Cannot create data directory here.</source>
        <translation type="unfinished">ناتوانیت لێرە داتا دروست بکەیت.</translation>
    </message>
</context>
<context>
    <name>Intro</name>
    <message numerus="yes">
        <source>%n GB of space available</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>(of %n GB needed)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>(%n GB needed for full chain)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message numerus="yes">
        <source>(sufficient to restore backups %n day(s) old)</source>
        <extracomment>Explanatory text on the capability of the current prune target.</extracomment>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message>
        <source>%1 will download and store a copy of the Kawra block chain.</source>
        <translation type="unfinished">%1 کۆپیەکی زنجیرەی بلۆکی بیتکۆپ دائەبەزێنێت و خەزنی دەکات.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">هەڵە</translation>
    </message>
    <message>
        <source>Welcome</source>
        <translation type="unfinished">بەخێربێن</translation>
    </message>
    <message>
        <source>Reverting this setting requires re-downloading the entire blockchain. It is faster to download the full chain first and prune it later. Disables some advanced features.</source>
        <translation type="unfinished">دووبارە کردنەوەی ئەم ڕێکخستنە پێویستی بە دووبارە داگرتنی تەواوی بەربەستەکە هەیە. خێراترە بۆ داگرتنی زنجیرەی تەواو سەرەتا و داگرتنی دواتر. هەندێک تایبەتمەندی پێشکەوتوو لە کار دەهێنێت.</translation>
    </message>
    <message>
        <source>This initial synchronisation is very demanding, and may expose hardware problems with your computer that had previously gone unnoticed. Each time you run %1, it will continue downloading where it left off.</source>
        <translation type="unfinished">ئەم هاوکاتکردنە سەرەتاییە زۆر داوای دەکات، و لەوانەیە کێشەکانی رەقەواڵە لەگەڵ کۆمپیوتەرەکەت دابخات کە پێشتر تێبینی نەکراو بوو. هەر جارێک کە %1 رادەدەیت، بەردەوام دەبێت لە داگرتن لەو شوێنەی کە بەجێی هێشت.</translation>
    </message>
    <message>
        <source>If you have chosen to limit block chain storage (pruning), the historical data must still be downloaded and processed, but will be deleted afterward to keep your disk usage low.</source>
        <translation type="unfinished">ئەگەر تۆ دیاریت کردووە بۆ سنووردارکردنی کۆگە زنجیرەی بلۆک (کێڵکردن)، هێشتا داتای مێژووی دەبێت دابەزێنرێت و پرۆسەی بۆ بکرێت، بەڵام دواتر دەسڕدرێتەوە بۆ ئەوەی بەکارهێنانی دیسکەکەت کەم بێت.</translation>
    </message>
    </context>
<context>
    <name>HelpMessageDialog</name>
    <message>
        <source>version</source>
        <translation type="unfinished">وەشان</translation>
    </message>
    </context>
<context>
    <name>ModalOverlay</name>
    <message>
        <source>%1 is currently syncing.  It will download headers and blocks from peers and validate them until reaching the tip of the block chain.</source>
        <translation type="unfinished">%1 لە ئێستادا هاوکات دەکرێت.  سەرپەڕ و بلۆکەکان لە هاوتەمەنەکان دابەزێنێت و کارایان دەکات تا گەیشتن بە سەرەی زنجیرەی بلۆک.</translation>
    </message>
    </context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation type="unfinished">هەڵبژاردنەکان</translation>
    </message>
    <message>
        <source>Reverting this setting requires re-downloading the entire blockchain.</source>
        <translation type="unfinished">دووبارە کردنەوەی ئەم ڕێکخستنە پێویستی بە دووبارە داگرتنی تەواوی بەربەستەکە هەیە.</translation>
    </message>
    <message>
        <source>User Interface &amp;language:</source>
        <translation type="unfinished">ڕووکاری بەکارهێنەر &amp;زمان:</translation>
    </message>
    <message>
        <source>The user interface language can be set here. This setting will take effect after restarting %1.</source>
        <translation type="unfinished">زمانی ڕووکاری بەکارهێنەر دەکرێت لێرە دابنرێت. ئەم ڕێکخستنە کاریگەر دەبێت پاش دەستپێکردنەوەی %1.</translation>
    </message>
    <message>
        <source>The configuration file is used to specify advanced user options which override GUI settings. Additionally, any command-line options will override this configuration file.</source>
        <extracomment>Explanatory text about the priority order of instructions considered by client. The order from high to low being: command-line, configuration file, GUI settings.</extracomment>
        <translation type="unfinished">فایلی شێوەپێدان بەکاردێت بۆ دیاریکردنی هەڵبژاردنەکانی بەکارهێنەری پێشکەوتوو کە زیادەڕەوی لە ڕێکخستنەکانی GUI دەکات. لەگەڵ ئەوەش، هەر بژاردەکانی هێڵی فەرمان زیادەڕەوی دەکات لە سەر ئەم فایلە شێوەپێدانە.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">هەڵە</translation>
    </message>
    </context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Total:</source>
        <translation type="unfinished">گشتی</translation>
    </message>
    <message>
        <source>Privacy mode activated for the Overview tab. To unmask the values, uncheck Settings-&gt;Mask values.</source>
        <translation type="unfinished">دۆخی تایبەتمەندی چالاک کرا بۆ تابی گشتی. بۆ کردنەوەی بەهاکان، بەهاکان ڕێکخستنەکان&gt;ماسک.</translation>
    </message>
</context>
<context>
    <name>PSBTOperationsDialog</name>
    <message>
        <source>or</source>
        <translation type="unfinished">یان</translation>
    </message>
    </context>
<context>
    <name>PaymentServer</name>
    <message>
        <source>Cannot start kawra: click-to-pay handler</source>
        <translation type="unfinished">ناتوانێت دەست بکات بە kawra: کرتە بکە بۆ-پارەدانی کار</translation>
    </message>
    </context>
<context>
    <name>PeerTableModel</name>
    <message>
        <source>Sent</source>
        <extracomment>Title of Peers Table column which indicates the total amount of network information we have sent to the peer.</extracomment>
        <translation type="unfinished">نێدرا</translation>
    </message>
    <message>
        <source>Address</source>
        <extracomment>Title of Peers Table column which contains the IP/Onion/I2P address of the connected peer.</extracomment>
        <translation type="unfinished">ناوونیشان</translation>
    </message>
    <message>
        <source>Type</source>
        <extracomment>Title of Peers Table column which describes the type of peer connection. The "type" describes why the connection exists.</extracomment>
        <translation type="unfinished">جۆر</translation>
    </message>
    <message>
        <source>Network</source>
        <extracomment>Title of Peers Table column which states the network the peer connected through.</extracomment>
        <translation type="unfinished">تۆڕ</translation>
    </message>
    </context>
<context>
    <name>QRImageWidget</name>
    <message>
        <source>Resulting URI too long, try to reduce the text for label / message.</source>
        <translation type="unfinished">ئەنجامی URL زۆر درێژە، هەوڵ بدە دەقەکە کەم بکەیتەوە بۆ پێناسە / نامە.</translation>
    </message>
    </context>
<context>
    <name>RPCConsole</name>
    <message>
        <source>&amp;Information</source>
        <translation type="unfinished">&amp;زانیاری</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="unfinished">گشتی</translation>
    </message>
    <message>
        <source>Network</source>
        <translation type="unfinished">تۆڕ</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished">ناو</translation>
    </message>
    <message>
        <source>Sent</source>
        <translation type="unfinished">نێدرا</translation>
    </message>
    <message>
        <source>Version</source>
        <translation type="unfinished">وەشان</translation>
    </message>
    <message>
        <source>Services</source>
        <translation type="unfinished">خزمەتگوزاریەکان</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation type="unfinished">&amp;کردنەوە</translation>
    </message>
    <message>
        <source>Totals</source>
        <translation type="unfinished">گشتییەکان</translation>
    </message>
    <message>
        <source>In:</source>
        <translation type="unfinished">لە ناو</translation>
    </message>
    <message>
        <source>Out:</source>
        <translation type="unfinished">لەدەرەوە</translation>
    </message>
    <message>
        <source>1 &amp;hour</source>
        <translation type="unfinished">1&amp;سات</translation>
    </message>
    <message>
        <source>1 &amp;week</source>
        <translation type="unfinished">1&amp;هەفتە</translation>
    </message>
    <message>
        <source>1 &amp;year</source>
        <translation type="unfinished">1&amp;ساڵ</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="unfinished">بەڵێ</translation>
    </message>
    <message>
        <source>No</source>
        <translation type="unfinished">نەخێر</translation>
    </message>
    <message>
        <source>To</source>
        <translation type="unfinished">بۆ</translation>
    </message>
    <message>
        <source>From</source>
        <translation type="unfinished">لە</translation>
    </message>
    </context>
<context>
    <name>ReceiveCoinsDialog</name>
    <message>
        <source>&amp;Amount:</source>
        <translation type="unfinished">&amp;سەرجەم:</translation>
    </message>
    <message>
        <source>&amp;Message:</source>
        <translation type="unfinished">&amp;پەیام:</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation type="unfinished">پاککردنەوە</translation>
    </message>
    <message>
        <source>Show the selected request (does the same as double clicking an entry)</source>
        <translation type="unfinished">پیشاندانی داواکارییە دیاریکراوەکان (هەمان کرتەی دووانی کرتەکردن دەکات لە تۆمارێک)</translation>
    </message>
    <message>
        <source>Show</source>
        <translation type="unfinished">پیشاندان</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished">سڕینەوە</translation>
    </message>
    </context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>Amount:</source>
        <translation type="unfinished">کۆ:</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation type="unfinished">پەیام:</translation>
    </message>
    <message>
        <source>Wallet:</source>
        <translation type="unfinished">Cizdan:</translation>
    </message>
    </context>
<context>
    <name>RecentRequestsTableModel</name>
    <message>
        <source>Date</source>
        <translation type="unfinished">رێکەت</translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished">پێناسەکردن</translation>
    </message>
    <message>
        <source>Message</source>
        <translation type="unfinished">پەیام</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(ناونیشان نییە)</translation>
    </message>
    </context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Amount:</source>
        <translation type="unfinished">کۆ:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation type="unfinished">تێچوون:</translation>
    </message>
    <message>
        <source>Hide transaction fee settings</source>
        <translation type="unfinished">شاردنەوەی ڕێکخستنەکانی باجی مامەڵە</translation>
    </message>
    <message>
        <source>When there is less transaction volume than space in the blocks, miners as well as relaying nodes may enforce a minimum fee. Paying only this minimum fee is just fine, but be aware that this can result in a never confirming transaction once there is more demand for kawra transactions than the network can process.</source>
        <translation type="unfinished">کاتێک قەبارەی مامەڵە کەمتر بێت لە بۆشایی بلۆکەکان، لەوانەیە کانەکان و گرێکانی گواستنەوە کەمترین کرێ جێبەجێ بکەن. پێدانی تەنیا ئەم کەمترین کرێیە تەنیا باشە، بەڵام ئاگاداربە کە ئەمە دەتوانێت ببێتە هۆی ئەوەی کە هەرگیز مامەڵەیەکی پشتڕاستکردنەوە ئەنجام بدرێت جارێک داواکاری زیاتر هەیە بۆ مامەڵەکانی بیت کۆبیتکۆ لەوەی کە تۆڕەکە دەتوانێت ئەنجامی بدات.</translation>
    </message>
    <message>
        <source>or</source>
        <translation type="unfinished">یان</translation>
    </message>
    <message>
        <source>Please, review your transaction proposal. This will produce a Partially Signed Kawra Transaction (PSBT) which you can save or copy and then sign with e.g. an offline %1 wallet, or a PSBT-compatible hardware wallet.</source>
        <extracomment>Text to inform a user attempting to create a transaction of their current options. At this stage, a user can only create a PSBT. This string is displayed when private keys are disabled and an external signer is not available.</extracomment>
        <translation type="unfinished">تکایە، پێداچوونەوە بکە بە پێشنیارەکانی مامەڵەکەت. ئەمە مامەڵەیەکی بیتکۆپەکی کەبەشیونکراو (PSBT) بەرهەمدەهێنێت کە دەتوانیت پاشەکەوتی بکەیت یان کۆپی بکەیت و پاشان واژووی بکەیت لەگەڵ بۆ ئەوەی بە دەرهێڵی %1 جزدانێک، یان جزدانێکی رەقەواڵەی گونجاو بە PSBT.</translation>
    </message>
    <message>
        <source>Please, review your transaction.</source>
        <extracomment>Text to prompt a user to review the details of the transaction they are attempting to send.</extracomment>
        <translation type="unfinished">تکایە، چاو بە مامەڵەکەتدا بخشێنەوە.</translation>
    </message>
    <message>
        <source>The recipient address is not valid. Please recheck.</source>
        <translation type="unfinished">ناونیشانی وەرگرتنەکە دروست نییە. تکایە دووبارە پشکنین بکەوە.</translation>
    </message>
    <message numerus="yes">
        <source>Estimated to begin confirmation within %n block(s).</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(ناونیشان نییە)</translation>
    </message>
</context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>Message:</source>
        <translation type="unfinished">پەیام:</translation>
    </message>
    </context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>Enter the receiver's address, message (ensure you copy line breaks, spaces, tabs, etc. exactly) and signature below to verify the message. Be careful not to read more into the signature than what is in the signed message itself, to avoid being tricked by a man-in-the-middle attack. Note that this only proves the signing party receives with the address, it cannot prove sendership of any transaction!</source>
        <translation type="unfinished">ناونیشانی وەرگرەکە بنووسە، نامە (دڵنیابە لەوەی کە جیاکەرەوەکانی هێڵ، مەوداکان، تابەکان، و هتد بە تەواوی کۆپی بکە) و لە خوارەوە واژووی بکە بۆ سەلماندنی نامەکە. وریابە لەوەی کە زیاتر نەیخوێنیتەوە بۆ ناو واژووەکە لەوەی کە لە خودی پەیامە واژووەکەدایە، بۆ ئەوەی خۆت بەدوور بگریت لە فێڵکردن لە هێرشی پیاوان لە ناوەنددا. سەرنج بدە کە ئەمە تەنیا لایەنی واژووکردن بە ناونیشانەکە وەربگرە، ناتوانێت نێرەری هیچ مامەڵەیەک بسەلمێنێت!</translation>
    </message>
    <message>
        <source>Click "Sign Message" to generate signature</source>
        <translation type="unfinished">کرتە بکە لەسەر "نامەی واژوو" بۆ دروستکردنی واژوو</translation>
    </message>
    <message>
        <source>Please check the address and try again.</source>
        <translation type="unfinished">تکایە ناونیشانەکە بپشکنە و دووبارە هەوڵ دەوە.</translation>
    </message>
    <message>
        <source>Please check the signature and try again.</source>
        <translation type="unfinished">تکایە واژووەکە بپشکنە و دووبارە هەوڵ دەوە.</translation>
    </message>
    </context>
<context>
    <name>TransactionDesc</name>
    <message>
        <source>Status</source>
        <translation type="unfinished">بارودۆخ</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished">رێکەت</translation>
    </message>
    <message>
        <source>Source</source>
        <translation type="unfinished">سەرچاوە</translation>
    </message>
    <message>
        <source>From</source>
        <translation type="unfinished">لە</translation>
    </message>
    <message>
        <source>To</source>
        <translation type="unfinished">بۆ</translation>
    </message>
    <message numerus="yes">
        <source>matures in %n more block(s)</source>
        <translation type="unfinished">
            <numerusform />
            <numerusform />
        </translation>
    </message>
    <message>
        <source>Message</source>
        <translation type="unfinished">پەیام</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">سەرجەم</translation>
    </message>
    <message>
        <source>true</source>
        <translation type="unfinished">دروستە</translation>
    </message>
    <message>
        <source>false</source>
        <translation type="unfinished">نادروستە</translation>
    </message>
</context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Date</source>
        <translation type="unfinished">رێکەت</translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished">جۆر</translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished">پێناسەکردن</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation type="unfinished">ناردن بۆ</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation type="unfinished">(ناونیشان نییە)</translation>
    </message>
    </context>
<context>
    <name>TransactionView</name>
    <message>
        <source>Sent to</source>
        <translation type="unfinished">ناردن بۆ</translation>
    </message>
    <message>
        <source>Enter address, transaction id, or label to search</source>
        <translation type="unfinished">ناونیشانێک بنووسە، ناسنامەی مامەڵە، یان ناولێنانێک بۆ گەڕان بنووسە</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished">رێکەت</translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished">جۆر</translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished">پێناسەکردن</translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="unfinished">ناوونیشان</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation type="unfinished">هەناردەکردن سەرکەوتوو نەبوو</translation>
    </message>
    <message>
        <source>to</source>
        <translation type="unfinished">بۆ</translation>
    </message>
</context>
<context>
    <name>WalletFrame</name>
    <message>
        <source>Error</source>
        <translation type="unfinished">هەڵە</translation>
    </message>
    </context>
<context>
    <name>WalletView</name>
    <message>
        <source>&amp;Export</source>
        <translation type="unfinished">&amp;هەناردن</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation type="unfinished">ناردنی داتا لە خشتەبەندی ئێستا بۆ فایلێک</translation>
    </message>
    </context>
<context>
    <name>kawra-core</name>
    <message>
        <source>Please check that your computer's date and time are correct! If your clock is wrong, %s will not work properly.</source>
        <translation type="unfinished">تکایە بپشکنە کە بەروار و کاتی کۆمپیوتەرەکەت ڕاستە! ئەگەر کاژێرەکەت هەڵە بوو، %s بە دروستی کار ناکات.</translation>
    </message>
    <message>
        <source>Please contribute if you find %s useful. Visit %s for further information about the software.</source>
        <translation type="unfinished">تکایە بەشداری بکە ئەگەر %s بەسوودت دۆزیەوە. سەردانی %s بکە بۆ زانیاری زیاتر دەربارەی نەرمواڵەکە.</translation>
    </message>
    <message>
        <source>Prune configured below the minimum of %d MiB.  Please use a higher number.</source>
        <translation type="unfinished">پڕە لە خوارەوەی کەمترین %d MiB شێوەبەند کراوە.  تکایە ژمارەیەکی بەرزتر بەکاربێنە.</translation>
    </message>
    <message>
        <source>Prune: last wallet synchronisation goes beyond pruned data. You need to -reindex (download the whole blockchain again in case of pruned node)</source>
        <translation type="unfinished">پرە: دوایین هاودەمکردنی جزدان لە داتای بەپێز دەچێت. پێویستە دووبارە -ئیندێکس بکەیتەوە (هەموو بەربەستەکە دابەزێنە دووبارە لە حاڵەتی گرێی هەڵکراو)</translation>
    </message>
    <message>
        <source>This error could occur if this wallet was not shutdown cleanly and was last loaded using a build with a newer version of Berkeley DB. If so, please use the software that last loaded this wallet</source>
        <translation type="unfinished">ئەم هەڵەیە لەوانەیە ڕووبدات ئەگەر ئەم جزدانە بە خاوێنی دانەبەزێنرابێت و دواجار بارکرا بێت بە بەکارهێنانی بنیاتێک بە وەشانێکی نوێتری بێرکلی DB. ئەگەر وایە، تکایە ئەو سۆفتوێرە بەکاربهێنە کە دواجار ئەم جزدانە بارکرا بوو</translation>
    </message>
    <message>
        <source>You need to rebuild the database using -reindex to go back to unpruned mode.  This will redownload the entire blockchain</source>
        <translation type="unfinished">پێویستە بنکەی زانیارییەکان دروست بکەیتەوە بە بەکارهێنانی -دووبارە ئیندێکس بۆ گەڕانەوە بۆ دۆخی نەپڕاو.  ئەمە هەموو بەربەستەکە دائەبەزێنێت</translation>
    </message>
    <message>
        <source>Copyright (C) %i-%i</source>
        <translation type="unfinished">مافی چاپ (C) %i-%i</translation>
    </message>
    <message>
        <source>Could not find asmap file %s</source>
        <translation type="unfinished">ئاسماپ بدۆزرێتەوە %s نەتوانرا فایلی</translation>
    </message>
    <message>
        <source>Error: Keypool ran out, please call keypoolrefill first</source>
        <translation type="unfinished">هەڵە: کلیلی پوول ڕایکرد، تکایە سەرەتا پەیوەندی بکە بە پڕکردنەوەی کلیل</translation>
    </message>
    </context>
</TS>