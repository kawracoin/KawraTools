Sample configuration files for:
```
systemd: kawrad.service
Upstart: kawrad.conf
OpenRC:  kawrad.openrc
         kawrad.openrcconf
CentOS:  kawrad.init
macOS:   org.kawra.kawrad.plist
```
have been made available to assist packagers in creating node packages here.

See [doc/init.md](../../doc/init.md) for more information.
